import { PrismaClient } from "@prisma/client"
import { hash } from "bcrypt"

const prisma = new PrismaClient()

async function main() {
  // Create a demo user
  const password = await hash("password123", 10)

  const user = await prisma.user.upsert({
    where: { email: "demo@example.com" },
    update: {},
    create: {
      email: "demo@example.com",
      name: "Demo User",
      password,
      role: "user",
      userSettings: {
        create: {
          theme: "system",
          language: "en",
          currency: "USD",
          emailNotifications: true,
          pushNotifications: true,
          smsNotifications: false,
          country: "us",
          timezone: "est",
          experience: "intermediate",
          riskTolerance: "moderate",
        },
      },
      copyTradingSettings: {
        create: {
          isEnabled: true,
          maxDailyLoss: 5,
          maxPositionSize: 10,
          stopLossEnabled: true,
          stopLossPercentage: 5,
          takeProfitEnabled: true,
          takeProfitPercentage: 10,
          traderAllocations: {
            create: [
              { traderId: 1, allocation: 50 },
              { traderId: 2, allocation: 30 },
              { traderId: 3, allocation: 20 },
            ],
          },
        },
      },
    },
  })

  console.log({ user })
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })

