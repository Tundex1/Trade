"use client"

import type React from "react"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  BarChart3,
  Briefcase,
  CreditCard,
  GraduationCap,
  Home,
  MessageSquare,
  PieChart,
  Settings,
  Shield,
  Users,
  TrendingUp,
  Zap,
  LineChart,
  TestTube,
  Rocket,
} from "lucide-react"

interface SidebarItem {
  title: string
  href: string
  icon: React.ComponentType<{ className?: string }>
  submenu?: { title: string; href: string }[]
}

export function DashboardSidebar() {
  const pathname = usePathname()
  const router = useRouter()

  const sidebarItems: SidebarItem[] = [
    {
      title: "Overview",
      href: "/dashboard",
      icon: Home,
    },
    {
      title: "Portfolio",
      href: "/dashboard/portfolio",
      icon: PieChart,
    },
    {
      title: "Traders",
      href: "/dashboard/traders",
      icon: Users,
    },
    {
      title: "Market",
      href: "/dashboard/market",
      icon: BarChart3,
    },
    {
      title: "Copy Trading",
      href: "/dashboard/copy-trading",
      icon: CreditCard,
      submenu: [
        { title: "Overview", href: "/dashboard/copy-trading" },
        { title: "Settings", href: "/dashboard/settings/copy-trading" },
      ],
    },
    {
      title: "Broker Accounts",
      href: "/dashboard/broker-accounts",
      icon: Briefcase,
      submenu: [
        { title: "My Accounts", href: "/dashboard/broker-accounts" },
        { title: "Connect Broker", href: "/dashboard/connect-broker" },
      ],
    },
    {
      title: "Advanced Features",
      href: "/dashboard/advanced",
      icon: Zap,
      submenu: [
        { title: "Risk Management", href: "/dashboard/advanced?tab=risk" },
        { title: "Social Trading", href: "/dashboard/advanced?tab=social" },
        { title: "Performance Analytics", href: "/dashboard/advanced?tab=performance" },
        { title: "System Status", href: "/dashboard/advanced?tab=status" },
      ],
    },
    {
      title: "Education",
      href: "/education",
      icon: GraduationCap,
    },
    {
      title: "Social",
      href: "/social",
      icon: MessageSquare,
    },
    {
      title: "Verification",
      href: "/verification",
      icon: Shield,
    },
    {
      title: "Analytics",
      href: "/dashboard/analytics",
      icon: LineChart,
    },
    {
      title: "Platform Tests",
      href: "/dashboard/tests",
      icon: TestTube,
    },
    {
      title: "Deployment Guide",
      href: "/dashboard/deployment",
      icon: Rocket,
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
    },
  ]

  return (
    <div className="flex border-r flex-col bg-background w-64">
      <div className="flex h-[52px] items-center border-b px-6">
        <Link href="/" className="flex items-center gap-2">
          <TrendingUp className="h-6 w-6" />
          <span className="text-xl font-bold">TradeCopy</span>
        </Link>
      </div>
      <ScrollArea className="flex-1 space-y-2 p-4">
        {sidebarItems.map((item) => {
          const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`)
          const Icon = item.icon

          return (
            <div key={item.href} className="mb-2">
              <Button
                variant={isActive ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => router.push(item.href)}
                asChild
              >
                <Link href={item.href} className="w-full">
                  <div className="flex items-center">
                    <Icon className="mr-2 h-4 w-4" />
                    {item.title}
                  </div>
                </Link>
              </Button>

              {item.submenu && isActive && (
                <div className="ml-6 mt-1 space-y-1">
                  {item.submenu.map((subitem) => {
                    const isSubActive =
                      pathname === subitem.href ||
                      (pathname === item.href &&
                        subitem.href.includes("?tab=") &&
                        pathname + window.location.search === subitem.href)

                    return (
                      <Button
                        key={subitem.href}
                        variant={isSubActive ? "secondary" : "ghost"}
                        size="sm"
                        className="w-full justify-start text-sm"
                        onClick={() => router.push(subitem.href)}
                        asChild
                      >
                        <Link href={subitem.href} className="w-full">
                          {subitem.title}
                        </Link>
                      </Button>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}
      </ScrollArea>
    </div>
  )
}

