"use client"

import { useState } from "react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

export function NotificationSettings() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    smsNotifications: false,
    tradeExecuted: true,
    tradeFailed: true,
    positionClosed: true,
    priceAlert: true,
    traderNewPosition: true,
    traderClosesPosition: true,
    traderPerformance: true,
    emailFrequency: "immediate",
    pushFrequency: "immediate",
  })

  const handleToggle = (setting: string) => {
    setSettings((prev) => ({ ...prev, [setting]: !prev[setting] }))
  }

  const handleChange = (setting: string, value: string) => {
    setSettings((prev) => ({ ...prev, [setting]: value }))
  }

  const handleSavePreferences = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      try {
        toast({
          title: "Preferences saved",
          description: "Your notification preferences have been updated successfully.",
        })
      } catch (error) {
        toast({
          title: "Save failed",
          description: "An error occurred while saving your preferences. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h3 className="text-lg font-medium">Notification Methods</h3>
        <p className="text-sm text-muted-foreground">Choose how you want to receive notifications</p>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="email-notifications">Email Notifications</Label>
            <p className="text-sm text-muted-foreground">Receive notifications via email</p>
          </div>
          <Switch
            id="email-notifications"
            checked={settings.emailNotifications}
            onCheckedChange={() => handleToggle("emailNotifications")}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="push-notifications">Push Notifications</Label>
            <p className="text-sm text-muted-foreground">Receive notifications on your device</p>
          </div>
          <Switch
            id="push-notifications"
            checked={settings.pushNotifications}
            onCheckedChange={() => handleToggle("pushNotifications")}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="sms-notifications">SMS Notifications</Label>
            <p className="text-sm text-muted-foreground">Receive notifications via text message</p>
          </div>
          <Switch
            id="sms-notifications"
            checked={settings.smsNotifications}
            onCheckedChange={() => handleToggle("smsNotifications")}
          />
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <h3 className="text-lg font-medium">Trading Notifications</h3>
          <p className="text-sm text-muted-foreground">Configure notifications for trading activities</p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="trade-executed">Trade Executed</Label>
              <p className="text-sm text-muted-foreground">When a trade is executed on your behalf</p>
            </div>
            <Switch
              id="trade-executed"
              checked={settings.tradeExecuted}
              onCheckedChange={() => handleToggle("tradeExecuted")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="trade-failed">Trade Failed</Label>
              <p className="text-sm text-muted-foreground">When a trade fails to execute</p>
            </div>
            <Switch
              id="trade-failed"
              checked={settings.tradeFailed}
              onCheckedChange={() => handleToggle("tradeFailed")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="position-closed">Position Closed</Label>
              <p className="text-sm text-muted-foreground">When a position is closed</p>
            </div>
            <Switch
              id="position-closed"
              checked={settings.positionClosed}
              onCheckedChange={() => handleToggle("positionClosed")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="price-alert">Price Alert</Label>
              <p className="text-sm text-muted-foreground">When a price alert is triggered</p>
            </div>
            <Switch id="price-alert" checked={settings.priceAlert} onCheckedChange={() => handleToggle("priceAlert")} />
          </div>
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <h3 className="text-lg font-medium">Trader Notifications</h3>
          <p className="text-sm text-muted-foreground">Configure notifications for trader activities</p>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="trader-new-position">Trader Opens Position</Label>
              <p className="text-sm text-muted-foreground">When a trader you follow opens a new position</p>
            </div>
            <Switch
              id="trader-new-position"
              checked={settings.traderNewPosition}
              onCheckedChange={() => handleToggle("traderNewPosition")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="trader-closes-position">Trader Closes Position</Label>
              <p className="text-sm text-muted-foreground">When a trader you follow closes a position</p>
            </div>
            <Switch
              id="trader-closes-position"
              checked={settings.traderClosesPosition}
              onCheckedChange={() => handleToggle("traderClosesPosition")}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="trader-performance">Trader Performance Update</Label>
              <p className="text-sm text-muted-foreground">Weekly performance updates for traders you follow</p>
            </div>
            <Switch
              id="trader-performance"
              checked={settings.traderPerformance}
              onCheckedChange={() => handleToggle("traderPerformance")}
            />
          </div>
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <h3 className="text-lg font-medium">Notification Frequency</h3>
          <p className="text-sm text-muted-foreground">Configure how often you receive notifications</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="email-frequency">Email Frequency</Label>
            <Select value={settings.emailFrequency} onValueChange={(value) => handleChange("emailFrequency", value)}>
              <SelectTrigger id="email-frequency">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="immediate">Immediate</SelectItem>
                <SelectItem value="hourly">Hourly Digest</SelectItem>
                <SelectItem value="daily">Daily Digest</SelectItem>
                <SelectItem value="weekly">Weekly Digest</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="push-frequency">Push Notification Frequency</Label>
            <Select value={settings.pushFrequency} onValueChange={(value) => handleChange("pushFrequency", value)}>
              <SelectTrigger id="push-frequency">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="immediate">Immediate</SelectItem>
                <SelectItem value="hourly">Hourly Digest</SelectItem>
                <SelectItem value="daily">Daily Digest</SelectItem>
                <SelectItem value="none">Do Not Disturb</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <Button onClick={handleSavePreferences} disabled={isLoading}>
          {isLoading ? "Saving..." : "Save Preferences"}
        </Button>
      </div>
    </div>
  )
}

