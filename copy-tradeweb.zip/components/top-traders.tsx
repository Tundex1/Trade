"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { TrendingUp, Info } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useTranslations } from "next-intl"

const traders = [
  {
    id: 1,
    name: "Alex Morgan",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AM",
    roi: 32.4,
    winRate: 78,
    riskLevel: "Medium",
    followers: 1245,
    trades: 342,
  },
  {
    id: 2,
    name: "Sarah Chen",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "SC",
    roi: 28.7,
    winRate: 82,
    riskLevel: "Low",
    followers: 987,
    trades: 256,
  },
  {
    id: 3,
    name: "Michael Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MJ",
    roi: 41.2,
    winRate: 71,
    riskLevel: "High",
    followers: 2134,
    trades: 512,
  },
  {
    id: 4,
    name: "David Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "DW",
    roi: 24.9,
    winRate: 75,
    riskLevel: "Medium",
    followers: 756,
    trades: 198,
  },
  {
    id: 5,
    name: "Emma Thompson",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "ET",
    roi: 36.8,
    winRate: 80,
    riskLevel: "Medium",
    followers: 1567,
    trades: 387,
  },
]

export function TopTraders() {
  const t = useTranslations("TopTraders")

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("title")}</CardTitle>
        <CardDescription>{t("description")}</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t("trader")}</TableHead>
              <TableHead>{t("roi")}</TableHead>
              <TableHead>{t("winRate")}</TableHead>
              <TableHead>{t("riskLevel")}</TableHead>
              <TableHead>{t("followers")}</TableHead>
              <TableHead className="text-right">{t("action")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {traders.map((trader) => (
              <TableRow key={trader.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={trader.avatar} alt={trader.name} />
                      <AvatarFallback>{trader.initials}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{trader.name}</div>
                      <div className="text-xs text-muted-foreground">{trader.trades} trades</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1 font-medium text-green-600">
                    {trader.roi}% <TrendingUp className="h-4 w-4" />
                  </div>
                </TableCell>
                <TableCell>{trader.winRate}%</TableCell>
                <TableCell>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="flex items-center gap-1">
                          {trader.riskLevel}
                          <Info className="h-3.5 w-3.5 text-muted-foreground" />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="max-w-xs text-xs">{t("riskDescription")}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </TableCell>
                <TableCell>{trader.followers.toLocaleString()}</TableCell>
                <TableCell className="text-right">
                  <Button size="sm">{t("follow")}</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

