"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import { useTraders } from "@/lib/traders"

export function CopyTradingSettings() {
  const { toast } = useToast()
  const { traders } = useTraders()
  const [isLoading, setIsLoading] = useState(false)
  const [settings, setSettings] = useState({
    copyTradingEnabled: true,
    copyMode: "automatic",
    delaySeconds: 1,
    minTraderRating: 4,
    minWinRate: 65,
    copyOnlyVerified: true,
    notifyOnCopy: true,
    notifyOnClose: true,
    defaultOrderSize: "proportional",
    proportionalSize: 100, // percentage
    fixedSize: 500, // dollar amount
    excludeInstruments: [],
    excludeTraderTypes: [],
  })

  const handleToggle = (setting: string) => {
    setSettings((prev) => ({ ...prev, [setting]: !prev[setting] }))
  }

  const handleChange = (setting: string, value: any) => {
    setSettings((prev) => ({ ...prev, [setting]: value }))
  }

  const handleSaveSettings = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      try {
        toast({
          title: "Settings saved",
          description: "Your copy trading settings have been updated successfully.",
        })
      } catch (error) {
        toast({
          title: "Save failed",
          description: "An error occurred while saving your settings. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }, 1000)
  }

  const followedTraders = traders.filter((trader) => trader.following).length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-0.5">
          <Label htmlFor="copy-trading">Enable Copy Trading</Label>
          <p className="text-sm text-muted-foreground">
            When enabled, trades from traders you follow will be automatically copied to your account
          </p>
        </div>
        <Switch
          id="copy-trading"
          checked={settings.copyTradingEnabled}
          onCheckedChange={() => handleToggle("copyTradingEnabled")}
        />
      </div>

      <div className="rounded-md bg-muted p-4">
        <div className="text-sm">
          <span className="font-medium">Status:</span>{" "}
          {settings.copyTradingEnabled ? (
            <span className="text-green-600 font-medium">Active</span>
          ) : (
            <span className="text-red-600 font-medium">Inactive</span>
          )}
          <p className="mt-1">
            You are currently following {followedTraders} trader{followedTraders !== 1 ? "s" : ""}.
          </p>
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Copy Mode</Label>
          <RadioGroup
            value={settings.copyMode}
            onValueChange={(value) => handleChange("copyMode", value)}
            disabled={!settings.copyTradingEnabled}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="automatic" id="automatic" />
              <Label htmlFor="automatic" className="font-normal">
                Automatic (Copy trades instantly)
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="manual" id="manual" />
              <Label htmlFor="manual" className="font-normal">
                Manual Approval (Review trades before copying)
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="delayed" id="delayed" />
              <Label htmlFor="delayed" className="font-normal">
                Delayed (Copy trades after a delay)
              </Label>
            </div>
          </RadioGroup>
        </div>

        {settings.copyMode === "delayed" && (
          <div className="space-y-2">
            <Label>Delay (seconds)</Label>
            <div className="flex items-center gap-4">
              <Slider
                value={[settings.delaySeconds]}
                min={1}
                max={30}
                step={1}
                onValueChange={(value) => handleChange("delaySeconds", value[0])}
                disabled={!settings.copyTradingEnabled}
                className="flex-1"
              />
              <span className="w-12 text-center">{settings.delaySeconds}s</span>
            </div>
            <p className="text-xs text-muted-foreground">
              Trades will be copied after the specified delay, giving you time to cancel if needed.
            </p>
          </div>
        )}
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Trader Criteria</Label>
          <p className="text-sm text-muted-foreground">
            Set minimum criteria for traders whose trades you want to copy
          </p>
        </div>

        <div className="space-y-2">
          <Label>Minimum Win Rate (%)</Label>
          <div className="flex items-center gap-4">
            <Slider
              value={[settings.minWinRate]}
              min={50}
              max={100}
              step={5}
              onValueChange={(value) => handleChange("minWinRate", value[0])}
              disabled={!settings.copyTradingEnabled}
              className="flex-1"
            />
            <span className="w-12 text-center">{settings.minWinRate}%</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="copy-verified">Copy Only Verified Traders</Label>
            <p className="text-sm text-muted-foreground">Only copy trades from verified traders</p>
          </div>
          <Switch
            id="copy-verified"
            checked={settings.copyOnlyVerified}
            onCheckedChange={() => handleToggle("copyOnlyVerified")}
            disabled={!settings.copyTradingEnabled}
          />
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Order Size Configuration</Label>
          <RadioGroup
            value={settings.defaultOrderSize}
            onValueChange={(value) => handleChange("defaultOrderSize", value)}
            disabled={!settings.copyTradingEnabled}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="proportional" id="proportional" />
              <Label htmlFor="proportional" className="font-normal">
                Proportional (% of your capital)
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="fixed" id="fixed" />
              <Label htmlFor="fixed" className="font-normal">
                Fixed Amount ($ per trade)
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="mirror" id="mirror" />
              <Label htmlFor="mirror" className="font-normal">
                Mirror Exactly (Same size as trader)
              </Label>
            </div>
          </RadioGroup>
        </div>

        {settings.defaultOrderSize === "proportional" && (
          <div className="space-y-2">
            <Label>Proportion of Capital (%)</Label>
            <div className="flex items-center gap-4">
              <Slider
                value={[settings.proportionalSize]}
                min={1}
                max={100}
                step={1}
                onValueChange={(value) => handleChange("proportionalSize", value[0])}
                disabled={!settings.copyTradingEnabled}
                className="flex-1"
              />
              <span className="w-12 text-center">{settings.proportionalSize}%</span>
            </div>
            <p className="text-xs text-muted-foreground">
              Each copied trade will use this percentage of your allocated capital for the trader.
            </p>
          </div>
        )}

        {settings.defaultOrderSize === "fixed" && (
          <div className="space-y-2">
            <Label>Fixed Amount ($)</Label>
            <div className="flex items-center gap-4">
              <Slider
                value={[settings.fixedSize]}
                min={100}
                max={10000}
                step={100}
                onValueChange={(value) => handleChange("fixedSize", value[0])}
                disabled={!settings.copyTradingEnabled}
                className="flex-1"
              />
              <span className="w-20 text-center">${settings.fixedSize}</span>
            </div>
            <p className="text-xs text-muted-foreground">Each copied trade will use this fixed dollar amount.</p>
          </div>
        )}
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Notifications</Label>
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="notify-copy">Notify on Trade Copy</Label>
            <p className="text-sm text-muted-foreground">Receive notifications when trades are copied</p>
          </div>
          <Switch
            id="notify-copy"
            checked={settings.notifyOnCopy}
            onCheckedChange={() => handleToggle("notifyOnCopy")}
            disabled={!settings.copyTradingEnabled}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="notify-close">Notify on Position Close</Label>
            <p className="text-sm text-muted-foreground">Receive notifications when copied positions are closed</p>
          </div>
          <Switch
            id="notify-close"
            checked={settings.notifyOnClose}
            onCheckedChange={() => handleToggle("notifyOnClose")}
            disabled={!settings.copyTradingEnabled}
          />
        </div>
      </div>

      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            "Save Settings"
          )}
        </Button>
      </div>
    </div>
  )
}

