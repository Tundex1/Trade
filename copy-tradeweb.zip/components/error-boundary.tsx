"use client"

import { useEffect } from "react"

import { useState } from "react"

import type { ReactNode } from "react"

interface ErrorBoundaryProps {
  children: ReactNode
}

export default function ErrorBoundary({ children }: ErrorBoundaryProps) {
  const [hasError, setHasError] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    const errorHandler = (error: Error) => {
      setHasError(true)
      setError(error)
    }

    window.addEventListener("error", errorHandler)
    return () => window.removeEventListener("error", errorHandler)
  }, [])

  if (hasError) {
    return (
      <div>
        <h1>Something went wrong!</h1>
        <pre>{error?.stack}</pre>
      </div>
    )
  }

  return children
}

