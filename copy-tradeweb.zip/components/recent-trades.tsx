"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { usePortfolio } from "@/lib/portfolio"
import { formatDistanceToNow } from "date-fns"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export function RecentTrades() {
  const router = useRouter()
  const { trades } = usePortfolio()

  // Get the 4 most recent trades
  const recentTrades = trades.slice(0, 4)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Trades</CardTitle>
        <CardDescription>Your most recent copy trades</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentTrades.length > 0 ? (
            recentTrades.map((trade) => (
              <div key={trade.id} className="flex items-center justify-between border-b pb-2 last:border-0">
                <div>
                  <div className="flex items-center gap-2">
                    <div className="font-medium">{trade.symbol}</div>
                    <Badge variant={trade.type === "BUY" ? "default" : "destructive"}>{trade.type}</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(trade.date), { addSuffix: true })}
                    {trade.traderName && ` • via ${trade.traderName}`}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">
                    ${trade.price.toLocaleString()} × {trade.quantity}
                  </div>
                  <div className="text-xs text-muted-foreground">${trade.total.toLocaleString()}</div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">No recent trades to display.</p>
            </div>
          )}
        </div>

        {trades.length > 4 && (
          <Button variant="outline" className="mt-4 w-full" onClick={() => router.push("/dashboard/portfolio")}>
            View All Trades
          </Button>
        )}
      </CardContent>
    </Card>
  )
}

