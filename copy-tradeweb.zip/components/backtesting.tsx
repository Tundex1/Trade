"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { toast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

interface BacktestingResult {
  date: string
  profit: number
}

export function Backtesting() {
  const [symbol, setSymbol] = useState("AAPL")
  const [startDate, setStartDate] = useState("2023-01-01")
  const [endDate, setEndDate] = useState("2023-12-31")
  const [strategy, setStrategy] = useState("simple_ma")
  const [initialCapital, setInitialCapital] = useState(10000)
  const [results, setResults] = useState<BacktestingResult[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const handleRunBacktest = async () => {
    setIsLoading(true)
    setResults([])

    // Simulate API call to a backend service
    try {
      const mockResults = [
        { date: "2023-01-03", profit: 120 },
        { date: "2023-01-10", profit: 150 },
        { date: "2023-01-17", profit: -50 },
        { date: "2023-01-24", profit: 200 },
        { date: "2023-01-31", profit: 180 },
      ]

      setResults(mockResults)
    } catch (error) {
      console.error("Backtesting error:", error)
      toast({
        title: "Backtesting Failed",
        description: "An error occurred during backtesting. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Backtesting</CardTitle>
        <CardDescription>Simulate your trading strategies against historical data</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="symbol">Symbol</Label>
            <Input id="symbol" value={symbol} onChange={(e) => setSymbol(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="strategy">Strategy</Label>
            <Select value={strategy} onValueChange={setStrategy}>
              <SelectTrigger id="strategy">
                <SelectValue placeholder="Select strategy" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="simple_ma">Simple Moving Average</SelectItem>
                <SelectItem value="rsi_divergence">RSI Divergence</SelectItem>
                <SelectItem value="macd_crossover">MACD Crossover</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="start-date">Start Date</Label>
            <Input id="start-date" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="end-date">End Date</Label>
            <Input id="end-date" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="initial-capital">Initial Capital</Label>
            <Input
              id="initial-capital"
              type="number"
              value={initialCapital}
              onChange={(e) => setInitialCapital(Number(e.target.value))}
            />
          </div>
        </div>

        <Button onClick={handleRunBacktest} disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Running Backtest...
            </>
          ) : (
            "Run Backtest"
          )}
        </Button>

        {results.length > 0 && (
          <div className="mt-4">
            <h3 className="text-sm font-medium mb-2">Results</h3>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={results} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="profit" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

