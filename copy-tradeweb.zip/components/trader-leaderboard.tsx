"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { TrendingUp, Info, Star, StarOff } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import Link from "next/link"
import { useTraders } from "@/lib/traders"
import { useToast } from "@/components/ui/use-toast"

interface TraderLeaderboardProps {
  followingOnly?: boolean
  recommended?: boolean
}

export function TraderLeaderboard({ followingOnly = false, recommended = false }: TraderLeaderboardProps) {
  const { traders, toggleFollow, isFollowing } = useTraders()
  const { toast } = useToast()

  // Filter traders based on props
  const filteredTraders = followingOnly
    ? traders.filter((trader) => trader.following)
    : recommended
      ? traders.filter((trader) => !trader.following).slice(0, 4)
      : traders

  const handleToggleFollow = (traderId: number, traderName: string, isFollowing: boolean) => {
    toggleFollow(traderId)

    toast({
      title: isFollowing ? "Trader unfollowed" : "Trader followed",
      description: isFollowing
        ? `You are no longer following ${traderName}.`
        : `You are now following ${traderName}. Their trades will be copied to your account.`,
    })
  }

  return (
    <div className="overflow-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Trader</TableHead>
            <TableHead>ROI (30d)</TableHead>
            <TableHead>Win Rate</TableHead>
            <TableHead>Risk Level</TableHead>
            <TableHead>Followers</TableHead>
            <TableHead className="text-right">Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredTraders.map((trader) => (
            <TableRow key={trader.id}>
              <TableCell>
                <Link href={`/dashboard/traders/${trader.id}`} className="flex items-center gap-3 hover:underline">
                  <Avatar>
                    <AvatarImage src={trader.avatar} alt={trader.name} />
                    <AvatarFallback>{trader.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{trader.name}</div>
                    <div className="text-xs text-muted-foreground">{trader.trades} trades</div>
                  </div>
                </Link>
              </TableCell>
              <TableCell>
                <div className="flex items-center gap-1 font-medium text-green-600">
                  {trader.roi}% <TrendingUp className="h-4 w-4" />
                </div>
              </TableCell>
              <TableCell>{trader.winRate}%</TableCell>
              <TableCell>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-1">
                        {trader.riskLevel}
                        <Info className="h-3.5 w-3.5 text-muted-foreground" />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="max-w-xs text-xs">
                        Risk level is calculated based on position sizing, leverage, and trading frequency.
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </TableCell>
              <TableCell>{trader.followers.toLocaleString()}</TableCell>
              <TableCell className="text-right">
                <div className="flex items-center justify-end gap-2">
                  <Button
                    variant={trader.following ? "outline" : "default"}
                    size="sm"
                    onClick={() => handleToggleFollow(trader.id, trader.name, trader.following)}
                  >
                    {trader.following ? (
                      <>
                        <StarOff className="mr-1 h-4 w-4" />
                        Unfollow
                      </>
                    ) : (
                      <>
                        <Star className="mr-1 h-4 w-4" />
                        Follow
                      </>
                    )}
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

