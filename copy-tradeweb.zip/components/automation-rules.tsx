"use client"

import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export function AutomationRules() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [rules, setRules] = useState([
    { id: 1, type: "profit", name: "Take Profit at 20%", enabled: true },
    { id: 2, type: "loss", name: "Stop Loss at 10%", enabled: true },
    { id: 3, type: "time", name: "Close After 7 Days", enabled: false },
  ])

  const handleToggleRule = (ruleId: number) => {
    setRules((prev) => prev.map((rule) => (rule.id === ruleId ? { ...rule, enabled: !rule.enabled } : rule)))
  }

  const handleSaveSettings = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      try {
        toast({
          title: "Automation rules saved",
          description: "Your automation rules have been updated successfully.",
        })
      } catch (error) {
        toast({
          title: "Save failed",
          description: "An error occurred while saving your rules. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label>Automation Rules</Label>
        <p className="text-sm text-muted-foreground">Set up automated rules for copy trading</p>
      </div>

      {rules.map((rule) => (
        <div key={rule.id} className="flex items-center justify-between">
          <div>
            <p className="font-medium">{rule.name}</p>
            <p className="text-sm text-muted-foreground">Type: {rule.type}</p>
          </div>
          <Switch checked={rule.enabled} onCheckedChange={() => handleToggleRule(rule.id)} />
        </div>
      ))}

      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          Save Rules
        </Button>
      </div>
    </div>
  )
}

