"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Check, DollarSign, EuroIcon, PoundSterling, JapaneseYenIcon as Yen } from "lucide-react"

const currencies = [
  { code: "USD", name: "US Dollar", symbol: "$", icon: DollarSign },
  { code: "EUR", name: "Euro", symbol: "€", icon: EuroIcon },
  { code: "GBP", name: "British Pound", symbol: "£", icon: PoundSterling },
  { code: "JPY", name: "Japanese Yen", symbol: "¥", icon: Yen },
  { code: "AUD", name: "Australian Dollar", symbol: "A$", icon: DollarSign },
  { code: "CAD", name: "Canadian Dollar", symbol: "C$", icon: DollarSign },
  { code: "CHF", name: "Swiss Franc", symbol: "Fr", icon: DollarSign },
]

export function CurrencySelector() {
  const [currentCurrency, setCurrentCurrency] = useState(currencies[0])

  const handleCurrencyChange = (currency: (typeof currencies)[0]) => {
    setCurrentCurrency(currency)
    // In a real app, this would update the app's currency preference
    // and potentially reload data with new currency
  }

  const CurrencyIcon = currentCurrency.icon

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="flex items-center gap-1">
          <CurrencyIcon className="h-4 w-4 mr-1" />
          <span>{currentCurrency.code}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {currencies.map((currency) => {
          const CurrIcon = currency.icon
          return (
            <DropdownMenuItem
              key={currency.code}
              onClick={() => handleCurrencyChange(currency)}
              className="flex items-center justify-between"
            >
              <span className="flex items-center">
                <CurrIcon className="h-4 w-4 mr-2" />
                {currency.name} ({currency.symbol})
              </span>
              {currentCurrency.code === currency.code && <Check className="h-4 w-4 ml-2" />}
            </DropdownMenuItem>
          )
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

