"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { AlertTriangle, BarChart3, Clock, LineChart, Save, Shield, TrendingDown, TrendingUp } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface RiskSettings {
  maxDrawdown: number
  maxAllocation: number
  maxPositionSize: number
  stopLossEnabled: boolean
  stopLossPercentage: number
  takeProfitEnabled: boolean
  takeProfitPercentage: number
  maxDailyLoss: number
  maxWeeklyLoss: number
  maxMonthlyLoss: number
  maxOpenPositions: number
  maxLeverage: number
  riskPerTrade: number
  autoCloseEnabled: boolean
  autoCloseThreshold: number
  volatilityProtection: boolean
  volatilityThreshold: number
  correlationProtection: boolean
  correlationThreshold: number
  limitAction: "notify" | "pause" | "close"
}

export function AdvancedRiskControls() {
  const { toast } = useToast()

  const [riskSettings, setRiskSettings] = useState<RiskSettings>({
    maxDrawdown: 15,
    maxAllocation: 30,
    maxPositionSize: 5,
    stopLossEnabled: true,
    stopLossPercentage: 10,
    takeProfitEnabled: true,
    takeProfitPercentage: 20,
    maxDailyLoss: 5,
    maxWeeklyLoss: 10,
    maxMonthlyLoss: 20,
    maxOpenPositions: 10,
    maxLeverage: 5,
    riskPerTrade: 2,
    autoCloseEnabled: true,
    autoCloseThreshold: 25,
    volatilityProtection: true,
    volatilityThreshold: 30,
    correlationProtection: true,
    correlationThreshold: 80,
    limitAction: "notify",
  })

  const [riskScore, setRiskScore] = useState(65)
  const [riskLevel, setRiskLevel] = useState("Medium")

  // Calculate risk score whenever settings change
  useEffect(() => {
    calculateRiskScore()
  }, [riskSettings])

  const handleSaveSettings = () => {
    try {
      // In a real app, this would save to a database or API
      localStorage.setItem("riskSettings", JSON.stringify(riskSettings))

      toast({
        title: "Risk settings saved",
        description: "Your risk management settings have been updated.",
      })
    } catch (error) {
      toast({
        title: "Error saving settings",
        description: "There was a problem saving your risk settings. Please try again.",
        variant: "destructive",
      })
    }
  }

  const calculateRiskScore = () => {
    // This is a simplified risk score calculation
    // In a real application, this would be more sophisticated
    let score = 100

    // Higher values increase risk
    score -= riskSettings.maxDrawdown * 1.5
    score -= riskSettings.maxAllocation * 0.5
    score -= riskSettings.maxPositionSize * 3
    score -= riskSettings.maxLeverage * 5
    score -= riskSettings.riskPerTrade * 5

    // Protective measures decrease risk
    if (riskSettings.stopLossEnabled) score += 10
    if (riskSettings.takeProfitEnabled) score += 5
    if (riskSettings.autoCloseEnabled) score += 10
    if (riskSettings.volatilityProtection) score += 5
    if (riskSettings.correlationProtection) score += 5

    // Clamp between 0 and 100
    score = Math.max(0, Math.min(100, Math.round(score)))

    setRiskScore(score)

    // Set risk level based on score
    if (score < 30) {
      setRiskLevel("Low")
    } else if (score < 70) {
      setRiskLevel("Medium")
    } else {
      setRiskLevel("High")
    }
  }

  const handleRiskSettingChange = (key: keyof RiskSettings, value: number | boolean | string) => {
    setRiskSettings((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Advanced Risk Management</h2>
          <p className="text-muted-foreground">Configure protection measures for your copy trading</p>
        </div>

        <Card className="w-full md:w-auto">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="relative w-20 h-20">
                <div className="absolute inset-0 rounded-full bg-gray-100 flex items-center justify-center">
                  <div
                    className="absolute inset-0 rounded-full border-4 border-transparent"
                    style={{
                      borderTopColor: riskScore < 30 ? "green" : riskScore < 70 ? "orange" : "red",
                      transform: `rotate(${riskScore * 3.6}deg)`,
                      transition: "transform 0.5s ease-out",
                    }}
                  />
                  <span className="text-lg font-bold">{riskScore}</span>
                </div>
              </div>

              <div>
                <div className="text-sm text-muted-foreground">Risk Score</div>
                <div className="text-xl font-bold flex items-center">
                  {riskLevel}
                  {riskLevel === "Low" && <Shield className="ml-1 h-5 w-5 text-green-500" />}
                  {riskLevel === "Medium" && <AlertTriangle className="ml-1 h-5 w-5 text-orange-500" />}
                  {riskLevel === "High" && <AlertTriangle className="ml-1 h-5 w-5 text-red-500" />}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Risk Management is Critical</AlertTitle>
        <AlertDescription>
          Proper risk management is essential for long-term success in copy trading. These settings help protect your
          capital.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="general">
        <TabsList className="grid grid-cols-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="stop-loss">Stop Loss & Take Profit</TabsTrigger>
          <TabsTrigger value="limits">Loss Limits</TabsTrigger>
          <TabsTrigger value="advanced">Advanced Protection</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>General Risk Settings</CardTitle>
              <CardDescription>Configure your basic risk parameters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="max-drawdown">Maximum Drawdown (%)</Label>
                  <span className="text-sm font-medium">{riskSettings.maxDrawdown}%</span>
                </div>
                <Slider
                  id="max-drawdown"
                  min={5}
                  max={50}
                  step={1}
                  value={[riskSettings.maxDrawdown]}
                  onValueChange={(value) => handleRiskSettingChange("maxDrawdown", value[0])}
                />
                <p className="text-xs text-muted-foreground">
                  Stop copying a trader if their account drawdown exceeds this percentage
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="max-allocation">Maximum Allocation per Trader (%)</Label>
                  <span className="text-sm font-medium">{riskSettings.maxAllocation}%</span>
                </div>
                <Slider
                  id="max-allocation"
                  min={5}
                  max={100}
                  step={5}
                  value={[riskSettings.maxAllocation]}
                  onValueChange={(value) => handleRiskSettingChange("maxAllocation", value[0])}
                />
                <p className="text-xs text-muted-foreground">
                  Maximum percentage of your capital allocated to a single trader
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="max-position">Maximum Position Size (%)</Label>
                  <span className="text-sm font-medium">{riskSettings.maxPositionSize}%</span>
                </div>
                <Slider
                  id="max-position"
                  min={1}
                  max={20}
                  step={1}
                  value={[riskSettings.maxPositionSize]}
                  onValueChange={(value) => handleRiskSettingChange("maxPositionSize", value[0])}
                />
                <p className="text-xs text-muted-foreground">
                  Maximum percentage of your capital allocated to a single position
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="max-leverage">Maximum Leverage</Label>
                  <span className="text-sm font-medium">{riskSettings.maxLeverage}x</span>
                </div>
                <Slider
                  id="max-leverage"
                  min={1}
                  max={20}
                  step={1}
                  value={[riskSettings.maxLeverage]}
                  onValueChange={(value) => handleRiskSettingChange("maxLeverage", value[0])}
                />
                <p className="text-xs text-muted-foreground">Maximum leverage allowed for copied trades</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="risk-per-trade">Risk per Trade (%)</Label>
                  <span className="text-sm font-medium">{riskSettings.riskPerTrade}%</span>
                </div>
                <Slider
                  id="risk-per-trade"
                  min={0.5}
                  max={10}
                  step={0.5}
                  value={[riskSettings.riskPerTrade]}
                  onValueChange={(value) => handleRiskSettingChange("riskPerTrade", value[0])}
                />
                <p className="text-xs text-muted-foreground">Maximum percentage of your capital at risk per trade</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="max-positions">Maximum Open Positions</Label>
                  <span className="text-sm font-medium">{riskSettings.maxOpenPositions}</span>
                </div>
                <Slider
                  id="max-positions"
                  min={1}
                  max={50}
                  step={1}
                  value={[riskSettings.maxOpenPositions]}
                  onValueChange={(value) => handleRiskSettingChange("maxOpenPositions", value[0])}
                />
                <p className="text-xs text-muted-foreground">Maximum number of open positions allowed at once</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stop-loss" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Stop Loss & Take Profit</CardTitle>
              <CardDescription>Configure automatic exit strategies</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="stop-loss-toggle">Automatic Stop Loss</Label>
                  <p className="text-xs text-muted-foreground">Automatically set stop losses for all copied trades</p>
                </div>
                <Switch
                  id="stop-loss-toggle"
                  checked={riskSettings.stopLossEnabled}
                  onCheckedChange={(checked) => handleRiskSettingChange("stopLossEnabled", checked)}
                />
              </div>

              {riskSettings.stopLossEnabled && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="stop-loss-percentage">Stop Loss Percentage</Label>
                    <span className="text-sm font-medium">{riskSettings.stopLossPercentage}%</span>
                  </div>
                  <Slider
                    id="stop-loss-percentage"
                    min={1}
                    max={50}
                    step={1}
                    value={[riskSettings.stopLossPercentage]}
                    onValueChange={(value) => handleRiskSettingChange("stopLossPercentage", value[0])}
                  />
                  <div className="flex items-center text-xs text-muted-foreground">
                    <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                    Close position if it loses this percentage of its value
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="take-profit-toggle">Automatic Take Profit</Label>
                  <p className="text-xs text-muted-foreground">Automatically set take profits for all copied trades</p>
                </div>
                <Switch
                  id="take-profit-toggle"
                  checked={riskSettings.takeProfitEnabled}
                  onCheckedChange={(checked) => handleRiskSettingChange("takeProfitEnabled", checked)}
                />
              </div>

              {riskSettings.takeProfitEnabled && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="take-profit-percentage">Take Profit Percentage</Label>
                    <span className="text-sm font-medium">{riskSettings.takeProfitPercentage}%</span>
                  </div>
                  <Slider
                    id="take-profit-percentage"
                    min={1}
                    max={100}
                    step={1}
                    value={[riskSettings.takeProfitPercentage]}
                    onValueChange={(value) => handleRiskSettingChange("takeProfitPercentage", value[0])}
                  />
                  <div className="flex items-center text-xs text-muted-foreground">
                    <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                    Close position if it gains this percentage in value
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-close-toggle">Auto-Close Protection</Label>
                  <p className="text-xs text-muted-foreground">
                    Automatically close all positions if drawdown exceeds threshold
                  </p>
                </div>
                <Switch
                  id="auto-close-toggle"
                  checked={riskSettings.autoCloseEnabled}
                  onCheckedChange={(checked) => handleRiskSettingChange("autoCloseEnabled", checked)}
                />
              </div>

              {riskSettings.autoCloseEnabled && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="auto-close-threshold">Auto-Close Threshold</Label>
                    <span className="text-sm font-medium">{riskSettings.autoCloseThreshold}%</span>
                  </div>
                  <Slider
                    id="auto-close-threshold"
                    min={5}
                    max={50}
                    step={1}
                    value={[riskSettings.autoCloseThreshold]}
                    onValueChange={(value) => handleRiskSettingChange("autoCloseThreshold", value[0])}
                  />
                  <div className="flex items-center text-xs text-muted-foreground">
                    <AlertTriangle className="mr-1 h-3 w-3 text-orange-500" />
                    Close all positions if total account drawdown exceeds this percentage
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="limits" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Loss Limits</CardTitle>
              <CardDescription>Set maximum loss thresholds for different time periods</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="daily-loss">Maximum Daily Loss (%)</Label>
                  <span className="text-sm font-medium">{riskSettings.maxDailyLoss}%</span>
                </div>
                <Slider
                  id="daily-loss"
                  min={1}
                  max={20}
                  step={1}
                  value={[riskSettings.maxDailyLoss]}
                  onValueChange={(value) => handleRiskSettingChange("maxDailyLoss", value[0])}
                />
                <div className="flex items-center text-xs text-muted-foreground">
                  <Clock className="mr-1 h-3 w-3" />
                  Stop trading for the day if losses exceed this percentage
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="weekly-loss">Maximum Weekly Loss (%)</Label>
                  <span className="text-sm font-medium">{riskSettings.maxWeeklyLoss}%</span>
                </div>
                <Slider
                  id="weekly-loss"
                  min={1}
                  max={30}
                  step={1}
                  value={[riskSettings.maxWeeklyLoss]}
                  onValueChange={(value) => handleRiskSettingChange("maxWeeklyLoss", value[0])}
                />
                <div className="flex items-center text-xs text-muted-foreground">
                  <Clock className="mr-1 h-3 w-3" />
                  Stop trading for the week if losses exceed this percentage
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="monthly-loss">Maximum Monthly Loss (%)</Label>
                  <span className="text-sm font-medium">{riskSettings.maxMonthlyLoss}%</span>
                </div>
                <Slider
                  id="monthly-loss"
                  min={5}
                  max={50}
                  step={1}
                  value={[riskSettings.maxMonthlyLoss]}
                  onValueChange={(value) => handleRiskSettingChange("maxMonthlyLoss", value[0])}
                />
                <div className="flex items-center text-xs text-muted-foreground">
                  <Clock className="mr-1 h-3 w-3" />
                  Stop trading for the month if losses exceed this percentage
                </div>
              </div>

              <div className="pt-4">
                <Select
                  defaultValue={riskSettings.limitAction}
                  onValueChange={(value) => handleRiskSettingChange("limitAction", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select action when limit is reached" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="notify">Notify Only</SelectItem>
                    <SelectItem value="pause">Pause Copy Trading</SelectItem>
                    <SelectItem value="close">Close All Positions</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-2">Action to take when a loss limit is reached</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="advanced" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Advanced Protection</CardTitle>
              <CardDescription>Configure sophisticated risk management features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="volatility-toggle">Volatility Protection</Label>
                  <p className="text-xs text-muted-foreground">Reduce position sizes during high market volatility</p>
                </div>
                <Switch
                  id="volatility-toggle"
                  checked={riskSettings.volatilityProtection}
                  onCheckedChange={(checked) => handleRiskSettingChange("volatilityProtection", checked)}
                />
              </div>

              {riskSettings.volatilityProtection && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="volatility-threshold">Volatility Threshold</Label>
                    <span className="text-sm font-medium">{riskSettings.volatilityThreshold}</span>
                  </div>
                  <Slider
                    id="volatility-threshold"
                    min={10}
                    max={50}
                    step={1}
                    value={[riskSettings.volatilityThreshold]}
                    onValueChange={(value) => handleRiskSettingChange("volatilityThreshold", value[0])}
                  />
                  <div className="flex items-center text-xs text-muted-foreground">
                    <BarChart3 className="mr-1 h-3 w-3" />
                    Reduce position sizes when market volatility exceeds this threshold
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="correlation-toggle">Correlation Protection</Label>
                  <p className="text-xs text-muted-foreground">Limit exposure to highly correlated assets</p>
                </div>
                <Switch
                  id="correlation-toggle"
                  checked={riskSettings.correlationProtection}
                  onCheckedChange={(checked) => handleRiskSettingChange("correlationProtection", checked)}
                />
              </div>

              {riskSettings.correlationProtection && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="correlation-threshold">Correlation Threshold (%)</Label>
                    <span className="text-sm font-medium">{riskSettings.correlationThreshold}%</span>
                  </div>
                  <Slider
                    id="correlation-threshold"
                    min={50}
                    max={100}
                    step={1}
                    value={[riskSettings.correlationThreshold]}
                    onValueChange={(value) => handleRiskSettingChange("correlationThreshold", value[0])}
                  />
                  <div className="flex items-center text-xs text-muted-foreground">
                    <LineChart className="mr-1 h-3 w-3" />
                    Reduce position sizes when asset correlation exceeds this percentage
                  </div>
                </div>
              )}

              <div className="pt-2">
                <div className="flex items-center space-x-2">
                  <Switch id="news-protection" />
                  <Label htmlFor="news-protection">News Event Protection</Label>
                </div>
                <p className="text-xs text-muted-foreground mt-1 ml-7">
                  Reduce position sizes before major economic announcements
                </p>
              </div>

              <div className="pt-2">
                <div className="flex items-center space-x-2">
                  <Switch id="weekend-protection" />
                  <Label htmlFor="weekend-protection">Weekend Gap Protection</Label>
                </div>
                <p className="text-xs text-muted-foreground mt-1 ml-7">
                  Reduce position sizes before market closes for the weekend
                </p>
              </div>

              <div className="pt-2">
                <div className="flex items-center space-x-2">
                  <Switch id="smart-diversification" />
                  <Label htmlFor="smart-diversification">Smart Diversification</Label>
                </div>
                <p className="text-xs text-muted-foreground mt-1 ml-7">
                  Automatically balance your portfolio across different asset classes
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} className="w-full md:w-auto">
          <Save className="mr-2 h-4 w-4" />
          Save Risk Settings
        </Button>
      </div>
    </div>
  )
}

