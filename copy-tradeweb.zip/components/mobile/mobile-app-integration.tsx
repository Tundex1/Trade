"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { QRCode } from "react-qrcode-logo"
import {
  Smartphone,
  QrCode,
  Send,
  Apple,
  SmartphoneIcon as Android,
  Loader2,
  CheckCircle,
  Bell,
  BarChart,
  Copy,
  Laptop,
} from "lucide-react"

export function MobileAppIntegration() {
  const { toast } = useToast()
  const [phoneNumber, setPhoneNumber] = useState("")
  const [isSending, setIsSending] = useState(false)
  const [linkSent, setLinkSent] = useState(false)

  const handleSendLink = async () => {
    if (!phoneNumber || phoneNumber.length < 10) {
      toast({
        title: "Invalid phone number",
        description: "Please enter a valid phone number.",
        variant: "destructive",
      })
      return
    }

    setIsSending(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    toast({
      title: "Download link sent",
      description: "Check your phone for the app download link.",
    })

    setIsSending(false)
    setLinkSent(true)
  }

  const handleCopyApiKey = () => {
    navigator.clipboard.writeText("sk_live_51NzQpTHKt6rTMjkjhGFDSeret34534534")

    toast({
      title: "API key copied",
      description: "The API key has been copied to your clipboard.",
    })
  }

  const appFeatures = [
    {
      icon: <Bell className="h-8 w-8 text-primary" />,
      title: "Real-time Notifications",
      description: "Get instant alerts for trades, market movements, and account updates.",
    },
    {
      icon: <BarChart className="h-8 w-8 text-primary" />,
      title: "Performance Tracking",
      description: "Monitor your portfolio and copy trading performance on the go.",
    },
    {
      icon: <Smartphone className="h-8 w-8 text-primary" />,
      title: "Mobile Trading",
      description: "Follow traders and manage your copy trading settings from anywhere.",
    },
    {
      icon: <Laptop className="h-8 w-8 text-primary" />,
      title: "Cross-platform Sync",
      description: "Seamlessly switch between desktop and mobile with real-time synchronization.",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold">Mobile App Integration</h2>
        <p className="text-muted-foreground mt-2">Access your copy trading platform on the go</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 max-w-5xl mx-auto">
        <div>
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Download Our Mobile App</CardTitle>
              <CardDescription>Get the full trading experience on your mobile device</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-center">
                <div className="relative w-64 h-64 bg-muted rounded-lg overflow-hidden flex items-center justify-center">
                  <img
                    src="/placeholder.svg?height=256&width=256"
                    alt="Mobile App Screenshot"
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <Smartphone className="h-24 w-24 text-white opacity-75" />
                  </div>
                </div>
              </div>

              <Tabs defaultValue="qrcode">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="qrcode">
                    <QrCode className="mr-2 h-4 w-4" />
                    QR Code
                  </TabsTrigger>
                  <TabsTrigger value="sms">
                    <Send className="mr-2 h-4 w-4" />
                    SMS Link
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="qrcode" className="mt-4 flex justify-center">
                  <div className="bg-white p-4 rounded-lg">
                    <QRCode
                      value="https://copytrading-platform.app/download"
                      size={200}
                      logoImage="/placeholder.svg?height=40&width=40"
                      logoWidth={40}
                      logoHeight={40}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="sms" className="mt-4">
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <label htmlFor="phone" className="text-sm font-medium">
                        Phone Number
                      </label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+1 (555) 123-4567"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                      />
                    </div>

                    <Button className="w-full" onClick={handleSendLink} disabled={isSending || linkSent}>
                      {isSending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Sending...
                        </>
                      ) : linkSent ? (
                        <>
                          <CheckCircle className="mr-2 h-4 w-4" />
                          Link Sent
                        </>
                      ) : (
                        <>
                          <Send className="mr-2 h-4 w-4" />
                          Send Download Link
                        </>
                      )}
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="flex justify-center gap-4">
              <Button variant="outline" className="flex-1">
                <Apple className="mr-2 h-4 w-4" />
                App Store
              </Button>
              <Button variant="outline" className="flex-1">
                <Android className="mr-2 h-4 w-4" />
                Google Play
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Key Features</CardTitle>
              <CardDescription>What you can do with our mobile app</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {appFeatures.map((feature, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="mt-1">{feature.icon}</div>
                    <div>
                      <h3 className="font-medium">{feature.title}</h3>
                      <p className="text-sm text-muted-foreground">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>API Integration</CardTitle>
              <CardDescription>Connect your custom apps to our platform</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm">Use our API to build custom applications or integrate with your existing tools.</p>

              <div className="bg-muted p-3 rounded-md flex items-center justify-between">
                <code className="text-xs font-mono truncate">sk_live_51NzQpTHKt6rTMjkjhGFDSeret34534534</code>
                <Button variant="ghost" size="sm" onClick={handleCopyApiKey}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>

              <p className="text-xs text-muted-foreground">
                This is your private API key. Do not share it with anyone.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View API Documentation
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

