"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, TrendingDown } from "lucide-react"

const stockData = [
  { symbol: "AAPL", name: "Apple Inc.", price: 187.42, change: 1.24, changePercent: 0.67 },
  { symbol: "MSFT", name: "Microsoft Corp.", price: 412.65, change: 3.78, changePercent: 0.92 },
  { symbol: "GOOGL", name: "Alphabet Inc.", price: 142.89, change: -0.56, changePercent: -0.39 },
  { symbol: "AMZN", name: "Amazon.com Inc.", price: 178.12, change: 2.34, changePercent: 1.33 },
  { symbol: "NVDA", name: "NVIDIA Corp.", price: 824.36, change: 12.45, changePercent: 1.53 },
]

const cryptoData = [
  { symbol: "BTC", name: "Bitcoin", price: 62487.23, change: 1245.67, changePercent: 2.03 },
  { symbol: "ETH", name: "Ethereum", price: 3421.56, change: 87.34, changePercent: 2.62 },
  { symbol: "SOL", name: "Solana", price: 142.78, change: -3.45, changePercent: -2.36 },
  { symbol: "ADA", name: "Cardano", price: 0.58, change: 0.02, changePercent: 3.57 },
  { symbol: "DOT", name: "Polkadot", price: 7.23, change: 0.18, changePercent: 2.55 },
]

const forexData = [
  { symbol: "EUR/USD", name: "Euro / US Dollar", price: 1.0842, change: -0.0012, changePercent: -0.11 },
  { symbol: "GBP/USD", name: "British Pound / US Dollar", price: 1.2654, change: 0.0023, changePercent: 0.18 },
  { symbol: "USD/JPY", name: "US Dollar / Japanese Yen", price: 151.23, change: 0.45, changePercent: 0.3 },
  { symbol: "USD/CAD", name: "US Dollar / Canadian Dollar", price: 1.3542, change: -0.0034, changePercent: -0.25 },
  { symbol: "AUD/USD", name: "Australian Dollar / US Dollar", price: 0.6587, change: 0.0021, changePercent: 0.32 },
]

export function MarketInsights() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Market Insights</CardTitle>
        <CardDescription>Real-time market data across multiple asset classes</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="stocks">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="stocks">Stocks</TabsTrigger>
            <TabsTrigger value="crypto">Crypto</TabsTrigger>
            <TabsTrigger value="forex">Forex</TabsTrigger>
          </TabsList>
          <TabsContent value="stocks" className="mt-4">
            <div className="space-y-4">
              {stockData.map((stock) => (
                <div key={stock.symbol} className="flex items-center justify-between border-b pb-2">
                  <div>
                    <div className="font-medium">{stock.symbol}</div>
                    <div className="text-xs text-muted-foreground">{stock.name}</div>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="font-medium">${stock.price.toLocaleString()}</div>
                    <div
                      className={`text-xs flex items-center ${stock.change >= 0 ? "text-green-600" : "text-red-600"}`}
                    >
                      {stock.change >= 0 ? (
                        <>
                          +{stock.change.toLocaleString()} ({stock.changePercent.toFixed(2)}%)
                          <TrendingUp className="ml-1 h-3 w-3" />
                        </>
                      ) : (
                        <>
                          {stock.change.toLocaleString()} ({stock.changePercent.toFixed(2)}%)
                          <TrendingDown className="ml-1 h-3 w-3" />
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="crypto" className="mt-4">
            <div className="space-y-4">
              {cryptoData.map((crypto) => (
                <div key={crypto.symbol} className="flex items-center justify-between border-b pb-2">
                  <div>
                    <div className="font-medium">{crypto.symbol}</div>
                    <div className="text-xs text-muted-foreground">{crypto.name}</div>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="font-medium">
                      ${crypto.price < 1 ? crypto.price.toFixed(4) : crypto.price.toLocaleString()}
                    </div>
                    <div
                      className={`text-xs flex items-center ${crypto.change >= 0 ? "text-green-600" : "text-red-600"}`}
                    >
                      {crypto.change >= 0 ? (
                        <>
                          +{crypto.change.toLocaleString()} ({crypto.changePercent.toFixed(2)}%)
                          <TrendingUp className="ml-1 h-3 w-3" />
                        </>
                      ) : (
                        <>
                          {crypto.change.toLocaleString()} ({crypto.changePercent.toFixed(2)}%)
                          <TrendingDown className="ml-1 h-3 w-3" />
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="forex" className="mt-4">
            <div className="space-y-4">
              {forexData.map((forex) => (
                <div key={forex.symbol} className="flex items-center justify-between border-b pb-2">
                  <div>
                    <div className="font-medium">{forex.symbol}</div>
                    <div className="text-xs text-muted-foreground">{forex.name}</div>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="font-medium">{forex.price.toFixed(4)}</div>
                    <div
                      className={`text-xs flex items-center ${forex.change >= 0 ? "text-green-600" : "text-red-600"}`}
                    >
                      {forex.change >= 0 ? (
                        <>
                          +{forex.change.toFixed(4)} ({forex.changePercent.toFixed(2)}%)
                          <TrendingUp className="ml-1 h-3 w-3" />
                        </>
                      ) : (
                        <>
                          {forex.change.toFixed(4)} ({forex.changePercent.toFixed(2)}%)
                          <TrendingDown className="ml-1 h-3 w-3" />
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

