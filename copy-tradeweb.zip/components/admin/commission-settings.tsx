"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Save, RefreshCw } from "lucide-react"

const commissionSchema = z.object({
  percentageFee: z.coerce.number().min(0, "Percentage must be positive").max(100, "Percentage cannot exceed 100%"),
  fixedFee: z.coerce.number().min(0, "Fixed fee must be positive"),
  minimumFee: z.coerce.number().min(0, "Minimum fee must be positive"),
  enableVolumeDiscounts: z.boolean().default(false),
  tier1Threshold: z.coerce.number().min(0, "Threshold must be positive"),
  tier1Percentage: z.coerce.number().min(0, "Percentage must be positive").max(100, "Percentage cannot exceed 100%"),
  tier2Threshold: z.coerce.number().min(0, "Threshold must be positive"),
  tier2Percentage: z.coerce.number().min(0, "Percentage must be positive").max(100, "Percentage cannot exceed 100%"),
  tier3Threshold: z.coerce.number().min(0, "Threshold must be positive"),
  tier3Percentage: z.coerce.number().min(0, "Percentage must be positive").max(100, "Percentage cannot exceed 100%"),
})

type CommissionFormValues = z.infer<typeof commissionSchema>

export function CommissionSettings() {
  const [isSaving, setIsSaving] = useState(false)

  const defaultValues: CommissionFormValues = {
    percentageFee: 2.5,
    fixedFee: 1.0,
    minimumFee: 0.5,
    enableVolumeDiscounts: true,
    tier1Threshold: 10000,
    tier1Percentage: 2.0,
    tier2Threshold: 50000,
    tier2Percentage: 1.5,
    tier3Threshold: 100000,
    tier3Percentage: 1.0,
  }

  const form = useForm<CommissionFormValues>({
    resolver: zodResolver(commissionSchema),
    defaultValues,
  })

  const onSubmit = async (data: CommissionFormValues) => {
    setIsSaving(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    console.log("Commission settings updated:", data)
    setIsSaving(false)
  }

  const enableVolumeDiscounts = form.watch("enableVolumeDiscounts")

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-bold">Commission Settings</CardTitle>
        <CardDescription>Configure platform commission rates and volume-based discounts</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="standard">
          <TabsList className="mb-4">
            <TabsTrigger value="standard">Standard Fees</TabsTrigger>
            <TabsTrigger value="volume">Volume Discounts</TabsTrigger>
          </TabsList>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <TabsContent value="standard" className="space-y-4">
                <FormField
                  control={form.control}
                  name="percentageFee"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Percentage Fee (%)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.1" {...field} />
                      </FormControl>
                      <FormDescription>Percentage fee applied to each copied trade</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="fixedFee"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fixed Fee (USD)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.1" {...field} />
                      </FormControl>
                      <FormDescription>Fixed fee applied to each copied trade</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="minimumFee"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Minimum Fee (USD)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.1" {...field} />
                      </FormControl>
                      <FormDescription>Minimum fee charged per trade</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>

              <TabsContent value="volume" className="space-y-4">
                <FormField
                  control={form.control}
                  name="enableVolumeDiscounts"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Enable Volume Discounts</FormLabel>
                        <FormDescription>Apply discounted rates based on trading volume</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />

                {enableVolumeDiscounts && (
                  <div className="space-y-4 mt-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="tier1Threshold"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tier 1 Threshold (USD)</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="tier1Percentage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tier 1 Fee (%)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.1" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="tier2Threshold"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tier 2 Threshold (USD)</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="tier2Percentage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tier 2 Fee (%)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.1" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="tier3Threshold"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tier 3 Threshold (USD)</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="tier3Percentage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tier 3 Fee (%)</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.1" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                )}
              </TabsContent>

              <CardFooter className="px-0">
                <Button type="submit" disabled={isSaving}>
                  {isSaving ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Changes
                    </>
                  )}
                </Button>
              </CardFooter>
            </form>
          </Form>
        </Tabs>
      </CardContent>
    </Card>
  )
}

