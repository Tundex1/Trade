"use client"

import type React from "react"

import { useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"
import {
  BarChart3,
  Home,
  Settings,
  Shield,
  Users,
  LayoutDashboard,
  UserCheck,
  DollarSign,
  AlertTriangle,
  Bell,
  FileText,
  HelpCircle,
} from "lucide-react"

interface SidebarItem {
  title: string
  icon: React.ReactNode
  href: string
  badge?: number
  variant?: "default" | "ghost"
}

export function AdminSidebar() {
  const router = useRouter()
  const pathname = usePathname()
  const [expanded, setExpanded] = useState(true)

  const mainItems: SidebarItem[] = [
    {
      title: "Dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
      href: "/admin/dashboard",
      variant: "default",
    },
    {
      title: "Users",
      icon: <Users className="h-5 w-5" />,
      href: "/admin/users",
      badge: 12,
    },
    {
      title: "Traders",
      icon: <UserCheck className="h-5 w-5" />,
      href: "/admin/traders",
      badge: 5,
    },
    {
      title: "Analytics",
      icon: <BarChart3 className="h-5 w-5" />,
      href: "/admin/analytics",
    },
    {
      title: "Commissions",
      icon: <DollarSign className="h-5 w-5" />,
      href: "/admin/commissions",
    },
    {
      title: "Risk Management",
      icon: <AlertTriangle className="h-5 w-5" />,
      href: "/admin/risk",
    },
    {
      title: "Notifications",
      icon: <Bell className="h-5 w-5" />,
      href: "/admin/notifications",
      badge: 3,
    },
    {
      title: "Reports",
      icon: <FileText className="h-5 w-5" />,
      href: "/admin/reports",
    },
  ]

  const bottomItems: SidebarItem[] = [
    {
      title: "Settings",
      icon: <Settings className="h-5 w-5" />,
      href: "/admin/settings",
    },
    {
      title: "Help",
      icon: <HelpCircle className="h-5 w-5" />,
      href: "/admin/help",
    },
    {
      title: "Back to App",
      icon: <Home className="h-5 w-5" />,
      href: "/dashboard",
    },
  ]

  return (
    <aside
      className={cn(
        "fixed inset-y-0 left-0 z-20 flex h-full flex-col border-r bg-background transition-all",
        expanded ? "w-64" : "w-16",
      )}
    >
      <div className="flex h-16 items-center justify-between border-b px-4">
        <div className={cn("flex items-center gap-2", !expanded && "justify-center w-full")}>
          <Shield className="h-6 w-6" />
          {expanded && <span className="font-bold">Admin Panel</span>}
        </div>
        <Button variant="ghost" size="icon" onClick={() => setExpanded(!expanded)} className="hidden md:flex">
          {expanded ? (
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M8.5 4L5.5 7.5L8.5 11" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          ) : (
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M6.5 4L9.5 7.5L6.5 11" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </Button>
      </div>

      <ScrollArea className="flex-1 py-2">
        <nav className="grid gap-1 px-2">
          {mainItems.map((item, index) => {
            const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`)
            const Icon = item.icon

            return (
              <Button
                key={index}
                variant={isActive ? "secondary" : "ghost"}
                className={cn("justify-start", !expanded && "justify-center px-0")}
                onClick={() => router.push(item.href)}
              >
                <Icon className="mr-2 h-4 w-4" />
                {expanded && <span className="ml-2">{item.title}</span>}
                {expanded && item.badge && (
                  <span className="ml-auto flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                    {item.badge}
                  </span>
                )}
                {!expanded && item.badge && (
                  <span className="absolute right-2 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                    {item.badge}
                  </span>
                )}
              </Button>
            )
          })}
        </nav>
      </ScrollArea>

      <div className="grid gap-1 border-t p-2">
        {bottomItems.map((item, index) => (
          <Button
            key={index}
            variant="ghost"
            className={cn("justify-start", !expanded && "justify-center px-0")}
            onClick={() => router.push(item.href)}
          >
            <item.icon className="mr-2 h-4 w-4" />
            {expanded && <span className="ml-2">{item.title}</span>}
          </Button>
        ))}
      </div>
    </aside>
  )
}

