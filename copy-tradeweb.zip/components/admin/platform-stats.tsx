"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Download, RefreshCw } from "lucide-react"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
} from "recharts"

// Sample data for charts
const userActivityData = [
  { name: "Jan", signups: 120, active: 95, traders: 15 },
  { name: "Feb", signups: 140, active: 110, traders: 18 },
  { name: "Mar", signups: 160, active: 130, traders: 22 },
  { name: "Apr", signups: 180, active: 140, traders: 25 },
  { name: "May", signups: 220, active: 170, traders: 30 },
  { name: "Jun", signups: 240, active: 190, traders: 35 },
  { name: "Jul", signups: 280, active: 220, traders: 42 },
  { name: "Aug", signups: 320, active: 250, traders: 48 },
  { name: "Sep", signups: 360, active: 280, traders: 52 },
  { name: "Oct", signups: 400, active: 320, traders: 58 },
  { name: "Nov", signups: 450, active: 350, traders: 65 },
  { name: "Dec", signups: 500, active: 380, traders: 72 },
]

const tradingVolumeData = [
  { name: "Jan", volume: 1.2 },
  { name: "Feb", volume: 1.4 },
  { name: "Mar", volume: 1.6 },
  { name: "Apr", volume: 1.8 },
  { name: "May", volume: 2.2 },
  { name: "Jun", volume: 2.4 },
  { name: "Jul", volume: 2.8 },
  { name: "Aug", volume: 3.2 },
  { name: "Sep", volume: 3.6 },
  { name: "Oct", volume: 4.0 },
  { name: "Nov", volume: 4.5 },
  { name: "Dec", volume: 5.0 },
]

const userTypeData = [
  { name: "Regular Users", value: 2356 },
  { name: "Traders", value: 187 },
  { name: "Premium Users", value: 684 },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28"]

export function PlatformStats() {
  const [timeframe, setTimeframe] = useState("yearly")
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = () => {
    setIsRefreshing(true)
    // Simulate data refresh
    setTimeout(() => {
      setIsRefreshing(false)
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Platform Statistics</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users">User Activity</TabsTrigger>
          <TabsTrigger value="trading">Trading Volume</TabsTrigger>
          <TabsTrigger value="distribution">User Distribution</TabsTrigger>
        </TabsList>

        <div className="mt-4 flex items-center justify-end">
          <Tabs defaultValue={timeframe} onValueChange={(value) => setTimeframe(value)}>
            <TabsList>
              <TabsTrigger value="monthly">Monthly</TabsTrigger>
              <TabsTrigger value="quarterly">Quarterly</TabsTrigger>
              <TabsTrigger value="yearly">Yearly</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <TabsContent value="users" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>User Activity</CardTitle>
              <CardDescription>Track user signups, active users, and traders over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  signups: {
                    label: "Signups",
                    color: "hsl(var(--chart-1))",
                  },
                  active: {
                    label: "Active Users",
                    color: "hsl(var(--chart-2))",
                  },
                  traders: {
                    label: "Traders",
                    color: "hsl(var(--chart-3))",
                  },
                }}
                className="h-[400px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={userActivityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Bar dataKey="signups" fill="var(--color-signups)" />
                    <Bar dataKey="active" fill="var(--color-active)" />
                    <Bar dataKey="traders" fill="var(--color-traders)" />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trading" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Trading Volume</CardTitle>
              <CardDescription>Monthly trading volume in millions of dollars</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  volume: {
                    label: "Volume (Millions $)",
                    color: "hsl(var(--chart-1))",
                  },
                }}
                className="h-[400px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={tradingVolumeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="volume"
                      stroke="var(--color-volume)"
                      strokeWidth={2}
                      dot={{ r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="distribution" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>User Distribution</CardTitle>
              <CardDescription>Breakdown of user types on the platform</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={userTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}\

