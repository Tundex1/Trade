"use client"

import { Popover } from "@/components/ui/popover"

import { PopoverContent } from "@/components/ui/popover"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Search, SlidersHorizontal, X } from "lucide-react"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

interface TraderFiltersProps {
  onFilterChange: (filters: TraderFilters) => void
}

export interface TraderFilters {
  search: string
  markets: string[]
  minReturn: number
  minWinRate: number
  sortBy: string
  verified: boolean
}

const marketOptions = ["Forex", "Crypto", "Stocks", "Commodities", "Indices", "Options"]

export function TraderFilters({ onFilterChange }: TraderFiltersProps) {
  const [filters, setFilters] = useState<TraderFilters>({
    search: "",
    markets: [],
    minReturn: 0,
    minWinRate: 50,
    sortBy: "performance",
    verified: false,
  })

  const [isOpen, setIsOpen] = useState(false)

  const handleFilterChange = (key: keyof TraderFilters, value: string | string[] | number | boolean) => {
    const newFilters = { ...filters, [key]: value }
    setFilters(newFilters)
    onFilterChange(newFilters)
  }

  const toggleMarket = (market: string) => {
    const newMarkets = filters.markets.includes(market)
      ? filters.markets.filter((m) => m !== market)
      : [...filters.markets, market]

    handleFilterChange("markets", newMarkets)
  }

  const clearFilters = () => {
    const resetFilters = {
      search: "",
      markets: [],
      minReturn: 0,
      minWinRate: 50,
      sortBy: "performance",
      verified: false,
    }
    setFilters(resetFilters)
    onFilterChange(resetFilters)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search traders..."
            className="pl-8"
            value={filters.search}
            onChange={(e) => handleFilterChange("search", e.target.value)}
          />
        </div>
        <Select value={filters.sortBy} onValueChange={(value) => handleFilterChange("sortBy", value)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="performance">Best Performance</SelectItem>
            <SelectItem value="followers">Most Followers</SelectItem>
            <SelectItem value="winRate">Highest Win Rate</SelectItem>
          </SelectContent>
        </Select>
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon">
              <SlidersHorizontal className="h-4 w-4" />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Filter Traders</SheetTitle>
              <SheetDescription>Refine your search with advanced filters</SheetDescription>
            </SheetHeader>
            <div className="py-4 space-y-6">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Markets</h3>
                <div className="flex flex-wrap gap-2">
                  {marketOptions.map((market) => (
                    <Badge
                      key={market}
                      variant={filters.markets.includes(market) ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => toggleMarket(market)}
                    >
                      {market}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <h3 className="text-sm font-medium">Minimum Monthly Return</h3>
                  <span className="text-sm">{filters.minReturn}%</span>
                </div>
                <Slider
                  value={[filters.minReturn]}
                  min={-10}
                  max={50}
                  step={1}
                  onValueChange={(value) => handleFilterChange("minReturn", value[0])}
                />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <h3 className="text-sm font-medium">Minimum Win Rate</h3>
                  <span className="text-sm">{filters.minWinRate}%</span>
                </div>
                <Slider
                  value={[filters.minWinRate]}
                  min={0}
                  max={100}
                  step={5}
                  onValueChange={(value) => handleFilterChange("minWinRate", value[0])}
                />
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="verified"
                  checked={filters.verified}
                  onChange={(e) => handleFilterChange("verified", e.target.checked)}
                  className="rounded border-gray-300 text-primary focus:ring-primary"
                />
                <label htmlFor="verified" className="text-sm font-medium">
                  Verified traders only
                </label>
              </div>
              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={clearFilters}>
                  <X className=\
</cut_off_point>
                  mr-2 h-4 w-4" />
                  Clear Filters
                </Button>
                <Button onClick={() => setIsOpen(false)}>Apply Filters</Button>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>
      {filters.markets.length > 0 && (
        <div className="flex flex-wrap gap-1">
          <span className="text-sm text-muted-foreground py-1">Markets:</span>
          {filters.markets.map((market) => (
            <Badge key={market} variant="secondary" className="flex items-center gap-1">
              {market}
              <X className="h-3 w-3 cursor-pointer" onClick={() => toggleMarket(market)} />
            </Badge>
          ))}
        </div>
      )}
    </div>
  )
}

