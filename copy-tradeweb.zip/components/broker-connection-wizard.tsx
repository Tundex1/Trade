"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useBrokerIntegration, type BrokerType, type BrokerConnectionMethod } from "@/lib/broker-integration"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, CheckCircle, AlertCircle, ExternalLink } from "lucide-react"
import Image from "next/image"
import { useNotifications } from "@/lib/notifications"

interface BrokerConnectionWizardProps {
  category: "stocks" | "forex" | "crypto"
}

export function BrokerConnectionWizard({ category }: BrokerConnectionWizardProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { addNotification } = useNotifications()
  const { getBrokersByCategory, connectBroker } = useBrokerIntegration()

  const [selectedBroker, setSelectedBroker] = useState<string | null>(null)
  const [connectionMethod, setConnectionMethod] = useState<BrokerConnectionMethod>("api_key")
  const [step, setStep] = useState(1)
  const [isConnecting, setIsConnecting] = useState(false)
  const [connectionError, setConnectionError] = useState<string | null>(null)
  const [connectionSuccess, setConnectionSuccess] = useState(false)
  const [credentials, setCredentials] = useState({
    apiKey: "",
    secretKey: "",
    passphrase: "",
    username: "",
    password: "",
  })

  const brokers = getBrokersByCategory(category)
  const popularBrokers = brokers.filter((broker) => broker.popular)
  const otherBrokers = brokers.filter((broker) => !broker.popular)

  const selectedBrokerDetails = brokers.find((broker) => broker.id === selectedBroker)

  const handleBrokerSelect = (brokerId: string) => {
    setSelectedBroker(brokerId)
    setStep(2)
    setConnectionMethod(brokers.find((b) => b.id === brokerId)?.connectionMethods[0] || "api_key")
  }

  const handleConnectionMethodChange = (method: BrokerConnectionMethod) => {
    setConnectionMethod(method)
  }

  const handleCredentialChange = (field: string, value: string) => {
    setCredentials((prev) => ({ ...prev, [field]: value }))
  }

  const handleConnect = async () => {
    if (!selectedBroker) return

    setIsConnecting(true)
    setConnectionError(null)

    try {
      // Prepare credentials based on connection method
      const credentialsToSend: any = {}

      if (connectionMethod === "api_key") {
        credentialsToSend.apiKey = credentials.apiKey
        credentialsToSend.secretKey = credentials.secretKey

        if (credentials.passphrase) {
          credentialsToSend.passphrase = credentials.passphrase
        }
      } else if (connectionMethod === "credentials") {
        credentialsToSend.username = credentials.username
        credentialsToSend.password = credentials.password
      }

      const result = await connectBroker(selectedBroker as BrokerType, connectionMethod, credentialsToSend)

      if (result.success) {
        setConnectionSuccess(true)
        setStep(4)

        toast({
          title: "Broker Connected",
          description: `Successfully connected to ${selectedBrokerDetails?.name}`,
        })

        addNotification({
          id: `broker_${Date.now()}`,
          title: "Broker Connected",
          message: `Your ${selectedBrokerDetails?.name} account has been successfully connected.`,
          type: "success",
          read: false,
          date: new Date().toISOString(),
        })

        // Redirect after a short delay
        setTimeout(() => {
          router.push("/dashboard/broker-accounts")
        }, 2000)
      } else {
        setConnectionError(result.error || "Failed to connect. Please check your credentials and try again.")
        setStep(3)
      }
    } catch (error) {
      console.error("Connection error:", error)
      setConnectionError("An unexpected error occurred. Please try again.")
      setStep(3)
    } finally {
      setIsConnecting(false)
    }
  }

  const handleRetry = () => {
    setStep(2)
    setConnectionError(null)
  }

  const renderStep1 = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-2">
          Popular {category.charAt(0).toUpperCase() + category.slice(1)} Brokers
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {popularBrokers.map((broker) => (
            <Card
              key={broker.id}
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedBroker === broker.id ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => handleBrokerSelect(broker.id)}
            >
              <CardContent className="p-4 flex items-center space-x-4">
                <div className="w-12 h-12 relative flex-shrink-0">
                  <div className="w-12 h-12 bg-gray-100 rounded-md flex items-center justify-center">
                    {broker.logo ? (
                      <Image
                        src={broker.logo || "/placeholder.svg"}
                        alt={broker.name}
                        width={40}
                        height={40}
                        className="object-contain"
                      />
                    ) : (
                      <div className="text-lg font-bold">{broker.name.charAt(0)}</div>
                    )}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium">{broker.name}</h4>
                  <p className="text-sm text-muted-foreground">{broker.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {otherBrokers.length > 0 && (
        <div>
          <h3 className="text-lg font-medium mb-2">
            Other {category.charAt(0).toUpperCase() + category.slice(1)} Brokers
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {otherBrokers.map((broker) => (
              <Card
                key={broker.id}
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedBroker === broker.id ? "ring-2 ring-primary" : ""
                }`}
                onClick={() => handleBrokerSelect(broker.id)}
              >
                <CardContent className="p-4 flex items-center space-x-4">
                  <div className="w-12 h-12 relative flex-shrink-0">
                    <div className="w-12 h-12 bg-gray-100 rounded-md flex items-center justify-center">
                      {broker.logo ? (
                        <Image
                          src={broker.logo || "/placeholder.svg"}
                          alt={broker.name}
                          width={40}
                          height={40}
                          className="object-contain"
                        />
                      ) : (
                        <div className="text-lg font-bold">{broker.name.charAt(0)}</div>
                      )}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium">{broker.name}</h4>
                    <p className="text-sm text-muted-foreground">{broker.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  )

  const renderStep2 = () => {
    if (!selectedBrokerDetails) return null

    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gray-100 rounded-md flex items-center justify-center">
            {selectedBrokerDetails.logo ? (
              <Image
                src={selectedBrokerDetails.logo || "/placeholder.svg"}
                alt={selectedBrokerDetails.name}
                width={40}
                height={40}
                className="object-contain"
              />
            ) : (
              <div className="text-lg font-bold">{selectedBrokerDetails.name.charAt(0)}</div>
            )}
          </div>
          <div>
            <h3 className="text-lg font-medium">{selectedBrokerDetails.name}</h3>
            <p className="text-sm text-muted-foreground">{selectedBrokerDetails.description}</p>
          </div>
        </div>

        {selectedBrokerDetails.connectionMethods.length > 1 && (
          <div className="space-y-3">
            <Label>Connection Method</Label>
            <RadioGroup
              value={connectionMethod}
              onValueChange={(value) => handleConnectionMethodChange(value as BrokerConnectionMethod)}
              className="flex flex-col space-y-2"
            >
              {selectedBrokerDetails.connectionMethods.includes("oauth") && (
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="oauth" id="oauth" />
                  <Label htmlFor="oauth" className="font-normal">
                    OAuth (Recommended)
                  </Label>
                </div>
              )}
              {selectedBrokerDetails.connectionMethods.includes("api_key") && (
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="api_key" id="api_key" />
                  <Label htmlFor="api_key" className="font-normal">
                    API Key
                  </Label>
                </div>
              )}
              {selectedBrokerDetails.connectionMethods.includes("credentials") && (
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="credentials" id="credentials" />
                  <Label htmlFor="credentials" className="font-normal">
                    Username & Password
                  </Label>
                </div>
              )}
            </RadioGroup>
          </div>
        )}

        {connectionMethod === "oauth" ? (
          <div className="space-y-4">
            <p className="text-sm">
              You will be redirected to {selectedBrokerDetails.name} to authorize access to your account. No credentials
              are stored on our servers.
            </p>
            <Button onClick={handleConnect} disabled={isConnecting}>
              {isConnecting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  Connect with {selectedBrokerDetails.name}
                  <ExternalLink className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        ) : connectionMethod === "api_key" ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="apiKey">API Key</Label>
              <Input
                id="apiKey"
                value={credentials.apiKey}
                onChange={(e) => handleCredentialChange("apiKey", e.target.value)}
                placeholder="Enter your API key"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="secretKey">Secret Key</Label>
              <Input
                id="secretKey"
                type="password"
                value={credentials.secretKey}
                onChange={(e) => handleCredentialChange("secretKey", e.target.value)}
                placeholder="Enter your secret key"
              />
            </div>
            {category === "crypto" && (
              <div className="space-y-2">
                <Label htmlFor="passphrase">Passphrase (if required)</Label>
                <Input
                  id="passphrase"
                  type="password"
                  value={credentials.passphrase}
                  onChange={(e) => handleCredentialChange("passphrase", e.target.value)}
                  placeholder="Enter your passphrase"
                />
              </div>
            )}
            <div className="pt-2">
              <Button onClick={handleConnect} disabled={isConnecting || !credentials.apiKey || !credentials.secretKey}>
                {isConnecting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  "Connect Account"
                )}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Your API keys are encrypted and securely stored. We recommend using read-only API keys when possible.
              <a
                href={selectedBrokerDetails.apiDocs}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary ml-1 hover:underline"
              >
                Learn how to create API keys
              </a>
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={credentials.username}
                onChange={(e) => handleCredentialChange("username", e.target.value)}
                placeholder="Enter your username"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={credentials.password}
                onChange={(e) => handleCredentialChange("password", e.target.value)}
                placeholder="Enter your password"
              />
            </div>
            <div className="pt-2">
              <Button onClick={handleConnect} disabled={isConnecting || !credentials.username || !credentials.password}>
                {isConnecting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  "Connect Account"
                )}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Your credentials are securely encrypted and never stored in plain text.
            </p>
          </div>
        )}
      </div>
    )
  }

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="flex items-center space-x-4 text-red-600">
        <AlertCircle className="h-8 w-8" />
        <div>
          <h3 className="text-lg font-medium">Connection Failed</h3>
          <p className="text-sm">{connectionError || "Failed to connect to broker. Please try again."}</p>
        </div>
      </div>

      <div className="flex space-x-4">
        <Button onClick={handleRetry}>Try Again</Button>
        <Button variant="outline" onClick={() => setStep(1)}>
          Choose Another Broker
        </Button>
      </div>
    </div>
  )

  const renderStep4 = () => (
    <div className="space-y-6">
      <div className="flex items-center space-x-4 text-green-600">
        <CheckCircle className="h-8 w-8" />
        <div>
          <h3 className="text-lg font-medium">Connection Successful</h3>
          <p className="text-sm">
            Your {selectedBrokerDetails?.name} account has been successfully connected. Redirecting to broker
            accounts...
          </p>
        </div>
      </div>
    </div>
  )

  return (
    <div className="space-y-6">
      {step === 1 && renderStep1()}
      {step === 2 && renderStep2()}
      {step === 3 && renderStep3()}
      {step === 4 && renderStep4()}

      {step > 1 && step < 4 && (
        <div className="flex justify-start">
          <Button variant="ghost" onClick={() => setStep(step - 1)} disabled={isConnecting}>
            Back
          </Button>
        </div>
      )}
    </div>
  )
}

