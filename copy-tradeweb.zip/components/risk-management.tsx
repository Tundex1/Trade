"use client"

import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export function RiskManagement() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [settings, setSettings] = useState({
    maxDailyLoss: 5,
    maxPositionSize: 10,
    stopLossEnabled: true,
    stopLossPercentage: 5,
    takeProfitEnabled: true,
    takeProfitPercentage: 10,
  })

  const handleToggle = (setting: string) => {
    setSettings((prev) => ({ ...prev, [setting]: !prev[setting] }))
  }

  const handleChange = (setting: string, value: number) => {
    setSettings((prev) => ({ ...prev, [setting]: value }))
  }

  const handleSaveSettings = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      try {
        toast({
          title: "Risk settings saved",
          description: "Your risk management settings have been updated successfully.",
        })
      } catch (error) {
        toast({
          title: "Save failed",
          description: "An error occurred while saving your settings. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label>Maximum Daily Loss (%)</Label>
        <div className="flex items-center gap-4">
          <Slider
            value={[settings.maxDailyLoss]}
            min={1}
            max={20}
            step={1}
            onValueChange={(value) => handleChange("maxDailyLoss", value[0])}
            className="flex-1"
          />
          <span className="w-12 text-center">{settings.maxDailyLoss}%</span>
        </div>
        <p className="text-xs text-muted-foreground">
          Trading will be paused if daily losses exceed this percentage of your portfolio.
        </p>
      </div>

      <div className="space-y-2">
        <Label>Maximum Position Size (%)</Label>
        <div className="flex items-center gap-4">
          <Slider
            value={[settings.maxPositionSize]}
            min={1}
            max={25}
            step={1}
            onValueChange={(value) => handleChange("maxPositionSize", value[0])}
            className="flex-1"
          />
          <span className="w-12 text-center">{settings.maxPositionSize}%</span>
        </div>
        <p className="text-xs text-muted-foreground">Maximum size of any single position.</p>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Stop Loss & Take Profit</Label>
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="stop-loss">Automatic Stop Loss</Label>
            <p className="text-sm text-muted-foreground">Automatically set stop loss for all copied trades</p>
          </div>
          <Switch
            id="stop-loss"
            checked={settings.stopLossEnabled}
            onCheckedChange={() => handleToggle("stopLossEnabled")}
          />
        </div>

        {settings.stopLossEnabled && (
          <div className="space-y-2">
            <Label>Stop Loss Percentage (%)</Label>
            <div className="flex items-center gap-4">
              <Slider
                value={[settings.stopLossPercentage]}
                min={1}
                max={20}
                step={1}
                onValueChange={(value) => handleChange("stopLossPercentage", value[0])}
                className="flex-1"
              />
              <span className="w-12 text-center">{settings.stopLossPercentage}%</span>
            </div>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="take-profit">Automatic Take Profit</Label>
            <p className="text-sm text-muted-foreground">Automatically set take profit for all copied trades</p>
          </div>
          <Switch
            id="take-profit"
            checked={settings.takeProfitEnabled}
            onCheckedChange={() => handleToggle("takeProfitEnabled")}
          />
        </div>

        {settings.takeProfitEnabled && (
          <div className="space-y-2">
            <Label>Take Profit Percentage (%)</Label>
            <div className="flex items-center gap-4">
              <Slider
                value={[settings.takeProfitPercentage]}
                min={1}
                max={50}
                step={1}
                onValueChange={(value) => handleChange("takeProfitPercentage", value[0])}
                className="flex-1"
              />
              <span className="w-12 text-center">{settings.takeProfitPercentage}%</span>
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          Save Risk Settings
        </Button>
      </div>
    </div>
  )
}

