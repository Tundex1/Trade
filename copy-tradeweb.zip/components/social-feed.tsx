"use client"

import type React from "react"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertCircle,
  BarChart2,
  BookmarkPlus,
  Copy,
  Flag,
  Heart,
  Loader2,
  MessageSquare,
  MoreHorizontal,
  PenSquare,
  Share2,
  Shield,
  Star,
  TrendingUp,
} from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useAuth } from "@/lib/auth"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/router"

// Post type
type Post = {
  id: string
  author: {
    id: string
    name: string
    username: string
    avatar: string
    isVerified: boolean
    badges: string[]
  }
  content: string
  timestamp: string
  likes: number
  comments: number
  isLiked: boolean
  isSaved: boolean
  attachments?: {
    type: "image" | "chart" | "trade"
    url: string
    caption?: string
  }[]
  tradeDetails?: {
    symbol: string
    type: "buy" | "sell"
    entry: number
    target?: number
    stopLoss?: number
    result?: "win" | "loss" | "open"
    profit?: number
    profitPercentage?: number
  }
}

type Trade = {
  symbol: string
  type: "buy" | "sell"
  entry: number
  target?: number
  stopLoss?: number
  result?: "win" | "loss" | "open"
  profit?: number
  profitPercentage?: number
}

// Sample posts data
const samplePosts: Post[] = [
  {
    id: "1",
    author: {
      id: "user1",
      name: "John Doe",
      username: "johndoe",
      avatar: "/avatars/1.png",
      isVerified: true,
      badges: ["professional_trader", "consistent_performer"],
    },
    content: "Just closed a profitable trade on EUR/USD! #trading #forex",
    timestamp: new Date(Date.now() - 60000).toISOString(),
    likes: 15,
    comments: 5,
    isLiked: false,
    isSaved: false,
    tradeDetails: {
      symbol: "EUR/USD",
      type: "buy",
      entry: 1.105,
      target: 1.108,
      stopLoss: 1.103,
      result: "win",
      profit: 300,
      profitPercentage: 0.27,
    },
  },
  {
    id: "2",
    author: {
      id: "user2",
      name: "Jane Smith",
      username: "janesmith",
      avatar: "/avatars/2.png",
      isVerified: false,
      badges: ["community_contributor"],
    },
    content: "Anyone else watching AAPL today? Seems like it might be a good entry point. #stocks #aapl",
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    likes: 23,
    comments: 8,
    isLiked: true,
    isSaved: true,
    attachments: [
      {
        type: "chart",
        url: "/charts/aapl.png",
        caption: "AAPL stock chart showing potential support level",
      },
    ],
  },
  {
    id: "3",
    author: {
      id: "user3",
      name: "Alice Johnson",
      username: "alicejohnson",
      avatar: "/avatars/3.png",
      isVerified: true,
      badges: ["risk_manager", "market_veteran"],
    },
    content: "Remember to always set stop losses! Just avoided a major loss on my GBP/JPY trade. #riskmanagement",
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    likes: 8,
    comments: 2,
    isLiked: false,
    isSaved: false,
    tradeDetails: {
      symbol: "GBP/JPY",
      type: "sell",
      entry: 184.5,
      stopLoss: 184.7,
      result: "open",
    },
  },
  {
    id: "4",
    author: {
      id: "user4",
      name: "Bob Williams",
      username: "bobwilliams",
      avatar: "/avatars/4.png",
      isVerified: false,
      badges: [],
    },
    content: "New blog post is up! Check out my analysis on the current crypto market trends. [link]",
    timestamp: new Date(Date.now() - 259200000).toISOString(),
    likes: 12,
    comments: 4,
    isLiked: false,
    isSaved: false,
  },
  {
    id: "5",
    author: {
      id: "user5",
      name: "Emily Davis",
      avatar: "/avatars/5.png",
      verified: true,
      role: "trader",
      badges: ["professional_trader", "winning_streak"],
    },
    content: "Long position on BTC looking promising. Let's see where it goes! #btc #cryptocurrency",
    timestamp: "2023-11-21T06:15:00Z",
    likes: 30,
    comments: 10,
    isLiked: true,
    isSaved: true,
  },
]

// Badge mapping
const badgeInfo: Record<string, { icon: React.ReactNode; color: string }> = {
  professional_trader: { icon: <Shield className="h-3 w-3" />, color: "bg-purple-500" },
  consistent_performer: { icon: <TrendingUp className="h-3 w-3" />, color: "bg-green-500" },
  risk_manager: { icon: <Shield className="h-3 w-3" />, color: "bg-blue-500" },
  market_veteran: { icon: <Star className="h-3 w-3" />, color: "bg-orange-500" },
  active_trader: { icon: <BarChart2 className="h-3 w-3" />, color: "bg-purple-500" },
  diversified_trader: { icon: <Copy className="h-3 w-3" />, color: "bg-indigo-500" },
  community_contributor: { icon: <MessageSquare className="h-3 w-3" />, color: "bg-pink-500" },
  winning_streak: { icon: <TrendingUp className="h-3 w-3" />, color: "bg-yellow-500" },
}

export function SocialFeed() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [posts, setPosts] = useState<Post[]>(samplePosts)
  const [newPostContent, setNewPostContent] = useState("")
  const [isPosting, setIsPosting] = useState(false)
  const [activeTab, setActiveTab] = useState("all")
  const router = useRouter()

  const handleLikePost = (postId: string) => {
    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            isLiked: !post.isLiked,
            likes: post.isLiked ? post.likes - 1 : post.likes + 1,
          }
        }
        return post
      }),
    )
  }

  const handleSavePost = (postId: string) => {
    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          const newIsSaved = !post.isSaved

          if (newIsSaved) {
            toast({
              title: "Post saved",
              description: "This post has been added to your saved items.",
            })
          }

          return {
            ...post,
            isSaved: newIsSaved,
          }
        }
        return post
      }),
    )
  }

  const handleSubmitPost = () => {
    if (!newPostContent.trim()) return

    setIsPosting(true)

    // Simulate API call
    setTimeout(() => {
      const newPost: Post = {
        id: `post${Date.now()}`,
        author: {
          id: "currentUser",
          name: "Current User",
          username: "currentuser",
          avatar: "/avatars/default.jpg",
          isVerified: false,
          badges: [],
        },
        content: newPostContent,
        timestamp: new Date().toISOString(),
        likes: 0,
        comments: 0,
        shares: 0,
        liked: false,
      }

      setPosts([newPost, ...posts])
      setNewPostContent("")
      setIsPosting(false)

      toast({
        title: "Post published",
        description: "Your post has been published to the feed.",
      })
    }, 1500)
  }

  const handleViewProfile = (userId: string) => {
    try {
      router.push(`/social/profile/${userId}`)
    } catch (error) {
      toast({
        title: "Navigation error",
        description: "There was a problem navigating to the profile. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleViewComments = (postId: string) => {
    try {
      router.push(`/social/post/${postId}`)
    } catch (error) {
      toast({
        title: "Navigation error",
        description: "There was a problem navigating to the comments. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleCopyTrade = (trade: Trade) => {
    try {
      toast({
        title: "Trade copied",
        description: `${trade.type.toUpperCase()} order for ${trade.symbol} has been added to your copy queue.`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem copying the trade. Please try again.",
        variant: "destructive",
      })
    }
  }

  const formatTimestamp = (timestamp: string) => {
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: true })
    } catch (error) {
      console.error("Error formatting timestamp:", error)
      return "Invalid date"
    }
  }

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab}>
      <TabsList className="mb-4">
        <TabsTrigger value="all">All</TabsTrigger>
        <TabsTrigger value="following">Following</TabsTrigger>
        {user ? <TabsTrigger value="saved">Saved</TabsTrigger> : null}
      </TabsList>
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Avatar>
              <AvatarImage src={user?.image || "/avatars/default.jpg"} alt={user?.name || "Profile"} />
              <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-sm font-semibold">{user?.name || "Guest"}</h2>
              <p className="text-xs text-muted-foreground">@{user?.username || "guest"}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="What's on your mind?"
            value={newPostContent}
            onChange={(e) => setNewPostContent(e.target.value)}
            className="mb-4 resize-none"
          />
          <Button onClick={handleSubmitPost} disabled={isPosting} className="w-full">
            {isPosting ? (
              <>
                Posting...
                <Loader2 className="ml-2 h-4 w-4 animate-spin" />
              </>
            ) : (
              "Post"
            )}
          </Button>
        </CardContent>
      </Card>

      <div className="mt-6 space-y-4">
        {posts.map((post) => (
          <Card key={post.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Avatar onClick={() => handleViewProfile(post.author.id)} className="cursor-pointer">
                    <AvatarImage src={post.author.avatar} alt={post.author.name} />
                    <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-1">
                      <h2
                        className="text-sm font-semibold hover:underline cursor-pointer"
                        onClick={() => handleViewProfile(post.author.id)}
                      >
                        {post.author.name}
                      </h2>
                      {post.author.isVerified && <Badge variant="secondary">Verified</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground">@{post.author.username}</p>
                    <div className="flex space-x-1">
                      {post.author.badges.map((badge) => (
                        <Badge
                          key={badge}
                          className="gap-0 rounded-full px-2 text-[0.6rem] font-bold"
                          color={badgeInfo[badge]?.color}
                        >
                          {badgeInfo[badge]?.icon}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                      <span className="sr-only">Open menu</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <PenSquare className="mr-2 h-4 w-4" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Flag className="mr-2 h-4 w-4" />
                      Report
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <AlertCircle className="mr-2 h-4 w-4" />
                      Block
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent className="break-words">
              <p>{post.content}</p>
              {post.attachments &&
                post.attachments.map((attachment, index) => {
                  if (attachment.type === "image") {
                    return (
                      <div key={index} className="mt-4">
                        <img
                          src={attachment.url || "/placeholder.svg"}
                          alt={attachment.caption}
                          className="rounded-md"
                        />
                        {attachment.caption && (
                          <p className="text-sm text-muted-foreground mt-1">{attachment.caption}</p>
                        )}
                      </div>
                    )
                  }
                  if (attachment.type === "chart") {
                    return (
                      <div key={index} className="mt-4">
                        <img
                          src={attachment.url || "/placeholder.svg"}
                          alt={attachment.caption}
                          className="rounded-md"
                        />
                        {attachment.caption && (
                          <p className="text-sm text-muted-foreground mt-1">{attachment.caption}</p>
                        )}
                      </div>
                    )
                  }
                  return null
                })}

              {post.tradeDetails && (
                <div className="mt-4 rounded-md border p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <h3 className="text-sm font-semibold">{post.tradeDetails.symbol}</h3>
                    <Badge variant="outline">{post.tradeDetails.type.toUpperCase()}</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>Entry: {post.tradeDetails.entry}</div>
                    {post.tradeDetails.target && <div>Target: {post.tradeDetails.target}</div>}
                    {post.tradeDetails.stopLoss && <div>Stop Loss: {post.tradeDetails.stopLoss}</div>}
                    {post.tradeDetails.result && (
                      <div>
                        Result:{" "}
                        <span
                          className={
                            post.tradeDetails.result === "win"
                              ? "text-green-500"
                              : post.tradeDetails.result === "loss"
                                ? "text-red-500"
                                : "text-gray-500"
                          }
                        >
                          {post.tradeDetails.result.toUpperCase()}
                        </span>
                      </div>
                    )}
                    {post.tradeDetails.profit && <div>Profit: {post.tradeDetails.profit}</div>}
                    {post.tradeDetails.profitPercentage && <div>Profit %: {post.tradeDetails.profitPercentage}%</div>}
                  </div>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="mt-3 w-full"
                    onClick={() => handleCopyTrade(post.tradeDetails!)}
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Trade
                  </Button>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="flex space-x-4">
                <Button
                  variant="ghost"
                  className={post.isLiked ? "text-red-500" : ""}
                  onClick={() => handleLikePost(post.id)}
                >
                  {post.isLiked ? <Heart className="h-4 w-4" /> : <Heart className="h-4 w-4" />}
                  <span>{post.likes}</span>
                </Button>
                <Button variant="ghost" onClick={() => handleViewComments(post.id)}>
                  <MessageSquare className="h-4 w-4" />
                  <span>{post.comments}</span>
                </Button>
                <Button variant="ghost">
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
              <Button variant="outline" onClick={() => handleSavePost(post.id)}>
                {post.isSaved ? <BookmarkPlus className="h-4 w-4" /> : <BookmarkPlus className="h-4 w-4" />}
                <span>{post.isSaved ? "Unsave" : "Save"}</span>
              </Button>
            </CardFooter>
            <div className="px-6 py-2 text-xs text-muted-foreground">{formatTimestamp(post.timestamp)}</div>
          </Card>
        ))}
      </div>
    </Tabs>
  )
}

