"use client"

import { ChartTooltip } from "@/components/ui/chart"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import {
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Calendar,
  Download,
  XIcon as XAxis,
  Axis3dIcon as YAxis,
  MapIcon as CartesianGrid,
  InfoIcon as Tooltip,
  StarIcon as Legend,
  ContainerIcon as ResponsiveContainer,
  PieChartIcon as Pie,
  PhoneIcon as Cell,
  RefreshCw,
  TrendingDown,
} from "lucide-react"
import { Area, Bar, ComposedChart, LineChart, PieChart, BarChart } from "recharts"

export function PerformanceDashboard() {
  const [timeframe, setTimeframe] = useState("1m")
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  // Simulate loading data
  useEffect(() => {
    const loadData = async () => {
      try {
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 1000))
      } catch (error) {
        toast({
          title: "Error loading data",
          description: "There was a problem loading performance data. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [timeframe, toast])

  const handleRefresh = async () => {
    try {
      setIsLoading(true)
      // In a real app, this would be an API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Data refreshed",
        description: "Performance data has been updated.",
      })
    } catch (error) {
      toast({
        title: "Error refreshing data",
        description: "There was a problem refreshing the data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleExport = () => {
    try {
      toast({
        title: "Export started",
        description: "Your performance report is being generated and will download shortly.",
      })

      // In a real app, this would trigger a file download
      setTimeout(() => {
        toast({
          title: "Export complete",
          description: "Your performance report has been downloaded.",
        })
      }, 2000)
    } catch (error) {
      toast({
        title: "Export failed",
        description: "There was a problem exporting your data. Please try again.",
        variant: "destructive",
      })
    }
  }

  const performanceChartData = [
    { date: "2023-01-01", value: 100000 },
    { date: "2023-02-01", value: 102000 },
    { date: "2023-03-01", value: 105000 },
    { date: "2023-04-01", value: 103000 },
    { date: "2023-05-01", value: 108000 },
    { date: "2023-06-01", value: 112000 },
    { date: "2023-07-01", value: 115000 },
  ]

  const monthlyReturnsData = [
    { month: "Jan", return: 2.0 },
    { month: "Feb", return: 3.0 },
    { month: "Mar", return: -1.5 },
    { month: "Apr", return: 2.5 },
    { month: "May", return: 4.0 },
    { month: "Jun", return: -0.5 },
    { month: "Jul", return: 1.0 },
  ]

  const allocationData = [
    { name: "Trader A", value: 30 },
    { name: "Trader B", value: 25 },
    { name: "Trader C", value: 45 },
  ]

  const assetAllocationData = [
    { name: "Stocks", value: 40 },
    { name: "Bonds", value: 30 },
    { name: "Crypto", value: 20 },
    { name: "Cash", value: 10 },
  ]

  const drawdownData = [
    { date: "2023-01-01", value: 100000, drawdown: 0 },
    { date: "2023-02-01", value: 102000, drawdown: 0 },
    { date: "2023-03-01", value: 105000, drawdown: 0 },
    { date: "2023-04-01", value: 103000, drawdown: -1.9 },
    { date: "2023-05-01", value: 108000, drawdown: 0 },
    { date: "2023-06-01", value: 112000, drawdown: 0 },
    { date: "2023-07-01", value: 115000, drawdown: 0 },
  ]

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"]

  const ChartTooltipContent = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border rounded-md p-2 shadow-md">
          <p className="font-bold">{`${label}`}</p>
          {payload.map((item, index) => (
            <p key={`item-${index}`} className="text-gray-700">{`${item.name}: ${item.value}`}</p>
          ))}
        </div>
      )
    }

    return null
  }

  const ChartContainer = ({ children }) => {
    return <div className="w-full">{children}</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Performance Dashboard</h2>
          <p className="text-muted-foreground">Comprehensive analysis of your copy trading performance</p>
        </div>

        <div className="flex items-center gap-2">
          <Select defaultValue={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[180px]">
              <Calendar className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1w">1 Week</SelectItem>
              <SelectItem value="1m">1 Month</SelectItem>
              <SelectItem value="3m">3 Months</SelectItem>
              <SelectItem value="6m">6 Months</SelectItem>
              <SelectItem value="1y">1 Year</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon" onClick={handleRefresh} disabled={isLoading}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
            Refresh
          </Button>

          <Button variant="outline" onClick={handleExport} disabled={isLoading}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className={isLoading ? "opacity-60" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Return</CardTitle>
            <LineChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-2">
                <div className="h-6 w-24 bg-muted rounded"></div>
                <div className="h-4 w-16 bg-muted rounded"></div>
              </div>
            ) : (
              <>
                <div className="flex items-baseline space-x-2">
                  <div className="text-2xl font-bold">+18.34%</div>
                  <div className="text-xs text-green-500 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    +2.5%
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">vs. previous period</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className={isLoading ? "opacity-60" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-2">
                <div className="h-6 w-24 bg-muted rounded"></div>
                <div className="h-4 w-16 bg-muted rounded"></div>
              </div>
            ) : (
              <>
                <div className="flex items-baseline space-x-2">
                  <div className="text-2xl font-bold">68.5%</div>
                  <div className="text-xs text-green-500 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    +3.2%
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">137 wins / 63 losses</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className={isLoading ? "opacity-60" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profit Factor</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-2">
                <div className="h-6 w-24 bg-muted rounded"></div>
                <div className="h-4 w-16 bg-muted rounded"></div>
              </div>
            ) : (
              <>
                <div className="flex items-baseline space-x-2">
                  <div className="text-2xl font-bold">2.14</div>
                  <div className="text-xs text-red-500 flex items-center">
                    <ArrowDownRight className="h-3 w-3 mr-1" />
                    -0.3
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Gross profit / Gross loss</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className={isLoading ? "opacity-60" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Max Drawdown</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-2">
                <div className="h-6 w-24 bg-muted rounded"></div>
                <div className="h-4 w-16 bg-muted rounded"></div>
              </div>
            ) : (
              <>
                <div className="flex items-baseline space-x-2">
                  <div className="text-2xl font-bold">-12.7%</div>
                  <div className="text-xs text-green-500 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    +1.8%
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Improved from previous period</p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="returns">Returns</TabsTrigger>
          <TabsTrigger value="allocation">Allocation</TabsTrigger>
          <TabsTrigger value="drawdown">Drawdown</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Portfolio Performance</CardTitle>
              <CardDescription>Your copy trading performance over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={performanceChartData}>
                    <defs>
                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="var(--color-value)" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="var(--color-value)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis
                      dataKey="date"
                      tickFormatter={(value) => {
                        const date = new Date(value)
                        return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
                      }}
                    />
                    <YAxis tickFormatter={(value) => `$${value.toLocaleString()}`} />
                    <Tooltip content={<ChartTooltipContent />} />
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="var(--color-value)"
                      fillOpacity={1}
                      fill="url(#colorValue)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="returns" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Returns</CardTitle>
              <CardDescription>Performance breakdown by month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ChartContainer
                  config={{
                    return: {
                      label: "Monthly Return (%)",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                  className="h-[400px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyReturnsData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="month" />
                      <YAxis tickFormatter={(value) => `${value}%`} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar
                        dataKey="return"
                        fill={(entry) => (entry.return >= 0 ? "var(--color-return)" : "hsl(var(--destructive))")}
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="allocation" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Trader Allocation</CardTitle>
                <CardDescription>Capital allocation by trader</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={allocationData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {allocationData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, "Allocation"]} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Asset Allocation</CardTitle>
                <CardDescription>Capital allocation by asset class</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={assetAllocationData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {assetAllocationData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, "Allocation"]} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="drawdown" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Drawdown Analysis</CardTitle>
              <CardDescription>Historical drawdown periods</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ChartContainer
                  config={{
                    value: {
                      label: "Portfolio Value",
                      color: "hsl(var(--chart-1))",
                    },
                    drawdown: {
                      label: "Drawdown (%)",
                      color: "hsl(var(--destructive))",
                    },
                  }}
                  className="h-[400px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={drawdownData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="date"
                        tickFormatter={(value) => {
                          const date = new Date(value)
                          return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
                        }}
                      />
                      <YAxis yAxisId="left" tickFormatter={(value) => `$${value.toLocaleString()}`} />
                      <YAxis
                        yAxisId="right"
                        orientation="right"
                        tickFormatter={(value) => `${value}%`}
                        domain={[-20, 0]}
                      />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Area
                        yAxisId="left"
                        type="monotone"
                        dataKey="value"
                        stroke="var(--color-value)"
                        fill="var(--color-value)"
                        fillOpacity={0.2}
                      />
                      <Bar yAxisId="right" dataKey="drawdown" fill="var(--color-drawdown)" radius={[4, 4, 0, 0]} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

