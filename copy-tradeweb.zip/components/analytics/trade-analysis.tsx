"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

// Sample trade data
const tradeData = [
  {
    id: "T-1001",
    symbol: "AAPL",
    type: "buy",
    entryDate: "2023-11-15T10:30:00Z",
    exitDate: "2023-11-17T14:45:00Z",
    entryPrice: 187.5,
    exitPrice: 195.0,
    quantity: 10,
    profit: 75.0,
    profitPercentage: 4.0,
    status: "closed",
    market: "stocks",
    strategy: "swing",
    tags: ["tech", "earnings"],
    notes: "Bought before earnings announcement, sold after positive results",
  },
  {
    id: "T-1002",
    symbol: "EUR/USD",
    type: "sell",
    entryDate: "2023-11-10T08:15:00Z",
    exitDate: "2023-11-10T16:30:00Z",
    entryPrice: 1.095,
    exitPrice: 1.092,
    quantity: 1,
    profit: 30.0,
    profitPercentage: 0.27,
    status: "closed",
    market: "forex",
    strategy: "day",
    tags: ["usd-strength", "technical"],
    notes: "Sold on technical breakdown, closed at end of day",
  },
  {
    id: "T-1003",
    symbol: "BTC/USD",
    type: "buy",
    entryDate: "2023-11-05T12:00:00Z",
    exitDate: null,
    entryPrice: 58750.0,
    exitPrice: null,
    quantity: 0.5,
    profit: null,
    profitPercentage: null,
    status: "open",
    market: "crypto",
    strategy: "position",
    tags: ["bitcoin", "institutional"],
    notes: "Long-term position based on institutional adoption",
  },
  {
    id: "T-1004",
    symbol: "TSLA",
    type: "buy",
    entryDate: "2023-10-25T09:45:00Z",
    exitDate: "2023-10-27T15:30:00Z",
    entryPrice: 220.5,
    exitPrice: 207.75,
    quantity: 5,
    profit: -63.75,
    profitPercentage: -5.8,
    status: "closed",
    market: "stocks",
    strategy: "swing",
    tags: ["tech", "ev"],
    notes: "Stopped out after negative market reaction to earnings",
  },
  {
    id: "T-1005",
    symbol: "GBP/JPY",
    type: "buy",
    entryDate: "2023-10-20T03:30:00Z",
    exitDate: "2023-10-20T11:15:00Z",
    entryPrice: 186.5,
    exitPrice: 188.0,
    quantity: 1,
    profit: 150.0,
    profitPercentage: 0.8,
    status: "closed",
    market: "forex",
    strategy: "day",
    tags: ["london-open", "technical"],
    notes: "Bought at London open, sold at resistance level",
  },
  {
    id: "T-1006",
    symbol: "ETH/USD",
    type: "buy",
    entryDate: "2023-10-15T14:20:00Z",
    exitDate: null,
    entryPrice: 2850.0,
    exitPrice: null,
    quantity: 2,
    profit: null,
    profitPercentage: null,
    status: "open",
    market: "crypto",
    strategy: "position",
    tags: ["ethereum", "defi"],
    notes: "Long-term position based on ETH 2.0 developments",
  },
  {
    id: "T-1007",
    symbol: "MSFT",
    type: "buy",
    entryDate: "2023-10-10T10:00:00Z",
    exitDate: "2023-10-18T11:30:00Z",
    entryPrice: 330.25,
    exitPrice: 348.5,
    quantity: 3,
    profit: 54.75,
    profitPercentage: 5.5,
    status: "closed",
    market: "stocks",
    strategy: "swing",
    tags: ["tech", "cloud"],
    notes: "Bought on cloud growth prospects, sold at target",
  },
  {
    id: "T-1008",
    symbol: "USD/JPY",
    type: "sell",
    entryDate: "2023-10-05T20:45:00Z",
    exitDate: "2023-10-06T08:30:00Z",
    entryPrice: 149.8,
    exitPrice: 150.2,
    quantity: 1,
    profit: -40.0,
    profitPercentage: -0.27,
    status: "closed",
    market: "forex",
    strategy: "overnight",
    tags: ["interest-rates", "fundamental"],
    notes: "Sold on interest rate differential, stopped out on news",
  },
  {
    id: "T-1009",
    symbol: "NVDA",
    type: "buy",
    entryDate: "2023-09-28T09:30:00Z",
    exitDate: "2023-10-05T15:45:00Z",
    entryPrice: 430.5,
    exitPrice: 455.25,
    quantity: 2,
    profit: 49.5,
    profitPercentage: 5.7,
    status: "closed",
    market: "stocks",
    strategy: "swing",
    tags: ["tech", "ai", "semiconductor"],
    notes: "Bought on AI growth story, sold at technical resistance",
  },
  {
    id: "T-1010",
    symbol: "SOL/USD",
    type: "buy",
    entryDate: "2023-09-20T11:15:00Z",
    exitDate: "2023-10-02T16:30:00Z",
    entryPrice: 22.5,
    exitPrice: 28.75,
    quantity: 50,
    profit: 312.5,
    profitPercentage: 27.8,
    status: "closed",
    market: "crypto",
    strategy: "swing",
    tags: ["altcoin", "technical"],
    notes: "Bought at support level, sold after significant rally",
  },
]

// Trade analysis data
const analysisData = {
  byMarket: [
    { name: "Stocks", value: 55, profit: 115.5, trades: 4 },
    { name: "Forex", value: 30, profit: 140.0, trades: 3 },
    { name: "Crypto", value: 15, profit: 312.5, trades: 3 },
  ],
  byStrategy: [
    { name: "Swing", value: 60, profit: 427.0, trades: 6 },
    { name: "Day", value: 20, profit: 180.0, trades: 2 },
    { name: "Position", value: 15, profit: 0, trades: 2 },
    { name: "Overnight", value: 5, profit: -40.0, trades: 1 },
  ],
  byDirection: [
    { name: "Long", value: 80, profit: 558.0, trades: 8 },
    { name: "Short", value: 20, profit: -10.0, trades: 2 },
  ],
  byTimeOfDay: [
    { name: "Pre-Market", value: 10, profit: 75.0, trades: 1 },
    { name: "Morning", value: 50, profit: 280.5, trades: 5 },
    { name: "Afternoon", value: 30, profit: 142.5, trades: 3 },
    { name: "Evening", value: 10, profit: 50.0, trades: 1 },
  ],
  byDayOfWeek: [
    { name: "Monday", value: 20, profit: 180.0, trades: 2 },
    { name: "Tuesday", value: 10, profit: -40.0, trades: 1 },
    { name: "Wednesday", value: 30, profit: 115.5, trades: 3 },
    { name: "Thursday", value: 20, profit: 142.5, trades: 2 },
    { name: "Friday", value: 20, profit: 160.0, trades: 2 },
  ],
}

export function TradeAnalysis() {
  const [timeframe, setTimeframe] = useState("all")
  const [page, setPage] = useState(1)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedMarket, setSelectedMarket] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedDirection, setSelectedDirection] = useState("all")

  // Filter trades based on search and filters
  const filteredTrades = tradeData.filter((trade) => {
    // Search filter
    if (
      searchQuery &&
      !trade.symbol.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !trade.id.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    // Market filter
    if (selectedMarket !== "all" && trade.market !== selectedMarket) {
      return false
    }

    // Status filter
    if (selectedStatus !== "all" && trade.status !== selectedStatus) {
      return false
    }

    // Direction filter
    if (selectedDirection !== "all" && trade.type !== selectedDirection) {
      return false
    }

    return true
  })

  // Pagination
  const itemsPerPage = 5
  const totalPages = Math.ceil(filteredTrades.length / itemsPerPage)
  const paginatedTrades = filteredTrades.slice((page - 1) * itemsPerPage, page * itemsPerPage)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Trade History</CardTitle>
        <CardDescription>View and analyze your complete trading history</CardDescription>
      </CardHeader>
      <CardContent>
        <p>Trade analysis content will be displayed here.</p>
      </CardContent>
    </Card>
  )
}

