"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowDownRight, ArrowUpRight } from "lucide-react"

// Sample copy trading data
const copyTradingData = {
  overview: {
    totalProfit: 8750.5,
    profitPercentage: 14.2,
    totalCopiedTrades: 124,
    successfulTrades: 82,
    failedTrades: 42,
    winRate: 66.1,
    averageProfit: 106.71,
    averageLoss: 65.45,
    totalInvestment: 61500.0,
    currentValue: 70250.5,
    totalTraders: 8,
    activeTraders: 5,
    pausedTraders: 3,
    bestTrader: {
      id: "trader1",
      name: "Sarah Johnson",
      profit: 3250.75,
      profitPercentage: 21.5,
      trades: 42,
      winRate: 73.8,
    },
    worstTrader: {
      id: "trader4",
      name: "Michael Chen",
      profit: -450.25,
      profitPercentage: -3.2,
      trades: 18,
      winRate: 44.4,
    },
  },
  traders: [
    {
      id: "trader1",
      name: "Sarah Johnson",
      username: "sarahtrader",
      avatar: "/avatars/sarah.jpg",
      allocation: 25,
      profit: 3250.75,
      profitPercentage: 21.5,
      trades: 42,
      winRate: 73.8,
      status: "active",
      strategy: "Swing Trading",
      markets: ["forex", "stocks"],
      copyingSince: "2023-06-15T10:30:00Z",
    },
    {
      id: "trader2",
      name: "David Rodriguez",
      username: "davidcrypto",
      avatar: "/avatars/david.jpg",
      allocation: 20,
      profit: 2850.5,
      profitPercentage: 18.2,
      trades: 28,
      winRate: 71.4,
      status: "active",
      strategy: "Crypto Momentum",
      markets: ["crypto"],
      copyingSince: "2023-07-22T14:15:00Z",
    },
    {
      id: "trader3",
      name: "Emma Wilson",
      username: "emmatrader",
      avatar: "/avatars/emma.jpg",
      allocation: 15,
      profit: 1450.25,
      profitPercentage: 12.4,
      trades: 22,
      winRate: 68.2,
      status: "active",
      strategy: "Day Trading",
      markets: ["stocks"],
      copyingSince: "2023-08-10T09:45:00Z",
    },
    {
      id: "trader4",
      name: "Michael Chen",
      username: "miketrader",
      avatar: "/avatars/michael.jpg",
      allocation: 10,
      profit: -450.25,
      profitPercentage: -3.2,
      trades: 18,
      winRate: 44.4,
      status: "paused",
      strategy: "Swing Trading",
      markets: ["stocks", "forex"],
      copyingSince: "2023-09-05T11:30:00Z",
    },
    {
      id: "trader5",
      name: "Sophia Lee",
      username: "sophiaforex",
      avatar: "/avatars/sophia.jpg",
      allocation: 15,
      profit: 1850.3,
      profitPercentage: 15.8,
      trades: 32,
      winRate: 65.6,
      status: "active",
      strategy: "Forex Scalping",
      markets: ["forex"],
      copyingSince: "2023-07-30T08:20:00Z",
    },
    {
      id: "trader6",
      name: "James Wilson",
      username: "jamestrader",
      avatar: "/placeholder.svg?height=100&width=100",
      allocation: 5,
      profit: 350.45,
      profitPercentage: 9.0,
      trades: 12,
      winRate: 66.7,
      status: "active",
      strategy: "Value Investing",
      markets: ["stocks"],
      copyingSince: "2023-10-12T15:40:00Z",
    },
    {
      id: "trader7",
      name: "Olivia Brown",
      username: "oliviacrypto",
      avatar: "/placeholder.svg?height=100&width=100",
      allocation: 5,
      profit: -150.5,
      profitPercentage: -3.8,
      trades: 8,
      winRate: 37.5,
      status: "paused",
      strategy: "Crypto Swing",
      markets: ["crypto"],
      copyingSince: "2023-10-25T13:15:00Z",
    },
    {
      id: "trader8",
      name: "Daniel Kim",
      username: "danieltrader",
      avatar: "/placeholder.svg?height=100&width=100",
      allocation: 5,
      profit: -400.0,
      profitPercentage: -10.2,
      trades: 6,
      winRate: 33.3,
      status: "paused",
      strategy: "Options Trading",
      markets: ["stocks"],
      copyingSince: "2023-11-02T10:10:00Z",
    },
  ],
  recentTrades: [
    {
      id: "ct-1001",
      traderId: "trader1",
      traderName: "Sarah Johnson",
      symbol: "EUR/USD",
      type: "buy",
      entryDate: "2023-11-15T10:30:00Z",
      exitDate: "2023-11-15T16:45:00Z",
      entryPrice: 1.095,
      exitPrice: 1.098,
      profit: 30.0,
      profitPercentage: 0.27,
      status: "closed",
    },
    {
      id: "ct-1002",
      traderId: "trader2",
      traderName: "David Rodriguez",
      symbol: "BTC/USD",
      type: "buy",
      entryDate: "2023-11-14T14:15:00Z",
      exitDate: "2023-11-16T09:30:00Z",
      entryPrice: 35750.0,
      exitPrice: 36250.0,
      profit: 125.0,
      profitPercentage: 1.4,
      status: "closed",
    },
    {
      id: "ct-1003",
      traderId: "trader3",
      traderName: "Emma Wilson",
      symbol: "AAPL",
      type: "buy",
      entryDate: "2023-11-13T09:45:00Z",
      exitDate: "2023-11-14T15:30:00Z",
      entryPrice: 187.5,
      exitPrice: 185.75,
      profit: -35.0,
      profitPercentage: -0.93,
      status: "closed",
    },
    {
      id: "ct-1004",
      traderId: "trader5",
      traderName: "Sophia Lee",
      symbol: "GBP/JPY",
      type: "sell",
      entryDate: "2023-11-12T08:20:00Z",
      exitDate: "2023-11-12T15:45:00Z",
      entryPrice: 186.5,
      exitPrice: 185.8,
      profit: 70.0,
      profitPercentage: 0.38,
      status: "closed",
    },
    {
      id: "ct-1005",
      traderId: "trader1",
      traderName: "Sarah Johnson",
      symbol: "USD/CAD",
      type: "sell",
      entryDate: "2023-11-10T11:30:00Z",
      exitDate: null,
      entryPrice: 1.372,
      exitPrice: null,
      profit: null,
      profitPercentage: null,
      status: "open",
    },
  ],
  monthlyPerformance: [
    { month: "Jan", profit: 850.5, profitPercentage: 1.4 },
    { month: "Feb", profit: 1250.25, profitPercentage: 2.0 },
    { month: "Mar", profit: -450.4, profitPercentage: -0.7 },
    { month: "Apr", profit: 1450.8, profitPercentage: 2.3 },
    { month: "May", profit: 950.3, profitPercentage: 1.5 },
    { month: "Jun", profit: 650.75, profitPercentage: 1.0 },
    { month: "Jul", profit: -250.25, profitPercentage: -0.4 },
    { month: "Aug", profit: 1250.4, profitPercentage: 1.9 },
    { month: "Sep", profit: 1650.6, profitPercentage: 2.5 },
    { month: "Oct", profit: 750.2, profitPercentage: 1.1 },
    { month: "Nov", profit: 1150.35, profitPercentage: 1.7 },
    { month: "Dec", profit: -550.75, profitPercentage: -0.8 },
  ],
}

export function CopyTradingAnalytics() {
  const [timeframe, setTimeframe] = useState("all")

  return (
    <Card>
      <CardHeader>
        <CardTitle>Copy Trading Analytics</CardTitle>
        <CardDescription>View your copy trading performance and allocation</CardDescription>
      </CardHeader>
      <CardContent>
        <p>Copy trading analytics content will be displayed here.</p>
      </CardContent>
    </Card>
  )
}

function MetricCard({
  title,
  value,
  change,
  icon,
  positive,
  invertColor = false,
}: {
  title: string
  value: string
  change: number
  icon: React.ReactNode
  positive: boolean
  invertColor?: boolean
}) {
  // If invertColor is true, we flip the color logic
  const colorPositive = invertColor ? !positive : positive

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className={`p-2 rounded-full ${colorPositive ? "bg-green-100" : "bg-red-100"}`}>{icon}</div>
          <Badge
            variant="outline"
            className={`${colorPositive ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
          >
            {change > 0 ? <ArrowUpRight className="mr-1 h-3 w-3" /> : <ArrowDownRight className="mr-1 h-3 w-3" />}
            {Math.abs(change).toFixed(1)}%
          </Badge>
        </div>
        <div className="mt-4">
          <p className="text-sm text-muted-foreground">{title}</p>
          <h3 className="text-2xl font-bold">{value}</h3>
        </div>
      </CardContent>
    </Card>
  )
}

