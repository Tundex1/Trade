# Broker Logos

This directory contains logos for all supported brokers in the CopyTradeweb platform.

## Supported Brokers

### Stock Brokers
- Charles Schwab
- Interactive Brokers
- TD Ameritrade
- Robinhood
- E*TRADE
- Webull
- Fidelity
- TradeStation
- Alpaca

### Forex Brokers
- OANDA
- FXTM
- IC Markets
- XM
- Pepperstone
- Exness
- Forex.com
- RoboForex

### Crypto Exchanges
- Binance
- Coinbase
- Kraken
- KuCoin
- Bitfinex
- Gemini
- Bybit

