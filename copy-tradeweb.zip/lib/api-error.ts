export class ApiError extends Error {
  public readonly statusCode: number
  public readonly isOperational: boolean

  constructor(statusCode: number, message: string, isOperational = true, stack = "") {
    super(message)
    this.statusCode = statusCode
    this.isOperational = isOperational

    if (stack) {
      this.stack = stack
    } else {
      Error.captureStackTrace(this, this.constructor)
    }
  }
}

export const handleApiError = (error: unknown) => {
  if (error instanceof ApiError) {
    return {
      statusCode: error.statusCode,
      message: error.message,
      isOperational: error.isOperational,
    }
  }

  // For unexpected errors
  console.error("Unexpected error:", error)

  return {
    statusCode: 500,
    message: "An unexpected error occurred",
    isOperational: false,
  }
}

export const createApiResponse = (data: any, statusCode = 200) => {
  return {
    success: true,
    statusCode,
    data,
  }
}

export const createApiError = (message: string, statusCode = 400) => {
  return {
    success: false,
    statusCode,
    error: message,
  }
}

