"\"use client"

// This is a mock email service for demonstration purposes
// In a production environment, you would integrate with a real email service like SendGrid, Mailgun, etc.

export interface EmailOptions {
  to: string
  subject: string
  text: string
  html?: string
}

export async function sendEmail(options: EmailOptions): Promise<{ success: boolean; error?: string }> {
  // In a real app, this would send an actual email
  console.log("Sending email:", options)

  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      // Simulate successful email sending
      resolve({ success: true })
    }, 500)
  })
}

export async function sendTradeNotificationEmail(
  email: string,
  traderName: string,
  symbol: string,
  action: string,
  quantity: number,
  price: number,
): Promise<{ success: boolean; error?: string }> {
  const subject = `Trade Copied: ${action.toUpperCase()} ${quantity} ${symbol}`

  const text = `
    A trade has been copied to your account.
    
    Trader: ${traderName}
    Action: ${action.toUpperCase()}
    Symbol: ${symbol}
    Quantity: ${quantity}
    Price: $${price.toFixed(2)}
    Total: $${(quantity * price).toFixed(2)}
    
    Log in to your account to view more details.
  `

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #333;">Trade Copied</h2>
      <p>A trade has been copied to your account.</p>
      
      <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
        <tr style="background-color: #f8f9fa;">
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Trader</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd;">${traderName}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Action</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd; color: ${action === "buy" ? "green" : "red"};">
            ${action.toUpperCase()}
          </td>
        </tr>
        <tr style="background-color: #f8f9fa;">
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Symbol</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd;">${symbol}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Quantity</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd;">${quantity}</td>
        </tr>
        <tr style="background-color: #f8f9fa;">
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Price</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd;">$${price.toFixed(2)}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Total</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd;">$${(quantity * price).toFixed(2)}</td>
        </tr>
      </table>
      
      <p>
        <a href="https://your-platform-url.com/dashboard" 
           style="background-color: #0070f3; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;">
          View Details
        </a>
      </p>
      
      <p style="color: #666; font-size: 12px; margin-top: 30px;">
        This is an automated message. Please do not reply to this email.
      </p>
    </div>
  `

  return sendEmail({
    to: email,
    subject,
    text,
    html,
  })
}

export async function trackLoginActivity(
  user: any,
  ipAddress: string,
  userAgent: string,
): Promise<{ success: boolean; error?: string }> {
  const subject = "New Login Alert"
  const text = `
    A new login has been detected on your account.
    
    Time: ${new Date().toLocaleString()}
    IP Address: ${ipAddress}
    Device: ${userAgent}
    
    If this was not you, please contact support immediately.
  `

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #333;">New Login Alert</h2>
      <p>A new login has been detected on your account.</p>
      
      <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
        <tr style="background-color: #f8f9fa;">
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Time</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd;">${new Date().toLocaleString()}</td>
        </tr>
        <tr>
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>IP Address</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd;">${ipAddress}</td>
        </tr>
        <tr style="background-color: #f8f9fa;">
          <td style="padding: 10px; border: 1px solid #ddd;"><strong>Device</strong></td>
          <td style="padding: 10px; border: 1px solid #ddd;">${userAgent}</td>
        </tr>
      </table>
      
      <p>
        <a href="https://your-platform-url.com/dashboard" 
           style="background-color: #0070f3; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;">
          View Activity
        </a>
      </p>
      
      <p style="color: #666; font-size: 12px; margin-top: 30px;">
        If this was not you, please contact support immediately.
      </p>
    </div>
  `

  return sendEmail({
    to: user.email,
    subject,
    text,
    html,
  })
}
\
"

