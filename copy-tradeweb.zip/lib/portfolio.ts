import { create } from "zustand"
import { persist } from "zustand/middleware"

export type Position = {
  id: string
  symbol: string
  name: string
  type: "stock" | "crypto" | "forex"
  entryPrice: number
  currentPrice: number
  quantity: number
  openDate: string
  traderId?: string
  traderName?: string
}

export type Trade = {
  id: string
  symbol: string
  name: string
  type: "BUY" | "SELL"
  price: number
  quantity: number
  total: number
  date: string
  status: "executed" | "pending" | "canceled"
  traderId?: string
  traderName?: string
}

type PortfolioState = {
  positions: Position[]
  trades: Trade[]
  balance: number
  addPosition: (position: Position) => void
  removePosition: (id: string) => void
  updatePosition: (id: string, updates: Partial<Position>) => void
  addTrade: (trade: Trade) => void
  updateBalance: (amount: number) => void
}

// Mock initial data
const initialPositions: Position[] = [
  {
    id: "1",
    symbol: "AAPL",
    name: "Apple Inc.",
    type: "stock",
    entryPrice: 187.42,
    currentPrice: 192.65,
    quantity: 10,
    openDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    traderId: "1",
    traderName: "Alex Morgan",
  },
  {
    id: "2",
    symbol: "BTC",
    name: "Bitcoin",
    type: "crypto",
    entryPrice: 60487.23,
    currentPrice: 62487.23,
    quantity: 0.05,
    openDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
    traderId: "3",
    traderName: "Michael Johnson",
  },
]

const initialTrades: Trade[] = [
  {
    id: "1",
    symbol: "AAPL",
    name: "Apple Inc.",
    type: "BUY",
    price: 187.42,
    quantity: 10,
    total: 1874.2,
    date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    status: "executed",
    traderId: "1",
    traderName: "Alex Morgan",
  },
  {
    id: "2",
    symbol: "BTC",
    name: "Bitcoin",
    type: "BUY",
    price: 60487.23,
    quantity: 0.05,
    total: 3024.36,
    date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
    status: "executed",
    traderId: "3",
    traderName: "Michael Johnson",
  },
  {
    id: "3",
    symbol: "MSFT",
    name: "Microsoft Corp.",
    type: "SELL",
    price: 412.65,
    quantity: 5,
    total: 2063.25,
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    status: "executed",
    traderId: "2",
    traderName: "Sarah Chen",
  },
]

export const usePortfolio = create<PortfolioState>()(
  persist(
    (set) => ({
      positions: initialPositions,
      trades: initialTrades,
      balance: 24892,
      addPosition: (position) =>
        set((state) => ({
          positions: [...state.positions, position],
          balance: state.balance - position.entryPrice * position.quantity,
        })),
      removePosition: (id) =>
        set((state) => {
          const position = state.positions.find((p) => p.id === id)
          if (!position) return state

          const proceeds = position.currentPrice * position.quantity

          return {
            positions: state.positions.filter((p) => p.id !== id),
            balance: state.balance + proceeds,
          }
        }),
      updatePosition: (id, updates) =>
        set((state) => ({
          positions: state.positions.map((p) => (p.id === id ? { ...p, ...updates } : p)),
        })),
      addTrade: (trade) =>
        set((state) => ({
          trades: [trade, ...state.trades],
        })),
      updateBalance: (amount) =>
        set((state) => ({
          balance: state.balance + amount,
        })),
    }),
    {
      name: "portfolio-storage",
    },
  ),
)

