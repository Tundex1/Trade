"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { OnboardingWizard } from "@/components/onboarding/onboarding-wizard"
import { useAuth } from "@/lib/auth"

export default function OnboardingPage() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()

  useEffect(() => {
    // Redirect to login if not authenticated
    if (!isAuthenticated) {
      router.push("/auth/login?redirect=/onboarding")
    }

    // Redirect to dashboard if already onboarded
    if (user?.onboardingComplete) {
      router.push("/dashboard")
    }
  }, [isAuthenticated, user, router])

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-muted/20">
      <OnboardingWizard />
    </div>
  )
}

