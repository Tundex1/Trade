import NextAuth, { type NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import GoogleProvider from "next-auth/providers/google"
import { compare } from "bcrypt"
import { PrismaAdapter } from "@auth/prisma-adapter"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID as string,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET as string,
    }),
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        const user = await prisma.user.findUnique({
          where: {
            email: credentials.email,
          },
        })

        if (!user || !user.password) {
          return null
        }

        const isPasswordValid = await compare(credentials.password, user.password)

        if (!isPasswordValid) {
          return null
        }

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user, account }) {
      if (user) {
        token.id = user.id
        token.role = user.role
      }

      // If this is a Google sign-in, create or update user settings
      if (account?.provider === "google") {
        const existingUser = await prisma.user.findUnique({
          where: { email: token.email as string },
          include: { userSettings: true, copyTradingSettings: true },
        })

        // Create default settings if they don't exist
        if (existingUser && !existingUser.userSettings) {
          await prisma.userSettings.create({
            data: {
              userId: existingUser.id,
              theme: "system",
              language: "en",
              currency: "USD",
              emailNotifications: true,
              pushNotifications: true,
              smsNotifications: false,
            },
          })
        }

        if (existingUser && !existingUser.copyTradingSettings) {
          await prisma.copyTradingSettings.create({
            data: {
              userId: existingUser.id,
              isEnabled: false,
              maxDailyLoss: 5,
              maxPositionSize: 10,
              stopLossEnabled: true,
              stopLossPercentage: 5,
              takeProfitEnabled: true,
              takeProfitPercentage: 10,
              traderAllocations: {
                create: [
                  { traderId: 1, allocation: 50 },
                  { traderId: 2, allocation: 30 },
                  { traderId: 3, allocation: 20 },
                ],
              },
            },
          })
        }
      }

      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string
        session.user.role = token.role as string
      }
      return session
    },
    async signIn({ user, account, profile }) {
      // For Google sign-in, ensure the user exists in the database
      if (account?.provider === "google" && profile?.email) {
        const existingUser = await prisma.user.findUnique({
          where: { email: profile.email },
        })

        if (!existingUser) {
          // Create a new user for Google sign-in
          await prisma.user.create({
            data: {
              email: profile.email,
              name: profile.name || "Google User",
              role: "user",
              userSettings: {
                create: {
                  theme: "system",
                  language: "en",
                  currency: "USD",
                  emailNotifications: true,
                  pushNotifications: true,
                  smsNotifications: false,
                },
              },
              copyTradingSettings: {
                create: {
                  isEnabled: false,
                  maxDailyLoss: 5,
                  maxPositionSize: 10,
                  stopLossEnabled: true,
                  stopLossPercentage: 5,
                  takeProfitEnabled: true,
                  takeProfitPercentage: 10,
                  traderAllocations: {
                    create: [
                      { traderId: 1, allocation: 50 },
                      { traderId: 2, allocation: 30 },
                      { traderId: 3, allocation: 20 },
                    ],
                  },
                },
              },
            },
          })
        }
      }

      return true
    },
  },
  pages: {
    signIn: "/login",
    signOut: "/login",
    error: "/login",
  },
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  secret: process.env.NEXTAUTH_SECRET,
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }

