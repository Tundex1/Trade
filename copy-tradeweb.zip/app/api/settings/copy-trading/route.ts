import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = session.user.id as string

    // Fetch copy trading settings from database
    const copyTradingSettings = await prisma.copyTradingSettings.findUnique({
      where: {
        userId,
      },
      include: {
        traderAllocations: true,
      },
    })

    if (!copyTradingSettings) {
      return NextResponse.json({
        isEnabled: false,
        maxDailyLoss: 5,
        maxPositionSize: 10,
        stopLossEnabled: true,
        stopLossPercentage: 5,
        takeProfitEnabled: true,
        takeProfitPercentage: 10,
        autoCloseEnabled: false,
        autoCloseThreshold: 20,
        volatilityProtection: false,
        volatilityThreshold: 30,
        correlationProtection: false,
        correlationThreshold: 80,
        traderAllocations: [],
      })
    }

    const settings = {
      isEnabled: copyTradingSettings.isEnabled,
      maxDailyLoss: copyTradingSettings.maxDailyLoss,
      maxPositionSize: copyTradingSettings.maxPositionSize,
      stopLossEnabled: copyTradingSettings.stopLossEnabled,
      stopLossPercentage: copyTradingSettings.stopLossPercentage,
      takeProfitEnabled: copyTradingSettings.takeProfitEnabled,
      takeProfitPercentage: copyTradingSettings.takeProfitPercentage,
      autoCloseEnabled: copyTradingSettings.autoCloseEnabled,
      autoCloseThreshold: copyTradingSettings.autoCloseThreshold,
      volatilityProtection: copyTradingSettings.volatilityProtection,
      volatilityThreshold: copyTradingSettings.volatilityThreshold,
      correlationProtection: copyTradingSettings.correlationProtection,
      correlationThreshold: copyTradingSettings.correlationThreshold,
      traderAllocations: copyTradingSettings.traderAllocations.map((allocation) => ({
        traderId: allocation.traderId,
        allocation: allocation.allocation,
      })),
    }

    return NextResponse.json(settings)
  } catch (error) {
    console.error("Error fetching copy trading settings:", error)
    return NextResponse.json({ error: "Failed to fetch copy trading settings" }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userId = session.user.id as string
    const data = await req.json()

    // Validate the data
    if (!data) {
      return NextResponse.json({ error: "Invalid request body" }, { status: 400 })
    }

    const { traderAllocations, ...settings } = data

    // Update or create copy trading settings
    const copyTradingSettings = await prisma.copyTradingSettings.upsert({
      where: {
        userId,
      },
      update: {
        ...settings,
        traderAllocations: {
          upsert: traderAllocations.map((allocation: any) => ({
            where: {
              traderId_copyTradingSettingsId: {
                traderId: allocation.traderId,
                copyTradingSettingsId: userId,
              },
            },
            update: {
              allocation: allocation.allocation,
            },
            create: {
              traderId: allocation.traderId,
              allocation: allocation.allocation,
            },
          })),
        },
        updatedAt: new Date(),
      },
      create: {
        userId,
        ...settings,
        traderAllocations: {
          create: traderAllocations.map((allocation: any) => ({
            traderId: allocation.traderId,
            allocation: allocation.allocation,
          })),
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    })

    return NextResponse.json({
      message: "Copy trading settings saved successfully",
      data: copyTradingSettings,
    })
  } catch (error) {
    console.error("Error saving copy trading settings:", error)
    return NextResponse.json({ error: "Failed to save copy trading settings" }, { status: 500 })
  }
}

