import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CopyTradingSettings } from "@/components/copy-trading-settings"
import { RiskManagement } from "@/components/risk-management"
import { AutomationRules } from "@/components/automation-rules"
import { TraderAllocation } from "@/components/trader-allocation"

export default function CopyTradingSettingsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Copy Trading Settings</h1>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="risk">Risk Management</TabsTrigger>
          <TabsTrigger value="allocation">Trader Allocation</TabsTrigger>
          <TabsTrigger value="automation">Automation Rules</TabsTrigger>
        </TabsList>
        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Copy Trading Settings</CardTitle>
              <CardDescription>Configure your general copy trading preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <CopyTradingSettings />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="risk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Risk Management</CardTitle>
              <CardDescription>Configure risk parameters for copy trading</CardDescription>
            </CardHeader>
            <CardContent>
              <RiskManagement />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="allocation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Trader Allocation</CardTitle>
              <CardDescription>Configure how your capital is allocated among traders</CardDescription>
            </CardHeader>
            <CardContent>
              <TraderAllocation />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="automation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Automation Rules</CardTitle>
              <CardDescription>Set up automated rules for copy trading</CardDescription>
            </CardHeader>
            <CardContent>
              <AutomationRules />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

