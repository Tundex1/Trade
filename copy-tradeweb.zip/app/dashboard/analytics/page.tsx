"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PerformanceMetrics } from "@/components/analytics/performance-metrics"
import { TradeAnalysis } from "@/components/analytics/trade-analysis"
import { CopyTradingAnalytics } from "@/components/analytics/copy-trading-analytics"
import { BarChart3, LineChart, Users } from "lucide-react"

export default function AnalyticsPage() {
  return (
    <div className="container mx-auto py-6">
      <Tabs defaultValue="performance">
        <TabsList className="mb-6">
          <TabsTrigger value="performance" className="flex items-center">
            <BarChart3 className="mr-2 h-4 w-4" />
            Performance Metrics
          </TabsTrigger>
          <TabsTrigger value="trades" className="flex items-center">
            <LineChart className="mr-2 h-4 w-4" />
            Trade Analysis
          </TabsTrigger>
          <TabsTrigger value="copyTrading" className="flex items-center">
            <Users className="mr-2 h-4 w-4" />
            Copy Trading Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="performance">
          <PerformanceMetrics />
        </TabsContent>

        <TabsContent value="trades">
          <TradeAnalysis />
        </TabsContent>

        <TabsContent value="copyTrading">
          <CopyTradingAnalytics />
        </TabsContent>
      </Tabs>
    </div>
  )
}

