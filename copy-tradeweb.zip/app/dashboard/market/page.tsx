import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { MarketTable } from "@/components/market-table"
import { MarketWatchlist } from "@/components/market-watchlist"
import { Search } from "lucide-react"

export default function MarketPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Market</h1>
        <div className="relative w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search markets..." className="pl-8" />
        </div>
      </div>

      <Tabs defaultValue="stocks" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="stocks">Stocks</TabsTrigger>
          <TabsTrigger value="crypto">Crypto</TabsTrigger>
          <TabsTrigger value="forex">Forex</TabsTrigger>
          <TabsTrigger value="watchlist">My Watchlist</TabsTrigger>
        </TabsList>
        <TabsContent value="stocks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Stock Market</CardTitle>
              <CardDescription>Real-time stock prices and trading opportunities</CardDescription>
            </CardHeader>
            <CardContent>
              <MarketTable type="stocks" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="crypto" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Cryptocurrency Market</CardTitle>
              <CardDescription>Real-time cryptocurrency prices and trading opportunities</CardDescription>
            </CardHeader>
            <CardContent>
              <MarketTable type="crypto" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="forex" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Forex Market</CardTitle>
              <CardDescription>Real-time forex prices and trading opportunities</CardDescription>
            </CardHeader>
            <CardContent>
              <MarketTable type="forex" />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="watchlist" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>My Watchlist</CardTitle>
              <CardDescription>Your personalized list of assets to track</CardDescription>
            </CardHeader>
            <CardContent>
              <MarketWatchlist />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

