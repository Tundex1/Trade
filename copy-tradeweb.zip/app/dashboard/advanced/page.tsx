"use client"

import { useEffect, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { AdvancedRiskControls } from "@/components/risk-management/advanced-risk-controls"
import { SocialTradingFeed } from "@/components/social/social-trading-feed"
import { PerformanceDashboard } from "@/components/analytics/performance-dashboard"
import { StatusDashboard } from "@/components/status-dashboard"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"

export default function AdvancedFeaturesPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const tabParam = searchParams.get("tab")
  const [activeTab, setActiveTab] = useState("risk")

  // Set the active tab based on URL parameter
  useEffect(() => {
    if (tabParam && ["risk", "social", "performance", "status"].includes(tabParam)) {
      setActiveTab(tabParam)
    }
  }, [tabParam])

  // Update URL when tab changes
  const handleTabChange = (value: string) => {
    setActiveTab(value)
    router.push(`/dashboard/advanced?tab=${value}`, { scroll: false })
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col gap-1 mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Advanced Features</h1>
        <p className="text-muted-foreground">
          Access advanced risk management, social trading, performance analytics, and system status
        </p>
      </div>

      <Separator className="my-6" />

      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-8">
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="risk">Risk Management</TabsTrigger>
          <TabsTrigger value="social">Social Trading</TabsTrigger>
          <TabsTrigger value="performance">Performance Analytics</TabsTrigger>
          <TabsTrigger value="status">System Status</TabsTrigger>
        </TabsList>

        <TabsContent value="risk">
          <AdvancedRiskControls />
        </TabsContent>

        <TabsContent value="social">
          <SocialTradingFeed />
        </TabsContent>

        <TabsContent value="performance">
          <PerformanceDashboard />
        </TabsContent>

        <TabsContent value="status">
          <StatusDashboard />
        </TabsContent>
      </Tabs>
    </div>
  )
}

