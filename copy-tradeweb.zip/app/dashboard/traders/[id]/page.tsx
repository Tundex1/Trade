"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { TraderPerformance } from "@/components/trader-performance"
import { TraderTrades } from "@/components/trader-trades"
import { TraderRiskAnalysis } from "@/components/trader-risk-analysis"
import { ArrowLeft, Star, StarOff, Copy, TrendingUp } from "lucide-react"
import Link from "next/link"
import { useTraders, type Trader } from "@/lib/traders"
import { useToast } from "@/components/ui/use-toast"

// Extended trader data with additional fields
interface ExtendedTraderData extends Trader {
  bio: string
  roi: {
    "1m": number
    "3m": number
    "6m": number
    "1y": number
    all: number
  }
  avgHoldingTime: string
  profitFactor: number
  maxDrawdown: number
  specialties: string[]
  performance: {
    monthly: {
      month: string
      return: number
    }[]
  }
}

// This would normally come from a database or API
const getExtendedTraderData = (trader: Trader | undefined): ExtendedTraderData | null => {
  if (!trader) return null

  return {
    ...trader,
    bio: "Professional trader with 8+ years of experience in stocks, ETFs, and forex. Specializing in momentum trading and swing strategies.",
    roi: {
      "1m": trader.roi,
      "3m": trader.roi * 2.4,
      "6m": trader.roi * 3.5,
      "1y": trader.roi * 5.8,
      all: trader.roi * 10.6,
    },
    avgHoldingTime: "3.2 days",
    profitFactor: 2.8,
    maxDrawdown: 12.4,
    specialties: ["Momentum", "Swing Trading", "Tech Stocks"],
    performance: {
      monthly: [
        { month: "Jan", return: 4.2 },
        { month: "Feb", return: 3.8 },
        { month: "Mar", return: -1.2 },
        { month: "Apr", return: 5.6 },
        { month: "May", return: 2.9 },
        { month: "Jun", return: 4.1 },
        { month: "Jul", return: 3.5 },
        { month: "Aug", return: -0.8 },
        { month: "Sep", return: 6.2 },
        { month: "Oct", return: 4.1 },
      ],
    },
  }
}

export default function TraderProfilePage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { getTrader, toggleFollow, isFollowing } = useTraders()
  const { toast } = useToast()

  const [trader, setTrader] = useState<ExtendedTraderData | null>(null)

  useEffect(() => {
    const traderId = Number.parseInt(params.id)
    if (isNaN(traderId)) {
      router.push("/dashboard/traders")
      return
    }

    const basicTrader = getTrader(traderId)
    if (!basicTrader) {
      router.push("/dashboard/traders")
      return
    }

    const extendedData = getExtendedTraderData(basicTrader)
    setTrader(extendedData)
  }, [params.id, getTrader, router])

  const handleToggleFollow = () => {
    if (!trader) return

    toggleFollow(trader.id)

    toast({
      title: isFollowing(trader.id) ? "Trader unfollowed" : "Trader followed",
      description: isFollowing(trader.id)
        ? `You are no longer following ${trader.name}.`
        : `You are now following ${trader.name}. Their trades will be copied to your account.`,
    })
  }

  if (!trader) {
    return null
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Link href="/dashboard/traders">
          <Button variant="ghost" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        </Link>
        <h1 className="text-3xl font-bold tracking-tight">Trader Profile</h1>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-1">
          <CardHeader>
            <div className="flex flex-col items-center text-center">
              <Avatar className="h-20 w-20">
                <AvatarImage src={trader.avatar} alt={trader.name} />
                <AvatarFallback>{trader.initials}</AvatarFallback>
              </Avatar>
              <CardTitle className="mt-4">{trader.name}</CardTitle>
              <div className="flex flex-wrap justify-center gap-2 mt-2">
                {trader.specialties.map((specialty, index) => (
                  <Badge key={index} variant="secondary">
                    {specialty}
                  </Badge>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-center mb-6">{trader.bio}</p>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-muted-foreground">30-Day ROI</p>
                <div className="flex items-center gap-1 font-medium text-green-600">
                  {trader.roi["1m"]}% <TrendingUp className="h-4 w-4" />
                </div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Win Rate</p>
                <p className="text-sm font-medium">{trader.winRate}%</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Followers</p>
                <p className="text-sm font-medium">{trader.followers.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Trades</p>
                <p className="text-sm font-medium">{trader.trades}</p>
              </div>
            </div>

            <Separator className="my-4" />

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Risk Level:</span>
                <span className="font-medium">{trader.riskLevel}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Avg. Holding Time:</span>
                <span className="font-medium">{trader.avgHoldingTime}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Profit Factor:</span>
                <span className="font-medium">{trader.profitFactor}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Max Drawdown:</span>
                <span className="font-medium">{trader.maxDrawdown}%</span>
              </div>
            </div>

            <Button className="w-full mt-6" onClick={handleToggleFollow}>
              {isFollowing(trader.id) ? (
                <>
                  <StarOff className="mr-2 h-4 w-4" />
                  Unfollow Trader
                </>
              ) : (
                <>
                  <Star className="mr-2 h-4 w-4" />
                  Follow Trader
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance History</CardTitle>
              <CardDescription>Monthly returns over time</CardDescription>
            </CardHeader>
            <CardContent>
              <TraderPerformance performance={trader.performance} />
            </CardContent>
          </Card>

          <Tabs defaultValue="trades" className="space-y-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="trades">Recent Trades</TabsTrigger>
              <TabsTrigger value="risk">Risk Analysis</TabsTrigger>
            </TabsList>
            <TabsContent value="trades">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Trades</CardTitle>
                  <CardDescription>Latest trading activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <TraderTrades traderId={trader.id} />
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="risk">
              <Card>
                <CardHeader>
                  <CardTitle>Risk Analysis</CardTitle>
                  <CardDescription>Detailed risk metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <TraderRiskAnalysis traderId={trader.id} />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <div className="flex justify-end">
        <Button asChild>
          <Link href={`/traders/${trader.id}/subscribe`}>
            <Copy className="mr-2 h-4 w-4" />
            Copy Trade
          </Link>
        </Button>
      </div>
    </div>
  )
}

