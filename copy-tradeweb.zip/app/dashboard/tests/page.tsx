import { IntegrationTestSuite } from "@/components/integration-test-suite"
import { Separator } from "@/components/ui/separator"

export default function TestsPage() {
  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col gap-1 mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Platform Tests</h1>
        <p className="text-muted-foreground">
          Run integration tests to verify all platform components are working correctly
        </p>
      </div>

      <Separator className="my-6" />

      <div className="space-y-6">
        <IntegrationTestSuite />
      </div>
    </div>
  )
}

