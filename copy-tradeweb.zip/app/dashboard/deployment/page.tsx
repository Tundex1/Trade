import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle, Server } from "lucide-react"

export default function DeploymentGuidePage() {
  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col gap-1 mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Deployment Guide</h1>
        <p className="text-muted-foreground">Follow these steps to deploy your copy trading platform to production</p>
      </div>

      <Separator className="my-6" />

      <div className="space-y-6">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Important</AlertTitle>
          <AlertDescription>
            Before deploying to production, make sure you have completed all integration tests and resolved any issues.
          </AlertDescription>
        </Alert>

        <Card>
          <CardHeader>
            <CardTitle>Deployment Checklist</CardTitle>
            <CardDescription>Complete these steps before going live</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Set Up Environment Variables</h3>
                  <p className="text-sm text-muted-foreground">
                    Ensure all required environment variables are set in your production environment:
                  </p>
                  <ul className="list-disc list-inside text-sm text-muted-foreground ml-4 mt-2">
                    <li>NEXTAUTH_SECRET - For authentication</li>
                    <li>SENDGRID_API_KEY - For email notifications</li>
                    <li>DATABASE_URL - For database connections</li>
                    <li>BROKER_API_KEYS - For broker integrations</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Configure Database</h3>
                  <p className="text-sm text-muted-foreground">Set up your production database and run migrations:</p>
                  <pre className="bg-muted p-2 rounded-md text-xs mt-2 overflow-x-auto">
                    <code>npx prisma migrate deploy</code>
                  </pre>
                </div>
              </div>

              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Build the Application</h3>
                  <p className="text-sm text-muted-foreground">Build the application for production:</p>
                  <pre className="bg-muted p-2 rounded-md text-xs mt-2 overflow-x-auto">
                    <code>npm run build</code>
                  </pre>
                </div>
              </div>

              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Set Up Monitoring</h3>
                  <p className="text-sm text-muted-foreground">
                    Configure monitoring tools to track application performance and errors:
                  </p>
                  <ul className="list-disc list-inside text-sm text-muted-foreground ml-4 mt-2">
                    <li>Set up error tracking with Sentry</li>
                    <li>Configure performance monitoring with New Relic or Datadog</li>
                    <li>Set up log aggregation with Logtail or Papertrail</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Configure SSL</h3>
                  <p className="text-sm text-muted-foreground">
                    Ensure SSL is properly configured for secure connections.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Set Up Backups</h3>
                  <p className="text-sm text-muted-foreground">
                    Configure automated backups for your database and user data.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Deployment Options</CardTitle>
            <CardDescription>Choose the best deployment method for your needs</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="border rounded-md p-4">
                <div className="flex items-center mb-2">
                  <Server className="h-5 w-5 mr-2 text-blue-500" />
                  <h3 className="font-medium">Vercel</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Recommended for easy deployment and scaling. Integrates well with Next.js.
                </p>
                <pre className="bg-muted p-2 rounded-md text-xs mt-2 overflow-x-auto">
                  <code>vercel --prod</code>
                </pre>
              </div>

              <div className="border rounded-md p-4">
                <div className="flex items-center mb-2">
                  <Server className="h-5 w-5 mr-2 text-purple-500" />
                  <h3 className="font-medium">AWS Amplify</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Great for AWS users. Provides CI/CD, hosting, and backend services.
                </p>
                <pre className="bg-muted p-2 rounded-md text-xs mt-2 overflow-x-auto">
                  <code>amplify publish</code>
                </pre>
              </div>

              <div className="border rounded-md p-4">
                <div className="flex items-center mb-2">
                  <Server className="h-5 w-5 mr-2 text-green-500" />
                  <h3 className="font-medium">Docker</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  For custom deployments and self-hosting. Provides flexibility and control.
                </p>
                <pre className="bg-muted p-2 rounded-md text-xs mt-2 overflow-x-auto">
                  <code>docker-compose up -d</code>
                </pre>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Post-Deployment Steps</CardTitle>
            <CardDescription>Complete these steps after deployment</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Run Integration Tests</h3>
                  <p className="text-sm text-muted-foreground">
                    Verify all components are working correctly in the production environment.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Set Up Alerts</h3>
                  <p className="text-sm text-muted-foreground">
                    Configure alerts for critical system events and errors.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Perform Security Audit</h3>
                  <p className="text-sm text-muted-foreground">
                    Conduct a security audit to identify and address potential vulnerabilities.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Document API Endpoints</h3>
                  <p className="text-sm text-muted-foreground">
                    Create documentation for all API endpoints for future reference.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium">Set Up Continuous Integration</h3>
                  <p className="text-sm text-muted-foreground">
                    Configure CI/CD pipelines for automated testing and deployment.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

