"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BrokerAccountsList } from "@/components/broker-accounts-list"
import { useRouter } from "next/navigation"
import { PlusCircle } from "lucide-react"

export default function BrokerAccountsPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("all")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Broker Accounts</h1>
        <Button onClick={() => router.push("/dashboard/connect-broker")}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Connect Broker
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Connected Accounts</CardTitle>
          <CardDescription>Manage your connected brokerage accounts for copy trading</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All Accounts</TabsTrigger>
              <TabsTrigger value="stocks">Stocks</TabsTrigger>
              <TabsTrigger value="forex">Forex</TabsTrigger>
              <TabsTrigger value="crypto">Crypto</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-6">
              <BrokerAccountsList filter="all" />
            </TabsContent>
            <TabsContent value="stocks" className="mt-6">
              <BrokerAccountsList filter="stocks" />
            </TabsContent>
            <TabsContent value="forex" className="mt-6">
              <BrokerAccountsList filter="forex" />
            </TabsContent>
            <TabsContent value="crypto" className="mt-6">
              <BrokerAccountsList filter="crypto" />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

