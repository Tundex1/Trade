"use client"

import { useState, useEffect } from "react"
import { TraderCard } from "@/components/discover/trader-card"
import { TraderFilters, type TraderFilters as FilterType } from "@/components/discover/trader-filters"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"

// Mock data for traders
const mockTraders = [
  {
    id: "trader-1",
    name: "Alex Johnson",
    image: "/placeholder.svg?height=40&width=40",
    verified: true,
    performance: {
      monthly: 12.5,
      total: 87.3,
    },
    followers: 1245,
    winRate: 68,
    tradingStyle: "Swing Trading",
    markets: ["Forex", "Crypto"],
  },
  {
    id: "trader-2",
    name: "Sarah Williams",
    image: "/placeholder.svg?height=40&width=40",
    verified: true,
    performance: {
      monthly: 8.2,
      total: 45.7,
    },
    followers: 876,
    winRate: 72,
    tradingStyle: "Day Trading",
    markets: ["Stocks", "Indices"],
  },
  {
    id: "trader-3",
    name: "Michael Chen",
    image: "/placeholder.svg?height=40&width=40",
    verified: false,
    performance: {
      monthly: -2.1,
      total: 32.4,
    },
    followers: 421,
    winRate: 58,
    tradingStyle: "Scalping",
    markets: ["Forex", "Commodities"],
  },
  {
    id: "trader-4",
    name: "Emma Davis",
    image: "/placeholder.svg?height=40&width=40",
    verified: true,
    performance: {
      monthly: 15.3,
      total: 124.8,
    },
    followers: 2134,
    winRate: 75,
    tradingStyle: "Position Trading",
    markets: ["Crypto", "Stocks"],
  },
  {
    id: "trader-5",
    name: "David Wilson",
    image: "/placeholder.svg?height=40&width=40",
    verified: false,
    performance: {
      monthly: 5.7,
      total: 28.9,
    },
    followers: 312,
    winRate: 62,
    tradingStyle: "Algorithmic Trading",
    markets: ["Forex", "Indices"],
  },
  {
    id: "trader-6",
    name: "Sophia Martinez",
    image: "/placeholder.svg?height=40&width=40",
    verified: true,
    performance: {
      monthly: 9.8,
      total: 67.2,
    },
    followers: 945,
    winRate: 70,
    tradingStyle: "Swing Trading",
    markets: ["Commodities", "Stocks"],
  },
]

export default function DiscoverPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [traders, setTraders] = useState(mockTraders)
  const [filteredTraders, setFilteredTraders] = useState(mockTraders)
  const [activeTab, setActiveTab] = useState("all")

  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleFilterChange = (filters: FilterType) => {
    let filtered = [...traders]

    // Apply search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase()
      filtered = filtered.filter(
        (trader) =>
          trader.name.toLowerCase().includes(searchLower) || trader.tradingStyle.toLowerCase().includes(searchLower),
      )
    }

    // Apply markets filter
    if (filters.markets.length > 0) {
      filtered = filtered.filter((trader) => trader.markets.some((market) => filters.markets.includes(market)))
    }

    // Apply minimum return filter
    if (filters.minReturn > 0) {
      filtered = filtered.filter((trader) => trader.performance.monthly >= filters.minReturn)
    }

    // Apply minimum win rate filter
    if (filters.minWinRate > 0) {
      filtered = filtered.filter((trader) => trader.winRate >= filters.minWinRate)
    }

    // Apply verified filter
    if (filters.verified) {
      filtered = filtered.filter((trader) => trader.verified)
    }

    // Apply sorting
    switch (filters.sortBy) {
      case "performance":
        filtered.sort((a, b) => b.performance.monthly - a.performance.monthly)
        break
      case "followers":
        filtered.sort((a, b) => b.followers - a.followers)
        break
      case "winRate":
        filtered.sort((a, b) => b.winRate - a.winRate)
        break
      case "newest":
        // In a real app, you would sort by creation date
        break
    }

    setFilteredTraders(filtered)
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value)

    if (value === "all") {
      setFilteredTraders(traders)
    } else if (value === "trending") {
      setFilteredTraders([...traders].sort((a, b) => b.followers - a.followers).slice(0, 3))
    } else if (value === "top-performers") {
      setFilteredTraders([...traders].sort((a, b) => b.performance.monthly - a.performance.monthly).slice(0, 3))
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Discover Traders</h1>

      <TraderFilters onFilterChange={handleFilterChange} />

      <Tabs defaultValue="all" className="mt-6" onValueChange={handleTabChange}>
        <TabsList>
          <TabsTrigger value="all">All Traders</TabsTrigger>
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="top-performers">Top Performers</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6)
                .fill(0)
                .map((_, i) => (
                  <Skeleton key={i} className="h-64 rounded-lg" />
                ))}
            </div>
          ) : filteredTraders.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTraders.map((trader) => (
                <TraderCard key={trader.id} trader={trader} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium">No traders found</h3>
              <p className="text-muted-foreground">Try adjusting your filters to find more traders</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="trending" className="mt-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(3)
                .fill(0)
                .map((_, i) => (
                  <Skeleton key={i} className="h-64 rounded-lg" />
                ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTraders.map((trader) => (
                <TraderCard key={trader.id} trader={trader} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="top-performers" className="mt-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(3)
                .fill(0)
                .map((_, i) => (
                  <Skeleton key={i} className="h-64 rounded-lg" />
                ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTraders.map((trader) => (
                <TraderCard key={trader.id} trader={trader} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

