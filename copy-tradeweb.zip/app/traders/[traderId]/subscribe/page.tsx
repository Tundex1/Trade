"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { AlertCircle, ArrowLeft, CheckCircle, CreditCard, Loader2 } from "lucide-react"
import Link from "next/link"
import { formatCurrency } from "@/lib/utils"

const subscriptionSchema = z.object({
  tradingCapital: z.coerce.number().min(100, "Minimum capital is $100").max(1000000, "Maximum capital is $1,000,000"),
  copyRatio: z.number().min(0.1).max(2),
  maxRiskPerTrade: z.number().min(1).max(20),
  enableStopLoss: z.boolean(),
  stopLossPercentage: z.number().min(5).max(50),
  acceptTerms: z.boolean().refine((val) => val === true, {
    message: "You must accept the terms and conditions",
  }),
})

type SubscriptionFormValues = z.infer<typeof subscriptionSchema>

export default function SubscribePage() {
  const params = useParams()
  const router = useRouter()
  const traderId = params.traderId as string

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Mock trader data
  const trader = {
    id: traderId,
    name: "Alex Johnson",
    subscription: {
      fee: 29.99,
      period: "monthly",
    },
  }

  const form = useForm<SubscriptionFormValues>({
    resolver: zodResolver(subscriptionSchema),
    defaultValues: {
      tradingCapital: 1000,
      copyRatio: 1,
      maxRiskPerTrade: 5,
      enableStopLoss: true,
      stopLossPercentage: 20,
      acceptTerms: false,
    },
  })

  const enableStopLoss = form.watch("enableStopLoss")
  const tradingCapital = form.watch("tradingCapital")
  const copyRatio = form.watch("copyRatio")
  const maxRiskPerTrade = form.watch("maxRiskPerTrade")

  const onSubmit = async (data: SubscriptionFormValues) => {
    setIsSubmitting(true)
    setError(null)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      console.log("Subscription data:", {
        traderId,
        ...data,
      })

      setIsSuccess(true)
    } catch (err) {
      setError("An error occurred while processing your subscription. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isSuccess) {
    return (
      <div className="container max-w-md mx-auto py-12 px-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="rounded-full bg-green-100 p-3">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold">Subscription Successful!</h2>
              <p className="text-muted-foreground">
                You are now copying trades from {trader.name}. You can manage your subscription from your dashboard.
              </p>
              <div className="flex flex-col space-y-2 w-full pt-4">
                <Button asChild>
                  <Link href="/dashboard">Go to Dashboard</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href={`/traders/${traderId}`}>Back to Trader Profile</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container max-w-2xl mx-auto py-8 px-4">
      <div className="mb-6">
        <Button variant="ghost" size="sm" asChild>
          <Link href={`/traders/${traderId}`}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Trader Profile
          </Link>
        </Button>
      </div>

      <h1 className="text-2xl font-bold mb-6">Subscribe to {trader.name}</h1>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Copy Trading Settings</CardTitle>
              <CardDescription>Configure how you want to copy trades from this trader</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="tradingCapital"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Trading Capital (USD)</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormDescription>The amount you want to allocate for copy trading</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="copyRatio"
                    render={({ field: { value, onChange } }) => (
                      <FormItem>
                        <FormLabel>Copy Ratio: {value}x</FormLabel>
                        <FormControl>
                          <Slider
                            value={[value]}
                            min={0.1}
                            max={2}
                            step={0.1}
                            onValueChange={(vals) => onChange(vals[0])}
                          />
                        </FormControl>
                        <FormDescription>Multiply or reduce the position size relative to the trader</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="maxRiskPerTrade"
                    render={({ field: { value, onChange } }) => (
                      <FormItem>
                        <FormLabel>Max Risk Per Trade: {value}%</FormLabel>
                        <FormControl>
                          <Slider
                            value={[value]}
                            min={1}
                            max={20}
                            step={1}
                            onValueChange={(vals) => onChange(vals[0])}
                          />
                        </FormControl>
                        <FormDescription>Maximum percentage of your capital to risk on a single trade</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="enableStopLoss"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Enable Stop Loss</FormLabel>
                          <FormDescription>Automatically stop copying if drawdown exceeds threshold</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {enableStopLoss && (
                    <FormField
                      control={form.control}
                      name="stopLossPercentage"
                      render={({ field: { value, onChange } }) => (
                        <FormItem>
                          <FormLabel>Stop Loss Threshold: {value}%</FormLabel>
                          <FormControl>
                            <Slider
                              value={[value]}
                              min={5}
                              max={50}
                              step={5}
                              onValueChange={(vals) => onChange(vals[0])}
                            />
                          </FormControl>
                          <FormDescription>
                            Stop copying if your account drawdown reaches this percentage
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <Alert className="bg-blue-50 text-blue-800 border-blue-200">
                    <AlertCircle className="h-4 w-4 text-blue-800" />
                    <AlertTitle>Risk Summary</AlertTitle>
                    <AlertDescription className="text-sm">
                      <p>Trading Capital: {formatCurrency(tradingCapital)}</p>
                      <p>Copy Ratio: {copyRatio}x</p>
                      <p>Max Risk Per Trade: {maxRiskPerTrade}%</p>
                      <p>
                        Maximum Amount at Risk Per Trade: {formatCurrency(tradingCapital * (maxRiskPerTrade / 100))}
                      </p>
                    </AlertDescription>
                  </Alert>

                  <Separator />

                  <FormField
                    control={form.control}
                    name="acceptTerms"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <input type="checkbox" checked={field.value} onChange={field.onChange} className="mt-1" />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>I accept the terms and conditions</FormLabel>
                          <FormDescription>
                            I understand the risks involved in copy trading and that past performance is not indicative
                            of future results.
                          </FormDescription>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />

                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <CreditCard className="mr-2 h-4 w-4" />
                        Subscribe & Pay {formatCurrency(trader.subscription.fee)}
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Subscription Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Trader</span>
                  <span className="text-sm font-medium">{trader.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Subscription Fee</span>
                  <span className="text-sm font-medium">
                    {formatCurrency(trader.subscription.fee)}/{trader.subscription.period}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Platform Fee</span>
                  <span className="text-sm font-medium">{formatCurrency(trader.subscription.fee * 0.05)}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Total</span>
                  <span className="text-sm font-medium">{formatCurrency(trader.subscription.fee * 1.05)}</span>
                </div>
              </div>

              <div className="pt-4 text-xs text-muted-foreground space-y-2">
                <p>Your subscription will renew automatically every {trader.subscription.period}.</p>
                <p>You can cancel your subscription at any time from your dashboard.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

