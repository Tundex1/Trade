"use client"

import { SocialFeed } from "@/components/social-feed"

export default function SocialPage() {
  return (
    <div className="container mx-auto py-6">
      <SocialFeed />
    </div>
  )
}

