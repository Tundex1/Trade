"use client"

import { TraderVerification } from "@/components/trader-verification"
import { TraderBadges } from "@/components/trader-badges"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Shield, Award } from "lucide-react"

export default function VerificationPage() {
  return (
    <div className="container mx-auto py-6">
      <Tabs defaultValue="verification">
        <TabsList className="mb-6">
          <TabsTrigger value="verification" className="flex items-center">
            <Shield className="mr-2 h-4 w-4" />
            Verification
          </TabsTrigger>
          <TabsTrigger value="badges" className="flex items-center">
            <Award className="mr-2 h-4 w-4" />
            Badges
          </TabsTrigger>
        </TabsList>

        <TabsContent value="verification">
          <TraderVerification />
        </TabsContent>

        <TabsContent value="badges">
          <TraderBadges />
        </TabsContent>
      </Tabs>
    </div>
  )
}

