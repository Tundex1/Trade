import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { getToken } from "next-auth/jwt"

// Rate limiting configuration
const RATE_LIMIT_WINDOW = 60 * 1000 // 1 minute in milliseconds
const MAX_REQUESTS_PER_WINDOW = 100 // Maximum requests per window

// In-memory store for rate limiting
// In production, use Redis or another distributed store
const rateLimitStore = new Map<string, { count: number; resetTime: number }>()

// Clean up the rate limit store periodically
setInterval(() => {
  const now = Date.now()
  for (const [key, value] of rateLimitStore.entries()) {
    if (now > value.resetTime) {
      rateLimitStore.delete(key)
    }
  }
}, 60 * 1000) // Clean up every minute

export async function middleware(request: NextRequest) {
  const response = NextResponse.next()

  // Apply rate limiting
  const ip = request.ip || "unknown"
  const now = Date.now()

  // Get or create rate limit data for this IP
  let rateLimitData = rateLimitStore.get(ip)
  if (!rateLimitData || now > rateLimitData.resetTime) {
    rateLimitData = { count: 0, resetTime: now + RATE_LIMIT_WINDOW }
    rateLimitStore.set(ip, rateLimitData)
  }

  // Increment request count
  rateLimitData.count++

  // Check if rate limit exceeded
  if (rateLimitData.count > MAX_REQUESTS_PER_WINDOW) {
    return new NextResponse(JSON.stringify({ success: false, message: "Rate limit exceeded" }), {
      status: 429,
      headers: {
        "Content-Type": "application/json",
        "X-RateLimit-Limit": MAX_REQUESTS_PER_WINDOW.toString(),
        "X-RateLimit-Remaining": "0",
        "X-RateLimit-Reset": Math.ceil(rateLimitData.resetTime / 1000).toString(),
      },
    })
  }

  // Add rate limit headers
  response.headers.set("X-RateLimit-Limit", MAX_REQUESTS_PER_WINDOW.toString())
  response.headers.set("X-RateLimit-Remaining", (MAX_REQUESTS_PER_WINDOW - rateLimitData.count).toString())
  response.headers.set("X-RateLimit-Reset", Math.ceil(rateLimitData.resetTime / 1000).toString())

  // Check authentication for protected routes
  const isApiRoute = request.nextUrl.pathname.startsWith("/api")
  const isDashboardRoute = request.nextUrl.pathname.startsWith("/dashboard")
  const isSettingsRoute = request.nextUrl.pathname.startsWith("/settings")
  const isAuthRoute =
    request.nextUrl.pathname.startsWith("/login") ||
    request.nextUrl.pathname.startsWith("/signup") ||
    request.nextUrl.pathname.startsWith("/auth")

  if (isApiRoute && !request.nextUrl.pathname.startsWith("/api/auth")) {
    // Protect API routes except auth endpoints
    const token = await getToken({ req: request })

    if (!token) {
      return new NextResponse(JSON.stringify({ success: false, message: "Authentication required" }), {
        status: 401,
        headers: {
          "Content-Type": "application/json",
        },
      })
    }
  }

  if (isDashboardRoute || isSettingsRoute) {
    // Protect dashboard and settings routes
    const token = await getToken({ req: request })

    if (!token) {
      // Redirect to login page with return URL
      const url = new URL("/login", request.url)
      url.searchParams.set("callbackUrl", request.nextUrl.pathname)
      return NextResponse.redirect(url)
    }
  }

  if (isAuthRoute) {
    // Check if user is already logged in
    const token = await getToken({ req: request })

    if (token) {
      // Redirect already logged in users to dashboard
      return NextResponse.redirect(new URL("/dashboard", request.url))
    }
  }

  return response
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public (public files)
     */
    "/((?!_next/static|_next/image|favicon.ico|public).*)",
  ],
}

