# CopyTradeweb Platform

CopyTradeweb is a full-featured copy trading platform that allows users to follow and automatically copy trades from expert traders across stocks, forex, and cryptocurrency markets.

## Features

- User authentication with email/password and Google OAuth
- Connect to multiple broker accounts (stocks, forex, crypto)
- Copy real trades from lead traders in real time
- Track portfolio, trade history, and real PnL
- Allocate capital based on real balances
- Manage trades, get alerts, and analyze performance

## Tech Stack

- **Frontend**: Next.js 14 with App Router, React, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: PostgreSQL (can be replaced with MongoDB, MySQL, etc.)
- **Authentication**: NextAuth.js with JWT
- **State Management**: Zustand
- **UI Components**: shadcn/ui
- **Icons**: Lucide React
- **Forms**: React Hook Form with Zod validation

## Getting Started

### Prerequisites

- Node.js 18+ and npm/pnpm
- PostgreSQL database (or other supported by Prisma)
- Google OAuth credentials (for Google sign-in)

### Installation

1.  Clone the repository:
    ```bash
    git clone https://github.com/yourusername/copytradeweb.git
    cd copytradeweb

