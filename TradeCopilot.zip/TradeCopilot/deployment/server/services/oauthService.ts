import axios from 'axios';
import crypto from 'crypto';
import querystring from 'querystring';
import { db } from '../db';
import { oauthTokens, InsertOAuthToken, OAuthToken } from '@shared/schema';
import { eq, and } from 'drizzle-orm';

// Encryption helpers for token security
const ENCRYPTION_KEY = process.env.JWT_SECRET || 'default-key-should-be-replaced'; // Use JWT_SECRET as encryption key
const IV_LENGTH = 16; // For AES, this is always 16

// Define Schwab OAuth configuration
interface SchwabOAuthConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  apiBaseUrl: string;
  authUrl: string;
  tokenUrl: string;
  scope: string;
}

// Instantiate with environment variables
const schwabOAuthConfig: SchwabOAuthConfig = {
  clientId: process.env.SCHWAB_API_KEY || '',
  clientSecret: process.env.SCHWAB_API_SECRET || '',
  redirectUri: process.env.SCHWAB_REDIRECT_URI || `${process.env.HOST || 'http://localhost:5000'}/auth/schwab/callback`,
  apiBaseUrl: process.env.SCHWAB_API_URL || 'https://api.schwabapi.com/v1',
  authUrl: process.env.SCHWAB_AUTH_URL || `${process.env.SCHWAB_API_URL}/oauth/authorize` || 'https://api.schwabapi.com/v1/oauth/authorize',
  tokenUrl: process.env.SCHWAB_TOKEN_URL || `${process.env.SCHWAB_API_URL}/oauth/token` || 'https://api.schwabapi.com/v1/oauth/token',
  scope: process.env.SCHWAB_SCOPE || 'trade account_info market_data',
};

export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: string;
  scope?: string;
}

class OAuthService {
  private config: SchwabOAuthConfig;
  private intervalId: NodeJS.Timeout | null = null;

  constructor(config: SchwabOAuthConfig) {
    this.config = config;
    this.setupTokenRefresh();
  }

  // Token encryption
  private encrypt(text: string): string {
    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), iv);
    let encrypted = cipher.update(text);
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return iv.toString('hex') + ':' + encrypted.toString('hex');
  }

  // Token decryption
  private decrypt(text: string): string {
    const parts = text.split(':');
    const iv = Buffer.from(parts.shift() || '', 'hex');
    const encryptedText = Buffer.from(parts.join(':'), 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), iv);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted.toString();
  }

  // Get authorization URL for redirect
  getAuthorizationUrl(state: string): string {
    const params = {
      response_type: 'code',
      client_id: this.config.clientId,
      redirect_uri: this.config.redirectUri,
      scope: this.config.scope,
      state
    };
    
    return `${this.config.authUrl}?${querystring.stringify(params)}`;
  }

  // Exchange authorization code for tokens
  async exchangeCodeForToken(code: string): Promise<TokenResponse> {
    try {
      const response = await axios.post(
        this.config.tokenUrl,
        querystring.stringify({
          grant_type: 'authorization_code',
          code,
          redirect_uri: this.config.redirectUri,
          client_id: this.config.clientId,
          client_secret: this.config.clientSecret,
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      );

      return response.data;
    } catch (error) {
      console.error('[oauth-error] Token exchange failed:', error);
      throw new Error('Failed to exchange authorization code for token');
    }
  }

  // Refresh an existing token
  async refreshToken(refreshToken: string): Promise<TokenResponse> {
    try {
      const response = await axios.post(
        this.config.tokenUrl,
        querystring.stringify({
          grant_type: 'refresh_token',
          refresh_token: refreshToken,
          client_id: this.config.clientId,
          client_secret: this.config.clientSecret,
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      );

      return response.data;
    } catch (error) {
      console.error('[oauth-error] Token refresh failed:', error);
      throw new Error('Failed to refresh token');
    }
  }

  // Save tokens to database (encrypted)
  async saveTokens(accountId: number, tokenResponse: TokenResponse): Promise<OAuthToken> {
    const now = new Date();
    const expiresAt = new Date(now.getTime() + tokenResponse.expires_in * 1000);
    
    // Encrypt tokens before storing
    const encryptedAccessToken = this.encrypt(tokenResponse.access_token);
    const encryptedRefreshToken = this.encrypt(tokenResponse.refresh_token);
    
    // Check if token already exists for this account
    const existingToken = await this.getTokenByAccountId(accountId);
    
    if (existingToken) {
      // Update existing token
      const [updatedToken] = await db
        .update(oauthTokens)
        .set({
          accessToken: encryptedAccessToken,
          refreshToken: encryptedRefreshToken,
          expiresAt,
          scope: tokenResponse.scope,
          tokenType: tokenResponse.token_type,
          updatedAt: now,
        })
        .where(eq(oauthTokens.id, existingToken.id))
        .returning();
      
      return updatedToken;
    } else {
      // Create new token
      const tokenData: InsertOAuthToken = {
        accountId,
        accessToken: encryptedAccessToken,
        refreshToken: encryptedRefreshToken,
        expiresAt,
        scope: tokenResponse.scope,
        tokenType: tokenResponse.token_type,
      };
      
      const [newToken] = await db
        .insert(oauthTokens)
        .values(tokenData)
        .returning();
      
      return newToken;
    }
  }

  // Get token by account ID
  async getTokenByAccountId(accountId: number): Promise<OAuthToken | undefined> {
    const [token] = await db
      .select()
      .from(oauthTokens)
      .where(eq(oauthTokens.accountId, accountId));
    
    return token;
  }

  // Get decrypted access token for API calls
  async getDecryptedAccessToken(accountId: number): Promise<string | null> {
    const token = await this.getTokenByAccountId(accountId);
    
    if (!token) {
      return null;
    }
    
    // Check if token is expired
    const now = new Date();
    if (now > token.expiresAt) {
      try {
        // Try to refresh the token
        const decryptedRefreshToken = this.decrypt(token.refreshToken);
        const tokenResponse = await this.refreshToken(decryptedRefreshToken);
        await this.saveTokens(accountId, tokenResponse);
        
        return tokenResponse.access_token;
      } catch (error) {
        console.error('[oauth-error] Failed to refresh expired token:', error);
        return null;
      }
    }
    
    // Token is valid, decrypt and return
    return this.decrypt(token.accessToken);
  }

  // Set up periodic token refresh (every 110 minutes to be safe)
  setupTokenRefresh(): void {
    // Clear any existing interval
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
    
    // Every 110 minutes (110 * 60 * 1000 ms)
    const refreshInterval = 110 * 60 * 1000;
    
    this.intervalId = setInterval(async () => {
      try {
        // Get all tokens that expire in the next 20 minutes
        const twentyMinutesFromNow = new Date(Date.now() + 20 * 60 * 1000);
        
        // Get tokens that will expire soon
        const tokens = await db
          .select()
          .from(oauthTokens);
          
        // Filter tokens manually since SQLite doesn't support Date comparison
        const tokensToRefresh = tokens.filter(token => 
          token.expiresAt < twentyMinutesFromNow && 
          token.refreshToken !== null
        );
        
        console.log(`[oauth] Refreshing ${tokensToRefresh.length} tokens`);
        
        // Refresh each token
        for (const token of tokensToRefresh) {
          try {
            const decryptedRefreshToken = this.decrypt(token.refreshToken);
            const tokenResponse = await this.refreshToken(decryptedRefreshToken);
            await this.saveTokens(token.accountId!, tokenResponse);
            console.log(`[oauth] Successfully refreshed token for account ${token.accountId}`);
          } catch (error) {
            console.error(`[oauth-error] Failed to refresh token for account ${token.accountId}:`, error);
          }
        }
      } catch (error) {
        console.error('[oauth-error] Error in token refresh scheduler:', error);
      }
    }, refreshInterval);
    
    console.log(`[oauth] Token refresh scheduled every ${refreshInterval / (60 * 1000)} minutes`);
  }
}

// Create and export a singleton instance
export const oauthService = new OAuthService(schwabOAuthConfig);