import { Router, Request, Response } from 'express';
import { oauthService } from '../services/oauthService';
import { storage } from '../storage';
import { authenticate } from '../middleware/auth';
import { AuthRequest } from '../middleware/auth';
import { randomBytes } from 'crypto';

const router = Router();

// Generate a random state for CSRF protection
const generateState = (): string => {
  return randomBytes(32).toString('hex');
};

// Route: GET /auth/schwab/connect
// Returns Schwab login URL with appropriate parameters as JSON
router.get('/connect', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    // Require accountId parameter
    const accountId = req.query.accountId as string;
    
    if (!accountId) {
      return res.status(400).json({ error: 'Missing accountId parameter' });
    }
    
    // Validate account exists and user has access
    const account = await storage.getAccount(parseInt(accountId, 10));
    
    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }
    
    // Generate and store state parameter to prevent CSRF
    const state = generateState();
    
    // Store the state and accountId in session to verify on callback
    req.session.oauthState = state;
    req.session.accountId = accountId;
    
    // Return the authorization URL as JSON instead of redirecting
    const authUrl = oauthService.getAuthorizationUrl(state);
    res.status(200).json({ authUrl });
  } catch (error) {
    console.error('[oauth-error] Connect error:', error);
    res.status(500).json({ error: 'Failed to initiate OAuth flow' });
  }
});

// Route: GET /auth/schwab/callback
// Handles callback from Schwab OAuth with code
router.get('/callback', async (req: Request, res: Response) => {
  try {
    const { code, state } = req.query;
    
    // Validate state to prevent CSRF attacks
    if (!state || state !== req.session.oauthState) {
      return res.status(400).json({ error: 'Invalid state parameter' });
    }
    
    // Get accountId from session
    const accountId = parseInt(req.session.accountId as string, 10);
    
    if (!accountId) {
      return res.status(400).json({ error: 'Missing accountId in session' });
    }
    
    // Exchange code for tokens
    const tokenResponse = await oauthService.exchangeCodeForToken(code as string);
    
    // Save tokens securely
    await oauthService.saveTokens(accountId, tokenResponse);
    
    // Update account status
    await storage.updateAccount(accountId, {
      status: 'connected'
    });
    
    // Clear session data
    delete req.session.oauthState;
    delete req.session.accountId;
    
    // Redirect back to application
    res.redirect('/accounts');
  } catch (error) {
    console.error('[oauth-error] Callback error:', error);
    res.status(500).json({ error: 'Failed to complete OAuth flow' });
  }
});

// Check if an account has a valid OAuth token
router.get('/status/:accountId', authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const accountId = parseInt(req.params.accountId, 10);
    const token = await oauthService.getTokenByAccountId(accountId);
    
    if (!token) {
      return res.json({ connected: false });
    }
    
    const now = new Date();
    const isValid = now < token.expiresAt;
    
    res.json({
      connected: isValid,
      expiresAt: token.expiresAt,
    });
  } catch (error) {
    console.error('[oauth-error] Status check error:', error);
    res.status(500).json({ error: 'Failed to check OAuth status' });
  }
});

export default router;