# TradeSwim cPanel Deployment Guide

This guide provides detailed instructions for deploying the TradeSwim application to a cPanel hosting environment.

## Prerequisites

1. A cPanel hosting account with:
   - Node.js support (version 16 or higher)
   - PostgreSQL database support
   - SSH access (recommended)

2. All required API keys and secrets for Schwab API integration

## Deployment Steps

### 1. Prepare Your Local Environment

First, run the deployment script to create the deployment package:

```bash
# Make the script executable
chmod +x deploy.sh

# Run the deployment script
./deploy.sh
```

This will create a `tradeswim-cpanel-deploy.zip` file in your project directory.

### 2. Database Setup in cPanel

1. Log in to your cPanel account
2. Navigate to "PostgreSQL Databases"
3. Create a new database and user
4. Grant all privileges to the user for the database
5. Note the connection details (hostname, database name, username, password)

### 3. Upload Files to cPanel

1. Download the `tradeswim-cpanel-deploy.zip` file from your development environment
2. In cPanel, go to "File Manager"
3. Navigate to the directory where you want to deploy the application (e.g., `public_html` or a subdirectory)
4. Upload and extract the ZIP file

### 4. Configure Node.js Application in cPanel

1. In cPanel, go to "Setup Node.js App"
2. Click "Create Application" and configure:
   - Node.js version: 20.x (or latest available)
   - Application mode: Production
   - Application root: `/path/to/uploaded/files` (where you extracted the ZIP)
   - Application URL: your domain or subdomain
   - Application startup file: `index.js`

3. Set environment variables:
   ```
   DATABASE_URL=postgres://username:password@hostname:5432/database_name
   JWT_SECRET=your_jwt_secret_key
   SCHWAB_API_URL=your_schwab_api_url
   SCHWAB_CLIENT_ID=your_schwab_client_id
   SCHWAB_CLIENT_SECRET=your_schwab_client_secret
   SCHWAB_API_BASE_URL=your_schwab_api_base_url
   SCHWAB_API_KEY=your_schwab_api_key
   SCHWAB_API_SECRET=your_schwab_api_secret
   SCHWAB_REDIRECT_URI=your_schwab_redirect_uri
   ```

4. Click "Create" to save the application configuration

### 5. Install Dependencies

Using SSH (recommended):
1. Connect to your server via SSH
2. Navigate to your application directory
3. Run `npm install --production`

Alternatively, if SSH access is not available:
1. In cPanel, go to "Terminal"
2. Navigate to your application directory
3. Run `npm install --production`

### 6. Initialize the Database

1. Via SSH or Terminal, run:
   ```bash
   npx drizzle-kit push
   ```

2. If you're migrating an existing database, you may need to export data from your development environment and import it to the cPanel database.

### 7. Start the Application

1. In cPanel's "Setup Node.js App" section, find your application
2. Click "Start Application"
3. Verify the status shows as "Running"

### 8. Configure Domain and SSL

1. In cPanel, ensure your domain or subdomain points to the Node.js application
2. Set up SSL certificate using "SSL/TLS" or "Let's Encrypt SSL"

## Troubleshooting

### Common Issues and Solutions

1. **Database Connection Errors**
   - Double-check your DATABASE_URL environment variable
   - Ensure the PostgreSQL user has proper permissions
   - Verify the PostgreSQL service is running

2. **WebSocket Connection Issues**
   - Check if your hosting provider supports WebSocket proxying
   - Verify the .htaccess configuration is correct
   - Contact your hosting provider for WebSocket support

3. **Application Not Starting**
   - Check the application logs in cPanel
   - Verify all dependencies are installed
   - Ensure the Node.js version is compatible

4. **API Integration Failures**
   - Verify all Schwab API credentials are correct
   - Check network connectivity to the Schwab API servers
   - Update your SCHWAB_REDIRECT_URI to match your production domain

## Maintenance

### Application Updates

To update your application in the future:
1. Generate a new deployment package
2. Upload and extract to replace the existing files
3. If database schema changed, run the database migrations
4. Restart the Node.js application

### Logging and Monitoring

1. Check application logs in cPanel's "Logs" section
2. Consider setting up a monitoring service for uptime and performance
3. Implement regular database backups through cPanel's "Backup" tools