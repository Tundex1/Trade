import { useState, useEffect, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from './queryClient';

type WebSocketStatus = 'connecting' | 'connected' | 'disconnected' | 'error';

interface WebSocketMessage {
  type: string;
  data: any;
}

let socket: WebSocket | null = null;
let reconnectAttempts = 0;
const maxReconnectAttempts = 5;
const reconnectDelay = 3000; // 3 seconds

export const useWebSocket = () => {
  const [status, setStatus] = useState<WebSocketStatus>('disconnected');
  const { toast } = useToast();
  
  const connect = useCallback(() => {
    if (socket?.readyState === WebSocket.OPEN) return;
    
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    setStatus('connecting');
    socket = new WebSocket(wsUrl);
    
    socket.onopen = () => {
      setStatus('connected');
      reconnectAttempts = 0;
      console.log('WebSocket connected');
      
      // Send initial ping and subscribe to all channels
      if (socket && socket.readyState === WebSocket.OPEN) {
        // Initial ping
        socket.send(JSON.stringify({ type: 'ping' }));
        
        // Subscribe to data channels
        socket.send(JSON.stringify({ type: 'subscribe', channel: 'trades' }));
        socket.send(JSON.stringify({ type: 'subscribe', channel: 'market' }));
        socket.send(JSON.stringify({ type: 'subscribe', channel: 'accounts' }));
      }
    };
    
    socket.onclose = (event) => {
      setStatus('disconnected');
      console.log(`WebSocket closed: ${event.code} ${event.reason}`);
      
      // Attempt to reconnect
      if (reconnectAttempts < maxReconnectAttempts) {
        reconnectAttempts++;
        setTimeout(connect, reconnectDelay);
      } else {
        toast({
          variant: 'destructive',
          title: 'Connection Lost',
          description: 'Unable to reconnect to the server. Please refresh the page.',
        });
      }
    };
    
    socket.onerror = (error) => {
      setStatus('error');
      console.error('WebSocket error:', error);
    };
    
    socket.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        handleWebSocketMessage(message);
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
  }, [toast]);
  
  const handleWebSocketMessage = (message: WebSocketMessage) => {
    switch (message.type) {
      case 'pong':
        // Update connection status
        break;
        
      case 'marketUpdate':
        // Update market data
        queryClient.setQueryData(['/api/market/indices'], message.data);
        break;
        
      case 'tradesUpdate':
        // Update trades
        queryClient.setQueryData(['/api/trades/active'], message.data);
        break;
        
      case 'accountsUpdate':
        // Update accounts
        queryClient.setQueryData(['/api/accounts'], message.data);
        break;
        
      case 'newTrade':
        // Add new trade and invalidate queries
        queryClient.invalidateQueries({ queryKey: ['api/trades'] });
        queryClient.invalidateQueries({ queryKey: ['api/trades/active'] });
        queryClient.invalidateQueries({ queryKey: ['api/dashboard'] });
        
        toast({
          title: 'New Trade Created',
          description: `${message.data.type === 'long' ? 'Buy' : 'Sell'} ${message.data.symbol} at ${message.data.entryPrice}`,
        });
        break;
        
      case 'updateTrade':
        // Update specific trade
        queryClient.invalidateQueries({ queryKey: ['api/trades'] });
        queryClient.invalidateQueries({ queryKey: ['api/trades/active'] });
        break;
        
      case 'closeTrade':
        // Handle closed trade
        queryClient.invalidateQueries({ queryKey: ['api/trades'] });
        queryClient.invalidateQueries({ queryKey: ['api/trades/active'] });
        queryClient.invalidateQueries({ queryKey: ['api/dashboard'] });
        
        toast({
          title: 'Trade Closed',
          description: `${message.data.symbol} position closed`,
        });
        break;
        
      case 'updateAccount':
        // Update account data
        queryClient.invalidateQueries({ queryKey: ['api/accounts'] });
        queryClient.invalidateQueries({ queryKey: ['api/dashboard'] });
        break;
        
      case 'newAccount':
        // Add new account
        queryClient.invalidateQueries({ queryKey: ['api/accounts'] });
        queryClient.invalidateQueries({ queryKey: ['api/dashboard'] });
        
        toast({
          title: 'Account Connected',
          description: `${message.data.accountName} has been connected`,
        });
        break;
        
      default:
        console.log('Unhandled message type:', message.type);
    }
  };
  
  // Set up ping interval to keep connection alive
  useEffect(() => {
    const pingInterval = setInterval(() => {
      if (socket?.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: 'ping' }));
      }
    }, 30000); // 30 seconds
    
    return () => clearInterval(pingInterval);
  }, []);
  
  // Initial connection
  useEffect(() => {
    connect();
    
    // Cleanup on unmount
    return () => {
      if (socket) {
        socket.close();
        socket = null;
      }
    };
  }, [connect]);
  
  return { status };
};

// Send message through WebSocket
export const sendWebSocketMessage = (type: string, data?: any) => {
  if (socket?.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({
      type,
      data
    }));
    return true;
  }
  return false;
};
