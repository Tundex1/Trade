"use client"

import { useQuery } from "@tanstack/react-query"
import { apiRequest } from "@/lib/queryClient"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Clock, CheckCircle, XCircle } from "lucide-react"
import { useState, useEffect } from "react"

interface OAuthStatusBadgeProps {
  accountId: number
}

export default function OAuthStatusBadge({ accountId }: OAuthStatusBadgeProps) {
  const [timeLeft, setTimeLeft] = useState<string>("")

  const { data, isLoading, isError } = useQuery({
    queryKey: [`/auth/schwab/status/${accountId}`],
    queryFn: async () => {
      const res = await apiRequest("GET", `/auth/schwab/status/${accountId}`)
      if (!res.ok) {
        throw new Error("Failed to fetch OAuth status")
      }
      return res.json()
    },
    // Refresh every 5 minutes
    refetchInterval: 5 * 60 * 1000,
  })

  // Format time remaining
  useEffect(() => {
    if (data?.expiresIn) {
      const updateTimeLeft = () => {
        const now = new Date()
        const expiresAt = new Date(data.expiresAt)
        const diffMs = expiresAt.getTime() - now.getTime()

        if (diffMs <= 0) {
          setTimeLeft("Expired")
          return
        }

        const diffMins = Math.floor(diffMs / 60000)
        const diffHours = Math.floor(diffMins / 60)
        const remainingMins = diffMins % 60

        if (diffHours > 0) {
          setTimeLeft(`${diffHours}h ${remainingMins}m`)
        } else {
          setTimeLeft(`${remainingMins}m`)
        }
      }

      updateTimeLeft()
      const interval = setInterval(updateTimeLeft, 60000) // Update every minute

      return () => clearInterval(interval)
    }
  }, [data])

  if (isLoading) {
    return (
      <Badge variant="outline" className="bg-dark-lighter text-light-darker">
        <Clock className="h-3 w-3 mr-1" />
        Checking...
      </Badge>
    )
  }

  if (isError || !data) {
    return (
      <Badge variant="outline" className="bg-dark-lighter text-danger">
        <XCircle className="h-3 w-3 mr-1" />
        Error
      </Badge>
    )
  }

  if (!data.connected) {
    return (
      <Badge variant="outline" className="bg-dark-lighter text-danger">
        <XCircle className="h-3 w-3 mr-1" />
        Disconnected
      </Badge>
    )
  }

  // Format the last refreshed time
  const lastRefreshed = new Date(data.lastRefreshed)
  const formattedLastRefreshed = lastRefreshed.toLocaleString()

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="outline" className="bg-dark-lighter text-secondary cursor-help">
            <CheckCircle className="h-3 w-3 mr-1" />
            Connected ({timeLeft})
          </Badge>
        </TooltipTrigger>
        <TooltipContent className="bg-dark text-light border-dark-lighter">
          <div className="text-xs">
            <p>
              <strong>Token Age:</strong> {Math.floor(data.tokenAge / 60)} minutes
            </p>
            <p>
              <strong>Expires In:</strong> {Math.floor(data.expiresIn / 60)} minutes
            </p>
            <p>
              <strong>Last Refreshed:</strong> {formattedLastRefreshed}
            </p>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
