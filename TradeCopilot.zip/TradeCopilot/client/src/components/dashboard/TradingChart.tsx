import { useState } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';
import { useQuery } from '@tanstack/react-query';

interface ChartData {
  date: string;
  value: number;
}

type TimeRange = '1D' | '1W' | '1M' | '3M' | '1Y';

export default function TradingChart() {
  const [timeRange, setTimeRange] = useState<TimeRange>('1W');
  
  // Mock chart data - in a real app, this would come from the API
  const { data: chartData, isLoading } = useQuery<ChartData[]>({
    queryKey: ['/api/dashboard/chart', timeRange],
  });
  
  const timeRangeOptions: TimeRange[] = ['1D', '1W', '1M', '3M', '1Y'];
  
  if (isLoading || !chartData) {
    return (
      <div className="bg-dark rounded-lg shadow-md border border-dark-lighter overflow-hidden mb-6">
        <div className="p-4 border-b border-dark-lighter flex justify-between items-center">
          <div>
            <h3 className="font-semibold">Performance Overview</h3>
            <p className="text-sm text-light-darker">Trade performance across all accounts</p>
          </div>
          <div className="flex space-x-2">
            {timeRangeOptions.map(option => (
              <button 
                key={option} 
                className="px-3 py-1 text-xs rounded-full bg-dark-lighter"
              >
                {option}
              </button>
            ))}
          </div>
        </div>
        
        <div className="p-4">
          <div className="chart-container animate-pulse bg-dark-lighter opacity-50">
            <div className="loading-indicator">
              <div className="spinner"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  const handleTimeRangeChange = (range: TimeRange) => {
    setTimeRange(range);
  };
  
  const formatCurrency = (value: number) => {
    return `$${value.toLocaleString('en-US')}`;
  };
  
  return (
    <div className="bg-dark rounded-lg shadow-md border border-dark-lighter overflow-hidden mb-6">
      <div className="p-4 border-b border-dark-lighter flex justify-between items-center">
        <div>
          <h3 className="font-semibold">Performance Overview</h3>
          <p className="text-sm text-light-darker">Trade performance across all accounts</p>
        </div>
        <div className="flex space-x-2">
          {timeRangeOptions.map(option => (
            <button 
              key={option} 
              className={`px-3 py-1 text-xs rounded-full ${
                timeRange === option 
                  ? 'bg-primary text-white' 
                  : 'bg-dark-lighter hover:bg-dark-darker transition-colors'
              }`}
              onClick={() => handleTimeRangeChange(option)}
            >
              {option}
            </button>
          ))}
        </div>
      </div>
      
      <div className="p-4">
        <div className="chart-container">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="date" 
                tick={{ fill: '#94a3b8', fontSize: 12 }}
                axisLine={{ stroke: '#334155' }}
                tickLine={{ stroke: '#334155' }}
              />
              <YAxis 
                tickFormatter={formatCurrency}
                tick={{ fill: '#94a3b8', fontSize: 12 }}
                axisLine={{ stroke: '#334155' }}
                tickLine={{ stroke: '#334155' }}
              />
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <Tooltip 
                formatter={(value: number) => [formatCurrency(value), 'Value']}
                contentStyle={{ 
                  backgroundColor: '#1e293b',
                  borderColor: '#334155',
                  color: '#f8fafc'
                }}
              />
              <Area 
                type="monotone"
                dataKey="value"
                stroke="#3b82f6"
                fillOpacity={1}
                fill="url(#colorValue)"
                dot={{ fill: '#3b82f6', r: 4 }}
                activeDot={{ r: 6 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
