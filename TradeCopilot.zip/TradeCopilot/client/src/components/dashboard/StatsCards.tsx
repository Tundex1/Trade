import { useQuery } from '@tanstack/react-query';
import { formatCurrency, formatPercentage } from '@/lib/utils';

interface DashboardStats {
  activeTrades: number;
  totalProfitLoss: number;
  connectedAccounts: number;
  successRate: number;
}

export default function StatsCards() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard'],
  });
  
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {Array(4).fill(0).map((_, index) => (
          <div key={index} className="bg-dark p-4 rounded-lg shadow-md border border-dark-lighter animate-pulse">
            <div className="h-4 bg-dark-lighter rounded w-1/2 mb-2"></div>
            <div className="h-6 bg-dark-lighter rounded w-1/3 mt-1"></div>
            <div className="h-4 bg-dark-lighter rounded w-2/3 mt-2"></div>
          </div>
        ))}
      </div>
    );
  }
  
  const statsCards = [
    {
      title: 'Active Trades',
      value: stats?.activeTrades || 0,
      change: '+3 (33%)',
      changeText: 'from yesterday',
      icon: 'trending_up',
      iconClass: 'text-primary bg-primary bg-opacity-10',
    },
    {
      title: 'Total P&L',
      value: formatCurrency(stats?.totalProfitLoss || 0),
      change: '+$420.65 (14.8%)',
      changeText: 'this week',
      icon: 'attach_money',
      iconClass: 'text-secondary bg-secondary bg-opacity-10',
      valueClass: stats && stats.totalProfitLoss > 0 ? 'text-secondary' : 'text-danger',
    },
    {
      title: 'Connected Accounts',
      value: stats?.connectedAccounts || 0,
      change: '+1 (25%)',
      changeText: 'new this month',
      icon: 'people',
      iconClass: 'text-info bg-info bg-opacity-10',
    },
    {
      title: 'Success Rate',
      value: `${stats?.successRate.toFixed(1) || 0}%`,
      change: '+2.3%',
      changeText: 'from last week',
      icon: 'insights',
      iconClass: 'text-warning bg-warning bg-opacity-10',
    }
  ];
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {statsCards.map((card, index) => (
        <div key={index} className="bg-dark p-4 rounded-lg shadow-md border border-dark-lighter">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-light-darker text-sm">{card.title}</p>
              <p className={`text-2xl font-bold mt-1 ${card.valueClass || ''}`}>{card.value}</p>
            </div>
            <span className={`material-icons p-2 rounded-full ${card.iconClass}`}>{card.icon}</span>
          </div>
          <div className="mt-2 text-sm">
            <span className="text-secondary">{card.change}</span> {card.changeText}
          </div>
        </div>
      ))}
    </div>
  );
}
