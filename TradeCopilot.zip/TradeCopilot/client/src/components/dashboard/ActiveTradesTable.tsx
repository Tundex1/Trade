import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Trade } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { formatCurrency, formatPercentage, formatDuration } from '@/lib/utils';
import { useLocation } from 'wouter';

interface TradesResponse {
  trades: Trade[];
  total: number;
}

export default function ActiveTradesTable() {
  const [page, setPage] = useState(1);
  const [pageSize] = useState(5);
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const { data, isLoading, isError } = useQuery<Trade[]>({
    queryKey: ['/api/trades/active'],
  });
  
  const closeTradeMutation = useMutation({
    mutationFn: async (tradeId: number) => {
      const res = await apiRequest('DELETE', `/api/trades/${tradeId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trades/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: 'Trade closed',
        description: 'The trade has been closed successfully',
      });
    },
    onError: (error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to close trade',
      });
    }
  });
  
  const handleCloseTrade = (tradeId: number) => {
    if (window.confirm('Are you sure you want to close this trade?')) {
      closeTradeMutation.mutate(tradeId);
    }
  };
  
  const navigateToTradesPage = () => {
    setLocation('/trades');
  };
  
  const handleEditTrade = (tradeId: number) => {
    // Navigate to the trade edit page
    setLocation(`/trades?edit=${tradeId}`);
  };
  
  // Calculate pagination
  const totalPages = Math.ceil((data?.length || 0) / pageSize);
  const paginatedTrades = data?.slice((page - 1) * pageSize, page * pageSize) || [];
  
  if (isLoading) {
    return (
      <div className="bg-dark rounded-lg shadow-md border border-dark-lighter overflow-hidden mb-6">
        <div className="p-4 border-b border-dark-lighter flex justify-between items-center">
          <div>
            <h3 className="font-semibold">Active Trades</h3>
            <p className="text-sm text-light-darker">Currently open positions</p>
          </div>
          <Button className="text-sm" disabled>Loading...</Button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-dark-lighter">
            <thead className="bg-dark-lighter">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Symbol</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Type</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Entry Price</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Current Price</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">P&L</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Duration</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-light-darker uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-dark divide-y divide-dark-lighter animate-pulse">
              {Array(5).fill(0).map((_, index) => (
                <tr key={index}>
                  {Array(8).fill(0).map((_, cellIndex) => (
                    <td key={cellIndex} className="px-6 py-4 whitespace-nowrap">
                      <div className="h-4 bg-dark-lighter rounded"></div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
  
  if (isError) {
    return (
      <div className="bg-dark rounded-lg shadow-md border border-dark-lighter overflow-hidden mb-6 p-4">
        <div className="text-danger flex items-center justify-center p-6">
          <span className="material-icons mr-2">error</span>
          Failed to load trades. Please try again later.
        </div>
      </div>
    );
  }
  
  // Status styles
  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'active':
        return 'status-active';
      case 'warning':
        return 'status-warning';
      case 'error':
        return 'status-error';
      default:
        return 'status-inactive';
    }
  };
  
  return (
    <div className="bg-dark rounded-lg shadow-md border border-dark-lighter overflow-hidden mb-6">
      <div className="p-4 border-b border-dark-lighter flex justify-between items-center">
        <div>
          <h3 className="font-semibold">Active Trades</h3>
          <p className="text-sm text-light-darker">Currently open positions</p>
        </div>
        <Button 
          className="px-3 py-1 text-sm rounded-md bg-primary hover:bg-primary-dark text-white transition-colors flex items-center"
          onClick={navigateToTradesPage}
        >
          <span className="material-icons text-sm mr-1">add</span> New Trade
        </Button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-dark-lighter">
          <thead className="bg-dark-lighter">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Symbol</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Type</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Entry Price</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Current Price</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">P&L</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Duration</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Status</th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-light-darker uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-dark divide-y divide-dark-lighter">
            {paginatedTrades.length > 0 ? (
              paginatedTrades.map((trade) => (
                <tr key={trade.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="font-mono font-medium">{trade.symbol}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      trade.type === 'long' 
                        ? 'bg-secondary bg-opacity-10 text-secondary'
                        : 'bg-danger bg-opacity-10 text-danger'
                    }`}>
                      {trade.type === 'long' ? 'Long' : 'Short'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap font-mono">{formatCurrency(trade.entryPrice)}</td>
                  <td className={`px-6 py-4 whitespace-nowrap font-mono ${
                    trade.currentPrice && trade.entryPrice 
                      ? (trade.type === 'long' 
                          ? (trade.currentPrice > trade.entryPrice ? 'price-up' : 'price-down')
                          : (trade.currentPrice < trade.entryPrice ? 'price-up' : 'price-down')
                        )
                      : ''
                  }`}>
                    {formatCurrency(trade.currentPrice)}
                  </td>
                  <td className={`px-6 py-4 whitespace-nowrap font-mono ${
                    trade.profitLoss && trade.profitLoss > 0 ? 'text-secondary' : 'text-danger'
                  }`}>
                    {formatCurrency(trade.profitLoss)} ({formatPercentage(trade.profitLossPercentage)})
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {formatDuration(new Date(trade.createdAt))}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <span className={`status-dot ${getStatusStyle(trade.status)}`}></span>
                      <span>{trade.status.charAt(0).toUpperCase() + trade.status.slice(1)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="p-1 rounded hover:bg-dark-lighter text-light"
                        onClick={() => handleEditTrade(trade.id)}
                      >
                        <span className="material-icons text-sm">edit</span>
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="p-1 rounded hover:bg-dark-lighter text-danger"
                        onClick={() => handleCloseTrade(trade.id)}
                        disabled={closeTradeMutation.isPending}
                      >
                        <span className="material-icons text-sm">close</span>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={8} className="px-6 py-12 text-center text-light-darker">
                  No active trades found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      <div className="px-6 py-3 flex items-center justify-between border-t border-dark-lighter bg-dark">
        <div className="text-sm text-light-darker">
          Showing <span className="font-medium">{paginatedTrades.length}</span> of <span className="font-medium">{data?.length || 0}</span> trades
        </div>
        <div className="flex items-center space-x-2">
          <Button 
            variant="ghost" 
            size="sm"
            className="p-1 rounded hover:bg-dark-lighter" 
            disabled={page === 1}
            onClick={() => setPage(p => Math.max(1, p - 1))}
          >
            <span className="material-icons text-sm">chevron_left</span>
          </Button>
          
          {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
            <Button 
              key={p} 
              variant={p === page ? 'default' : 'ghost'} 
              size="sm"
              className={`px-3 py-1 text-xs rounded-full ${
                p === page 
                  ? 'bg-primary text-white' 
                  : 'hover:bg-dark-lighter'
              }`}
              onClick={() => setPage(p)}
            >
              {p}
            </Button>
          ))}
          
          <Button 
            variant="ghost" 
            size="sm"
            className="p-1 rounded hover:bg-dark-lighter" 
            disabled={page === totalPages || totalPages === 0}
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
          >
            <span className="material-icons text-sm">chevron_right</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
