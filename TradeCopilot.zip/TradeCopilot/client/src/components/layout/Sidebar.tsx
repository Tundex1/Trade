import { useQuery } from '@tanstack/react-query';
import { formatCurrency, formatPercentage } from '@/lib/utils';

interface MarketIndex {
  symbol: string;
  price: number;
  change: number;
  changePercentage: number;
}

export default function Sidebar() {
  const { data: marketIndices, isLoading: isLoadingMarket } = useQuery<MarketIndex[]>({
    queryKey: ['/api/market/indices'],
  });
  
  // Format market index names for display
  const formatIndexName = (symbol: string) => {
    switch (symbol) {
      case 'SPX':
        return 'S&P 500';
      case 'COMP':
        return 'NASDAQ';
      case 'DJI':
        return 'DOW';
      case 'VIX':
        return 'VIX';
      default:
        return symbol;
    }
  };
  
  return (
    <aside className="hidden lg:block w-80 border-l border-dark-lighter bg-dark p-4 overflow-y-auto">
      <div className="mb-6">
        <h3 className="text-sm font-semibold mb-3">Navigation</h3>
        <div className="bg-dark-lighter rounded overflow-hidden">
          <a href="/" className="flex items-center p-3 hover:bg-dark-darker transition-colors">
            <span className="material-icons mr-2">dashboard</span>
            Dashboard
          </a>
          <a href="/trades" className="flex items-center p-3 hover:bg-dark-darker transition-colors">
            <span className="material-icons mr-2">trending_up</span>
            Trades
          </a>
          <a href="/trade-history" className="flex items-center p-3 hover:bg-dark-darker transition-colors">
            <span className="material-icons mr-2">history</span>
            Trade History
          </a>
          <a href="/accounts" className="flex items-center p-3 hover:bg-dark-darker transition-colors">
            <span className="material-icons mr-2">account_balance</span>
            Accounts
          </a>
          <a href="/copy-trading" className="flex items-center p-3 hover:bg-dark-darker transition-colors">
            <span className="material-icons mr-2">content_copy</span>
            Copy Trading
          </a>
          <a href="/settings" className="flex items-center p-3 hover:bg-dark-darker transition-colors">
            <span className="material-icons mr-2">settings</span>
            Settings
          </a>
        </div>
      </div>
      
      <div className="mb-6">
        <h3 className="text-sm font-semibold mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-2">
          <button className="p-2 bg-dark-lighter hover:bg-dark-darker rounded text-sm transition-colors flex flex-col items-center justify-center">
            <span className="material-icons mb-1">add_circle</span>
            New Trade
          </button>
          <button className="p-2 bg-dark-lighter hover:bg-dark-darker rounded text-sm transition-colors flex flex-col items-center justify-center">
            <span className="material-icons mb-1">sync</span>
            Sync Data
          </button>
          <button className="p-2 bg-dark-lighter hover:bg-dark-darker rounded text-sm transition-colors flex flex-col items-center justify-center">
            <span className="material-icons mb-1">person_add</span>
            Add Account
          </button>
          <button className="p-2 bg-dark-lighter hover:bg-dark-darker rounded text-sm transition-colors flex flex-col items-center justify-center">
            <span className="material-icons mb-1">file_download</span>
            Export
          </button>
        </div>
      </div>
      
      <div className="mb-6">
        <h3 className="text-sm font-semibold mb-3">Market Overview</h3>
        <div className="space-y-3">
          {isLoadingMarket ? (
            Array(4).fill(0).map((_, i) => (
              <div key={i} className="bg-dark-lighter p-3 rounded animate-pulse">
                <div className="h-6 bg-dark-darker rounded" />
              </div>
            ))
          ) : (
            marketIndices?.map((index) => (
              <div key={index.symbol} className="bg-dark-lighter p-3 rounded flex justify-between items-center">
                <div className="flex items-center">
                  <span className="font-mono font-medium">{formatIndexName(index.symbol)}</span>
                </div>
                <div className="flex flex-col items-end">
                  <span className="font-mono">{formatCurrency(index.price)}</span>
                  <span className={`text-xs ${index.changePercentage >= 0 ? 'text-secondary' : 'text-danger'}`}>
                    {formatPercentage(index.changePercentage)}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      
      <div className="mb-6">
        <h3 className="text-sm font-semibold mb-3">System Status</h3>
        <div className="bg-dark-lighter p-3 rounded space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm">API Connection</span>
            <div className="flex items-center">
              <span className="status-dot status-active"></span>
              <span className="text-sm">Online</span>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm">WebSocket</span>
            <div className="flex items-center">
              <span className="status-dot status-active"></span>
              <span className="text-sm">Connected</span>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm">Database</span>
            <div className="flex items-center">
              <span className="status-dot status-active"></span>
              <span className="text-sm">Operational</span>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm">Last Data Sync</span>
            <span className="text-sm">3 minutes ago</span>
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="text-sm font-semibold mb-3">Recent Notifications</h3>
        <div className="space-y-3">
          <div className="bg-dark-lighter p-3 rounded border-l-4 border-primary">
            <div className="flex justify-between items-start mb-1">
              <span className="font-medium text-sm">Trade Executed</span>
              <span className="text-xs text-light-darker">12:45 PM</span>
            </div>
            <p className="text-xs text-light-darker">Buy order for AAPL executed at $194.68 successfully.</p>
          </div>
          
          <div className="bg-dark-lighter p-3 rounded border-l-4 border-danger">
            <div className="flex justify-between items-start mb-1">
              <span className="font-medium text-sm">Connection Error</span>
              <span className="text-xs text-light-darker">11:23 AM</span>
            </div>
            <p className="text-xs text-light-darker">Account ID 43921 authentication failed. Please check credentials.</p>
          </div>
          
          <div className="bg-dark-lighter p-3 rounded border-l-4 border-warning">
            <div className="flex justify-between items-start mb-1">
              <span className="font-medium text-sm">Stop Loss Warning</span>
              <span className="text-xs text-light-darker">09:17 AM</span>
            </div>
            <p className="text-xs text-light-darker">AMZN position approaching stop loss threshold.</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
