import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/ui/button';
import { useWebSocket } from '@/lib/websocket';
import { Link } from 'wouter';

export default function Header() {
  const { user, logout } = useAuth();
  const { status: wsStatus } = useWebSocket();
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  
  const toggleUserMenu = () => {
    setIsUserMenuOpen(!isUserMenuOpen);
  };
  
  const handleLogout = () => {
    logout();
    setIsUserMenuOpen(false);
  };
  
  const getConnectionStatus = () => {
    switch (wsStatus) {
      case 'connected':
        return { class: 'status-active', text: 'Connected' };
      case 'connecting':
        return { class: 'status-pending', text: 'Connecting...' };
      case 'disconnected':
        return { class: 'status-inactive', text: 'Disconnected' };
      case 'error':
        return { class: 'status-error', text: 'Error' };
      default:
        return { class: 'status-inactive', text: 'Disconnected' };
    }
  };
  
  const connectionStatus = getConnectionStatus();
  
  // User avatar - use first letter of username
  const userInitial = user?.username?.charAt(0).toUpperCase() || 'A';
  
  return (
    <header className="bg-dark px-6 py-3 shadow-md border-b border-dark-lighter sticky top-0 z-40">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="text-xl font-bold mr-6">
            <span className="text-primary">Trade</span><span className="text-light">Swim</span>
          </h1>
          
          <div className="hidden md:flex space-x-6">
            <Link href="/" className="text-light hover:text-primary text-sm font-semibold transition duration-200">Dashboard</Link>
            <Link href="/trades" className="text-light hover:text-primary text-sm font-semibold transition duration-200">Trades</Link>
            <Link href="/accounts" className="text-light hover:text-primary text-sm font-semibold transition duration-200">Accounts</Link>
            <Link href="/settings" className="text-light hover:text-primary text-sm font-semibold transition duration-200">Settings</Link>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <span className={`status-dot ${connectionStatus.class}`}></span>
            <span className="text-sm mr-3">{connectionStatus.text}</span>
          </div>
          
          <div className="relative">
            <Button
              variant="ghost"
              className="flex items-center space-x-2 focus:outline-none"
              onClick={toggleUserMenu}
            >
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                <span className="text-white text-sm font-semibold">{userInitial}</span>
              </div>
              <span className="hidden md:inline-block text-sm font-semibold">{user?.username || 'Admin'}</span>
              <span className="material-icons text-sm">expand_more</span>
            </Button>
            
            {isUserMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-dark-lighter rounded-md shadow-lg py-1">
                <Link href="/settings" className="block px-4 py-2 text-sm hover:bg-dark-darker">Profile</Link>
                <Link href="/settings" className="block px-4 py-2 text-sm hover:bg-dark-darker">API Settings</Link>
                <hr className="border-dark-lighter my-1" />
                <Button
                  variant="ghost"
                  className="block w-full text-left px-4 py-2 text-sm text-danger hover:bg-dark-darker"
                  onClick={handleLogout}
                >
                  Sign Out
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
