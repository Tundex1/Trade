import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  AlertTriangle, 
  Copy, 
  Unlink, 
  Link, 
  Settings,
  Sliders, 
  DollarSign, 
  Percent, 
  AlertCircle, 
  Check, 
  X, 
  RefreshCw,
  Shield
} from 'lucide-react';
import { Account } from '@shared/schema';
import { formatCurrency } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';

// Add new properties to Account type
interface AccountExtension {
  fixedQuantity?: number;
  percentAllocation?: number;
  killSwitchEnabled?: boolean;
}

// Use type intersection to create our extended type
type ExtendedAccount = Account & AccountExtension;

interface CopySettingsDialogProps {
  account: Account;
  onClose: () => void;
  onSave: (accountId: number, settings: Partial<Account>) => Promise<void>;
}

const CopySettingsDialog: React.FC<CopySettingsDialogProps> = ({ account, onClose, onSave }) => {
  const [copyMode, setCopyMode] = useState(account.copyMode || 'exact');
  // Use type assertion to access custom properties
  const extAccount = account as any;
  const [fixedQuantity, setFixedQuantity] = useState(extAccount.fixedQuantity?.toString() || '');
  const [percentAllocation, setPercentAllocation] = useState(extAccount.percentAllocation?.toString() || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSave = async () => {
    setIsSubmitting(true);
    
    try {
      const settings: Partial<ExtendedAccount> = {
        copyMode,
      };
      
      if (copyMode === 'fixed') {
        const quantity = parseInt(fixedQuantity, 10);
        if (isNaN(quantity) || quantity <= 0) {
          throw new Error('Invalid fixed quantity');
        }
        settings.fixedQuantity = quantity;
      } else if (copyMode === 'percentage') {
        const percent = parseFloat(percentAllocation);
        if (isNaN(percent) || percent <= 0 || percent > 100) {
          throw new Error('Percentage must be between 1 and 100');
        }
        settings.percentAllocation = percent;
      }
      
      await onSave(account.id, settings);
      toast({
        title: 'Settings updated',
        description: 'Copy trading settings have been updated successfully',
      });
      onClose();
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to update settings',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={() => onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Copy Trading Settings</DialogTitle>
          <DialogDescription>
            Configure how trades will be copied to account: <span className="font-semibold">{account.accountName}</span>
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 my-6">
          <div>
            <Label className="mb-2 block">Copy Mode</Label>
            <Select value={copyMode} onValueChange={(value) => setCopyMode(value as "exact" | "fixed" | "percentage")}>
              <SelectTrigger>
                <SelectValue placeholder="Select copy mode" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="exact">Exact Copy (Same Quantity)</SelectItem>
                <SelectItem value="fixed">Fixed Quantity</SelectItem>
                <SelectItem value="percentage">Percentage of Capital</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {copyMode === 'fixed' && (
            <div>
              <Label className="mb-2 block">Fixed Quantity</Label>
              <Input 
                type="number" 
                value={fixedQuantity}
                onChange={(e) => setFixedQuantity(e.target.value)}
                placeholder="Enter quantity (e.g. 10)"
                min="1"
              />
              <p className="text-xs text-muted-foreground mt-1">
                All trades will use this exact quantity regardless of the master account
              </p>
            </div>
          )}
          
          {copyMode === 'percentage' && (
            <div>
              <Label className="mb-2 block">Percentage of Capital (%)</Label>
              <Input 
                type="number" 
                value={percentAllocation}
                onChange={(e) => setPercentAllocation(e.target.value)}
                placeholder="Enter percentage (e.g. 50)"
                min="1"
                max="100"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Trades will be sized proportionally to your account balance
              </p>
            </div>
          )}
          
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Important</AlertTitle>
            <AlertDescription>
              These settings affect how trades are copied. Make sure your account has sufficient funds.
            </AlertDescription>
          </Alert>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Check className="mr-2 h-4 w-4" />
                Save Settings
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const RiskSettingsDialog: React.FC<CopySettingsDialogProps> = ({ account, onClose, onSave }) => {
  const [maxTradeSize, setMaxTradeSize] = useState(account.maxTradeSize?.toString() || '');
  const [maxDailyDrawdown, setMaxDailyDrawdown] = useState(account.maxDailyDrawdown?.toString() || '');
  // Use type assertion for the custom property
  const extAccount = account as any;
  const [isKillSwitchEnabled, setIsKillSwitchEnabled] = useState(extAccount.killSwitchEnabled || false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSave = async () => {
    setIsSubmitting(true);
    
    try {
      const settings: Partial<Account> = {
        killSwitchEnabled: isKillSwitchEnabled,
      };
      
      if (maxTradeSize) {
        const size = parseFloat(maxTradeSize);
        if (isNaN(size) || size <= 0) {
          throw new Error('Invalid maximum trade size');
        }
        settings.maxTradeSize = size;
      }
      
      if (maxDailyDrawdown) {
        const drawdown = parseFloat(maxDailyDrawdown);
        if (isNaN(drawdown) || drawdown <= 0 || drawdown > 100) {
          throw new Error('Invalid maximum daily drawdown');
        }
        settings.maxDailyDrawdown = drawdown;
      }
      
      await onSave(account.id, settings);
      toast({
        title: 'Risk settings updated',
        description: 'Account risk management settings have been updated successfully',
      });
      onClose();
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to update risk settings',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={() => onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Risk Management Settings</DialogTitle>
          <DialogDescription>
            Configure risk management for account: <span className="font-semibold">{account.accountName}</span>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 my-6">
          <div>
            <Label className="mb-2 block">Maximum Trade Size ($)</Label>
            <Input 
              type="number" 
              value={maxTradeSize}
              onChange={(e) => setMaxTradeSize(e.target.value)}
              placeholder="Max position size (e.g. 1000)"
              min="0"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Trades exceeding this dollar amount will not be executed
            </p>
          </div>
          
          <div>
            <Label className="mb-2 block">Maximum Daily Drawdown (%)</Label>
            <Input 
              type="number" 
              value={maxDailyDrawdown}
              onChange={(e) => setMaxDailyDrawdown(e.target.value)}
              placeholder="Max daily loss (e.g. 5)"
              min="0"
              max="100"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Trading will be paused if daily losses exceed this percentage
            </p>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="block">Emergency Kill Switch</Label>
              <p className="text-xs text-muted-foreground">
                Immediately stops all trading activity
              </p>
            </div>
            <Switch 
              checked={isKillSwitchEnabled} 
              onCheckedChange={setIsKillSwitchEnabled}
            />
          </div>
          
          <Alert className="bg-red-100 dark:bg-red-900/20 border-red-200 dark:border-red-800">
            <AlertCircle className="h-4 w-4 text-red-500" />
            <AlertTitle className="text-red-700 dark:text-red-300">Risk Warning</AlertTitle>
            <AlertDescription className="text-red-600 dark:text-red-400">
              Proper risk management is critical. Even with these settings, trading involves risk of loss.
            </AlertDescription>
          </Alert>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Check className="mr-2 h-4 w-4" />
                Save Settings
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const AccountStatusBadge: React.FC<{ status: string }> = ({ status }) => {
  switch (status) {
    case 'connected':
      return <Badge className="bg-green-500 hover:bg-green-600">Connected</Badge>;
    case 'paused':
      return <Badge className="bg-yellow-500 hover:bg-yellow-600">Paused</Badge>;
    case 'auth_failed':
      return <Badge className="bg-red-500 hover:bg-red-600">Auth Failed</Badge>;
    case 'disconnected':
      return <Badge className="bg-gray-500 hover:bg-gray-600">Disconnected</Badge>;
    default:
      return <Badge>{status}</Badge>;
  }
};

const CopyModeDisplay: React.FC<{ account: Account }> = ({ account }) => {
  let icon = <Copy className="h-4 w-4 mr-1" />;
  let text = "Exact Copy";
  let detail = "Same quantity";
  
  // Use type assertion to access custom properties
  const extAccount = account as any;
  
  if (account.copyMode === 'fixed') {
    icon = <DollarSign className="h-4 w-4 mr-1" />;
    text = "Fixed Quantity";
    detail = `${extAccount.fixedQuantity || 0} units`;
  } else if (account.copyMode === 'percentage') {
    icon = <Percent className="h-4 w-4 mr-1" />;
    text = "Percentage";
    detail = `${extAccount.percentAllocation || 0}% of capital`;
  }
  
  return (
    <div className="flex flex-col">
      <div className="flex items-center text-sm font-medium">
        {icon} {text}
      </div>
      <span className="text-xs text-muted-foreground">{detail}</span>
    </div>
  );
};

const CopyTrading: React.FC = () => {
  const { toast } = useToast();
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);
  const [dialogType, setDialogType] = useState<'copy' | 'risk' | null>(null);
  
  // Fetch accounts data
  const { data: accounts, isLoading, isError, refetch } = useQuery<Account[]>({
    queryKey: ['/api/accounts'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/accounts');
      if (!response.ok) {
        throw new Error('Failed to fetch accounts');
      }
      return response.json();
    },
  });

  // Toggle account pause/resume
  const toggleAccountStatus = async (accountId: number, isPaused: boolean) => {
    try {
      const action = isPaused ? 'resume' : 'pause';
      await apiRequest('POST', `/api/accounts/${accountId}/${action}`);
      
      toast({
        title: 'Account Updated',
        description: `Account has been ${isPaused ? 'resumed' : 'paused'} successfully`,
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
    } catch (error) {
      toast({
        title: 'Action Failed',
        description: 'Failed to update account status',
        variant: 'destructive',
      });
    }
  };

  // Toggle kill switch
  const toggleKillSwitch = async (accountId: number, enabled: boolean) => {
    try {
      await apiRequest('POST', `/api/accounts/${accountId}/kill-switch`, { enabled });
      
      toast({
        title: enabled ? 'Kill Switch Activated' : 'Kill Switch Deactivated',
        description: enabled 
          ? 'All trading activity has been stopped for this account' 
          : 'Trading activity has been re-enabled for this account',
        variant: enabled ? 'destructive' : 'default',
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
    } catch (error) {
      toast({
        title: 'Action Failed',
        description: 'Failed to toggle kill switch',
        variant: 'destructive',
      });
    }
  };

  // Update copy settings
  const updateCopySettings = async (accountId: number, settings: Partial<Account>) => {
    await apiRequest('PUT', `/api/accounts/${accountId}/copy-settings`, settings);
    queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
  };

  // Update risk settings
  const updateRiskSettings = async (accountId: number, settings: Partial<Account>) => {
    await apiRequest('PUT', `/api/accounts/${accountId}/risk-settings`, settings);
    queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
  };

  // Open dialog
  const openDialog = (account: Account, type: 'copy' | 'risk') => {
    setSelectedAccount(account);
    setDialogType(type);
  };

  // Close dialog
  const closeDialog = () => {
    setSelectedAccount(null);
    setDialogType(null);
  };

  return (
    <div className="container mx-auto py-6">
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Copy Trading Management</CardTitle>
            <CardDescription>
              Configure how trades are copied across accounts
            </CardDescription>
          </div>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            // Loading skeleton
            Array(3).fill(0).map((_, index) => (
              <div key={index} className="mb-4">
                <Skeleton className="h-16 w-full" />
              </div>
            ))
          ) : isError ? (
            // Error state
            <div className="text-center py-8">
              <AlertTriangle className="mx-auto h-12 w-12 text-red-500 mb-4" />
              <h3 className="text-lg font-medium mb-2">Failed to load accounts</h3>
              <p className="text-muted-foreground mb-4">There was an error loading your accounts</p>
              <Button variant="outline" onClick={() => refetch()}>
                Try Again
              </Button>
            </div>
          ) : accounts && accounts.length > 0 ? (
            // Account table
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Account</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Copy Mode</TableHead>
                  <TableHead>Risk Controls</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accounts.map((account) => (
                  <TableRow key={account.id}>
                    <TableCell>
                      <div className="font-medium">{account.accountName}</div>
                      <div className="text-xs text-muted-foreground">{account.accountId}</div>
                    </TableCell>
                    <TableCell>
                      <AccountStatusBadge status={account.status} />
                      {/* Use type assertion to safely access optional property */}
                      {(account as any).killSwitchEnabled && (
                        <Badge className="ml-2 bg-red-500 hover:bg-red-600">Kill Switch</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="font-mono">{formatCurrency(account.balance)}</div>
                      {account.pdtStatus && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger>
                              <Badge variant="outline" className="text-xs border-yellow-500 text-yellow-500">
                                PDT
                              </Badge>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Pattern Day Trader status active</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                    </TableCell>
                    <TableCell>
                      <CopyModeDisplay account={account} />
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {account.maxTradeSize && (
                          <div className="text-xs flex items-center">
                            <DollarSign className="h-3 w-3 mr-1" />
                            Max Trade: {formatCurrency(account.maxTradeSize)}
                          </div>
                        )}
                        {account.maxDailyDrawdown && (
                          <div className="text-xs flex items-center">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Max Drawdown: {account.maxDailyDrawdown}%
                          </div>
                        )}
                        {!account.maxTradeSize && !account.maxDailyDrawdown && (
                          <div className="text-xs text-muted-foreground">
                            No risk limits set
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => openDialog(account, 'copy')}
                              >
                                <Copy className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Copy Settings</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => openDialog(account, 'risk')}
                              >
                                <Shield className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Risk Settings</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant={account.status === 'paused' ? 'default' : 'outline'}
                                size="icon"
                                onClick={() => toggleAccountStatus(
                                  account.id, 
                                  account.status === 'paused'
                                )}
                              >
                                {account.status === 'paused' ? (
                                  <Link className="h-4 w-4" />
                                ) : (
                                  <Unlink className="h-4 w-4" />
                                )}
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>
                                {account.status === 'paused' ? 'Resume Account' : 'Pause Account'}
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant={(account as any).killSwitchEnabled ? 'default' : 'destructive'}
                                size="icon"
                                className={(account as any).killSwitchEnabled ? 'bg-red-500 hover:bg-red-600' : ''}
                                onClick={() => toggleKillSwitch(
                                  account.id, 
                                  !(account as any).killSwitchEnabled
                                )}
                              >
                                {(account as any).killSwitchEnabled ? (
                                  <Check className="h-4 w-4" />
                                ) : (
                                  <X className="h-4 w-4" />
                                )}
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>
                                {(account as any).killSwitchEnabled 
                                  ? 'Deactivate Kill Switch' 
                                  : 'Activate Kill Switch'}
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            // No accounts state
            <div className="text-center py-12">
              <Unlink className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No connected accounts</h3>
              <p className="text-muted-foreground mb-4">
                Connect a Schwab account to start copy trading
              </p>
              <Button variant="outline" onClick={() => refetch()}>
                Refresh Accounts
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Help card */}
      <Card>
        <CardHeader>
          <CardTitle>Copy Trading Guide</CardTitle>
          <CardDescription>
            Learn how to configure copy trading for optimal results
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex items-center">
                <Copy className="h-5 w-5 mr-2 text-primary" />
                <h3 className="font-medium">Copy Modes</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Choose how trades are copied between accounts:
              </p>
              <ul className="text-sm space-y-1 list-disc pl-5">
                <li><span className="font-medium">Exact Copy:</span> Same quantity as master</li>
                <li><span className="font-medium">Fixed Quantity:</span> Specific number of shares</li>
                <li><span className="font-medium">Percentage:</span> Based on account balance ratio</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center">
                <Shield className="h-5 w-5 mr-2 text-primary" />
                <h3 className="font-medium">Risk Management</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Protect your accounts with limits:
              </p>
              <ul className="text-sm space-y-1 list-disc pl-5">
                <li><span className="font-medium">Max Trade Size:</span> Limit per-position exposure</li>
                <li><span className="font-medium">Daily Drawdown:</span> Stop trading if losses exceed threshold</li>
                <li><span className="font-medium">Kill Switch:</span> Emergency stop for all trading</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center">
                <Sliders className="h-5 w-5 mr-2 text-primary" />
                <h3 className="font-medium">Best Practices</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Tips for successful copy trading:
              </p>
              <ul className="text-sm space-y-1 list-disc pl-5">
                <li>Set copy mode based on account size differences</li>
                <li>Use risk limits appropriate to your risk tolerance</li>
                <li>Monitor account status regularly during trading hours</li>
                <li>Pause accounts during market volatility if needed</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Dialogs */}
      {selectedAccount && dialogType === 'copy' && (
        <CopySettingsDialog
          account={selectedAccount}
          onClose={closeDialog}
          onSave={updateCopySettings}
        />
      )}
      
      {selectedAccount && dialogType === 'risk' && (
        <RiskSettingsDialog
          account={selectedAccount}
          onClose={closeDialog}
          onSave={updateRiskSettings}
        />
      )}
    </div>
  );
};

export default CopyTrading;