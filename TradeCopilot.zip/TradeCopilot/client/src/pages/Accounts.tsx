"use client"

import type React from "react"

import { useState } from "react"
import { Helmet } from "react-helmet"
import { useQuery, useMutation } from "@tanstack/react-query"
import { queryClient, apiRequest } from "@/lib/queryClient"
import type { Account, InsertAccount } from "@shared/schema"
import { useToast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import ConnectSchwabButton from "@/components/accounts/ConnectSchwabButton"
import OAuthStatusBadge from "@/components/accounts/OAuthStatusBadge"
import { RefreshCw, Plus, AlertCircle, Pause, Play, Trash, Settings, Shield, Power, PowerOff } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { formatCurrency, formatPercentage } from "@/lib/utils"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"

export default function Accounts() {
  const { toast } = useToast()
  const [isNewAccountDialogOpen, setIsNewAccountDialogOpen] = useState(false)
  const [accountForm, setAccountForm] = useState({
    accountName: "",
    accountId: "",
    accountType: "Schwab",
    apiKey: "",
    apiSecret: "",
  })

  const {
    data: accounts,
    isLoading,
    isError,
  } = useQuery<Account[]>({
    queryKey: ["/api/accounts"],
  })

  const createAccountMutation = useMutation({
    mutationFn: async (account: InsertAccount) => {
      const res = await apiRequest("POST", "/api/accounts", account)
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
      toast({
        title: "Account connected",
        description: "The account has been connected successfully",
      })
      setIsNewAccountDialogOpen(false)
      resetAccountForm()
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Connection failed",
        description: error instanceof Error ? error.message : "Failed to connect account",
      })
    },
  })

  const pauseAccountMutation = useMutation({
    mutationFn: async (accountId: number) => {
      const res = await apiRequest("POST", `/api/accounts/${accountId}/pause`)
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
      toast({
        title: "Account paused",
        description: "The account has been paused successfully",
      })
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to pause account",
      })
    },
  })

  const resumeAccountMutation = useMutation({
    mutationFn: async (accountId: number) => {
      const res = await apiRequest("POST", `/api/accounts/${accountId}/resume`)
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
      toast({
        title: "Account resumed",
        description: "The account has been resumed successfully",
      })
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to resume account",
      })
    },
  })

  const deleteAccountMutation = useMutation({
    mutationFn: async (accountId: number) => {
      const res = await apiRequest("DELETE", `/api/accounts/${accountId}`)
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
      toast({
        title: "Account deleted",
        description: "The account has been deleted successfully",
      })
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete account",
      })
    },
  })

  const syncAccountMutation = useMutation({
    mutationFn: async (accountId: number) => {
      const res = await apiRequest("POST", `/api/accounts/${accountId}/sync`)
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
      toast({
        title: "Account synced",
        description: "The account has been synced successfully with the latest data",
      })
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Sync failed",
        description: error instanceof Error ? error.message : "Failed to sync account",
      })
    },
  })

  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null)
  const [isCopySettingsOpen, setIsCopySettingsOpen] = useState(false)
  const [isRiskManagementOpen, setIsRiskManagementOpen] = useState(false)
  const [isKillSwitchDialogOpen, setIsKillSwitchDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  // Copy settings form
  const [copySettingsForm, setCopySettingsForm] = useState({
    copyMode: "exact",
    copyAllocation: 100,
  })

  // Risk management form
  const [riskSettingsForm, setRiskSettingsForm] = useState({
    maxTradeSize: 0,
    maxDailyDrawdown: 0,
    tradingStartTime: "",
    tradingEndTime: "",
    blockedSymbols: "",
    emergencyKillSwitch: false,
  })

  const updateCopySettingsMutation = useMutation({
    mutationFn: async ({ accountId, data }: { accountId: number; data: any }) => {
      const res = await apiRequest("PUT", `/api/accounts/${accountId}/copy-settings`, data)
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
      toast({
        title: "Copy settings updated",
        description: "The copy trading settings have been updated successfully",
      })
      setIsCopySettingsOpen(false)
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: error instanceof Error ? error.message : "Failed to update copy settings",
      })
    },
  })

  const updateRiskManagementMutation = useMutation({
    mutationFn: async ({ accountId, data }: { accountId: number; data: any }) => {
      const res = await apiRequest("PUT", `/api/accounts/${accountId}/risk-management`, data)
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
      toast({
        title: "Risk settings updated",
        description: "The risk management settings have been updated successfully",
      })
      setIsRiskManagementOpen(false)
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: error instanceof Error ? error.message : "Failed to update risk management settings",
      })
    },
  })

  const toggleKillSwitchMutation = useMutation({
    mutationFn: async ({ accountId, enabled }: { accountId: number; enabled: boolean }) => {
      const res = await apiRequest("POST", `/api/accounts/${accountId}/kill-switch`, { enabled })
      return res.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
      toast({
        title: "Kill switch updated",
        description: riskSettingsForm.emergencyKillSwitch
          ? "Emergency kill switch has been activated"
          : "Emergency kill switch has been deactivated",
        variant: riskSettingsForm.emergencyKillSwitch ? "destructive" : "default",
      })
      setIsKillSwitchDialogOpen(false)
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: error instanceof Error ? error.message : "Failed to update kill switch",
      })
    },
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setAccountForm((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const account: InsertAccount = {
      accountName: accountForm.accountName,
      accountId: accountForm.accountId,
      accountType: accountForm.accountType,
      apiKey: accountForm.apiKey,
      apiSecret: accountForm.apiSecret,
      balance: 0, // This will be updated by the API
      status: "connected",
      activeTrades: 0,
      monthlyProfitLoss: 0,
      monthlyProfitLossPercentage: 0,
    }

    createAccountMutation.mutate(account)
  }

  const resetAccountForm = () => {
    setAccountForm({
      accountName: "",
      accountId: "",
      accountType: "Schwab",
      apiKey: "",
      apiSecret: "",
    })
  }

  const handlePauseAccount = (accountId: number) => {
    pauseAccountMutation.mutate(accountId)
  }

  const handleResumeAccount = (accountId: number) => {
    resumeAccountMutation.mutate(accountId)
  }

  const openDeleteDialog = (account: Account) => {
    setSelectedAccount(account)
    setIsDeleteDialogOpen(true)
  }

  const handleDeleteAccount = () => {
    if (!selectedAccount) return
    deleteAccountMutation.mutate(selectedAccount.id)
    setIsDeleteDialogOpen(false)
  }

  const handleSyncAccount = (accountId: number) => {
    syncAccountMutation.mutate(accountId)
  }

  const handleSyncAllAccounts = () => {
    accounts?.forEach((account) => {
      if (account.status === "connected" || account.status === "auth_failed") {
        syncAccountMutation.mutate(account.id)
      }
    })

    toast({
      title: "Syncing all accounts",
      description: "The system is syncing all accounts. This may take a moment.",
    })
  }

  const openCopySettings = (account: Account) => {
    setSelectedAccount(account)
    setCopySettingsForm({
      copyMode: account.copyMode || "exact",
      copyAllocation: account.copyAllocation || 100,
    })
    setIsCopySettingsOpen(true)
  }

  const openRiskManagement = (account: Account) => {
    setSelectedAccount(account)
    setRiskSettingsForm({
      maxTradeSize: account.maxTradeSize || 0,
      maxDailyDrawdown: account.maxDailyDrawdown || 0,
      tradingStartTime: account.tradingStartTime || "09:30",
      tradingEndTime: account.tradingEndTime || "16:00",
      blockedSymbols: account.blockedSymbols?.join(",") || "",
      emergencyKillSwitch: account.emergencyKillSwitch || false,
    })
    setIsRiskManagementOpen(true)
  }

  const openKillSwitchDialog = (account: Account) => {
    setSelectedAccount(account)
    setRiskSettingsForm((prev) => ({
      ...prev,
      emergencyKillSwitch: !account.emergencyKillSwitch,
    }))
    setIsKillSwitchDialogOpen(true)
  }

  const handleCopySettingsSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedAccount) return

    updateCopySettingsMutation.mutate({
      accountId: selectedAccount.id,
      data: {
        copyMode: copySettingsForm.copyMode,
        copyAllocation: copySettingsForm.copyAllocation,
      },
    })
  }

  const handleRiskManagementSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedAccount) return

    updateRiskManagementMutation.mutate({
      accountId: selectedAccount.id,
      data: {
        maxTradeSize: riskSettingsForm.maxTradeSize,
        maxDailyDrawdown: riskSettingsForm.maxDailyDrawdown,
        tradingStartTime: riskSettingsForm.tradingStartTime,
        tradingEndTime: riskSettingsForm.tradingEndTime,
        blockedSymbols: riskSettingsForm.blockedSymbols
          .split(",")
          .map((s) => s.trim())
          .filter((s) => s),
      },
    })
  }

  const handleKillSwitchConfirm = () => {
    if (!selectedAccount) return

    toggleKillSwitchMutation.mutate({
      accountId: selectedAccount.id,
      enabled: riskSettingsForm.emergencyKillSwitch,
    })
  }

  const handleCopyModeChange = (value: string) => {
    setCopySettingsForm((prev) => ({
      ...prev,
      copyMode: value,
    }))
  }

  const handleCopyAllocationChange = (value: number[]) => {
    setCopySettingsForm((prev) => ({
      ...prev,
      copyAllocation: value[0],
    }))
  }

  const handleRiskSettingsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target
    setRiskSettingsForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? (e.target as HTMLInputElement).checked : value,
    }))
  }

  // Status styles and text
  const getStatusInfo = (status: string) => {
    switch (status) {
      case "connected":
        return { dotClass: "status-active", text: "Connected" }
      case "paused":
        return { dotClass: "status-inactive", text: "Paused" }
      case "auth_failed":
        return { dotClass: "status-error", text: "Auth Failed" }
      case "disconnected":
        return { dotClass: "status-inactive", text: "Disconnected" }
      default:
        return { dotClass: "status-inactive", text: status }
    }
  }

  return (
    <>
      <Helmet>
        <title>Accounts - TradeSwim Admin Copy Trading Platform</title>
        <meta name="description" content="Manage connected Schwab trading accounts for copy trading." />
      </Helmet>

      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Accounts Management</h2>

        <div className="flex space-x-2">
          <Button
            variant="outline"
            className="flex items-center"
            onClick={handleSyncAllAccounts}
            disabled={syncAccountMutation.isPending || !accounts || accounts.length === 0}
          >
            <RefreshCw className="h-4 w-4 mr-1" />
            Sync All
          </Button>

          {/* Always show the Connect to Schwab button prominently */}
          <ConnectSchwabButton
            accountId={accounts && accounts.length > 0 ? accounts[0].id : 0}
            onSuccess={() => {
              queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
              toast({
                title: "Connection Successful",
                description: "Your Schwab account is now connected via OAuth",
              })
            }}
          />

          <Dialog open={isNewAccountDialogOpen} onOpenChange={setIsNewAccountDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center">
                <Plus className="h-4 w-4 mr-1" />
                Add Account Manually
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px] bg-dark border-dark-lighter text-light">
              <DialogHeader>
                <DialogTitle>Add Trading Account Manually</DialogTitle>
                <DialogDescription className="text-light-darker">
                  Enter account details to add a trading account manually. For Schwab accounts, we recommend using the
                  "Connect to Schwab" button instead.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleAccountSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <Label htmlFor="accountName">Account Name</Label>
                      <Input
                        id="accountName"
                        name="accountName"
                        value={accountForm.accountName}
                        onChange={handleInputChange}
                        className="bg-dark-darker border-dark-lighter text-light"
                        placeholder="John's Trading Account"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-1">
                      <Label htmlFor="accountId">Account ID</Label>
                      <Input
                        id="accountId"
                        name="accountId"
                        value={accountForm.accountId}
                        onChange={handleInputChange}
                        className="bg-dark-darker border-dark-lighter text-light"
                        placeholder="123456789"
                        required
                      />
                    </div>
                    <div className="col-span-1">
                      <Label htmlFor="accountType">Account Type</Label>
                      <Input
                        id="accountType"
                        name="accountType"
                        value={accountForm.accountType}
                        onChange={handleInputChange}
                        className="bg-dark-darker border-dark-lighter text-light"
                        placeholder="Schwab"
                        disabled
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div className="col-span-1">
                      <Label htmlFor="apiKey">API Key</Label>
                      <Input
                        id="apiKey"
                        name="apiKey"
                        value={accountForm.apiKey}
                        onChange={handleInputChange}
                        className="bg-dark-darker border-dark-lighter text-light"
                        placeholder="Enter API Key"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div className="col-span-1">
                      <Label htmlFor="apiSecret">API Secret</Label>
                      <Input
                        id="apiSecret"
                        name="apiSecret"
                        type="password"
                        value={accountForm.apiSecret}
                        onChange={handleInputChange}
                        className="bg-dark-darker border-dark-lighter text-light"
                        placeholder="Enter API Secret"
                        required
                      />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsNewAccountDialogOpen(false)}
                    className="bg-dark-lighter text-light border-dark-lighter hover:bg-dark-darker"
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createAccountMutation.isPending}>
                    {createAccountMutation.isPending ? "Connecting..." : "Add Account"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Add a prominent card for connecting to Schwab */}
      {(!accounts || accounts.length === 0) && (
        <Card className="bg-dark border-dark-lighter mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center justify-center p-6 text-center">
              <h3 className="text-xl font-semibold mb-2">Connect Your Schwab Account</h3>
              <p className="text-light-darker mb-4">
                Connect your Schwab trading account to enable automated copy trading. Your credentials are securely
                encrypted.
              </p>
              <ConnectSchwabButton
                accountId={0}
                onSuccess={() => {
                  queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
                  toast({
                    title: "Connection Successful",
                    description: "Your Schwab account is now connected via OAuth",
                  })
                }}
                isLarge={true}
              />
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-dark border-dark-lighter">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Connected Accounts</CardTitle>
              <CardDescription className="text-light-darker">
                Manage all accounts linked for copy trading
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="spinner"></div>
            </div>
          ) : isError ? (
            <div className="text-danger flex items-center justify-center p-6">
              <AlertCircle className="h-5 w-5 mr-2" />
              Failed to load accounts. Please try again later.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-dark-lighter">
                <thead className="bg-dark-lighter">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider"
                    >
                      Account
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider"
                    >
                      Type
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider"
                    >
                      Balance
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider"
                    >
                      Active Trades
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider"
                    >
                      P&L (Monthly)
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider"
                    >
                      Status
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider"
                    >
                      OAuth
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 text-center text-xs font-medium text-light-darker uppercase tracking-wider"
                    >
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-dark divide-y divide-dark-lighter">
                  {accounts && accounts.length > 0 ? (
                    accounts.map((account) => {
                      const statusInfo = getStatusInfo(account.status)

                      return (
                        <tr key={account.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="text-sm font-medium">{account.accountName}</div>
                              <div className="ml-2 text-xs text-light-darker">ID: {account.accountId}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-2 py-1 text-xs rounded-full bg-info bg-opacity-10 text-info">
                              {account.accountType}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap font-mono">{formatCurrency(account.balance)}</td>
                          <td className="px-6 py-4 whitespace-nowrap">{account.activeTrades}</td>
                          <td className="px-6 py-4 whitespace-nowrap font-mono">
                            <span className={account.monthlyProfitLoss >= 0 ? "text-secondary" : "text-danger"}>
                              {formatCurrency(account.monthlyProfitLoss)} (
                              {formatPercentage(account.monthlyProfitLossPercentage)})
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <span className={`status-dot ${statusInfo.dotClass}`}></span>
                              <span>{statusInfo.text}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <OAuthStatusBadge accountId={account.id} />
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-center">
                            <div className="flex justify-center space-x-3">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="p-1 rounded hover:bg-dark-lighter text-light"
                                onClick={() => handleSyncAccount(account.id)}
                                disabled={syncAccountMutation.isPending}
                              >
                                <RefreshCw className="h-4 w-4" />
                              </Button>

                              {account.status === "connected" ? (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="p-1 rounded hover:bg-dark-lighter text-warning"
                                  onClick={() => handlePauseAccount(account.id)}
                                  disabled={pauseAccountMutation.isPending}
                                >
                                  <Pause className="h-4 w-4" />
                                </Button>
                              ) : account.status === "paused" ? (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="p-1 rounded hover:bg-dark-lighter text-secondary"
                                  onClick={() => handleResumeAccount(account.id)}
                                  disabled={resumeAccountMutation.isPending}
                                >
                                  <Play className="h-4 w-4" />
                                </Button>
                              ) : account.status === "auth_failed" ? (
                                <ConnectSchwabButton
                                  accountId={account.id}
                                  onSuccess={() => {
                                    queryClient.invalidateQueries({ queryKey: ["/api/accounts"] })
                                  }}
                                />
                              ) : null}

                              <Button
                                variant="ghost"
                                size="sm"
                                className="p-1 rounded hover:bg-dark-lighter text-danger"
                                onClick={() => openDeleteDialog(account)}
                                disabled={deleteAccountMutation.isPending}
                                title="Delete Account"
                              >
                                <Trash className="h-4 w-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                className="p-1 rounded hover:bg-dark-lighter text-light"
                                onClick={() => openCopySettings(account)}
                              >
                                <Settings className="h-4 w-4" />
                              </Button>

                              <Button
                                variant="ghost"
                                size="sm"
                                className="p-1 rounded hover:bg-dark-lighter text-warning"
                                onClick={() => openRiskManagement(account)}
                              >
                                <Shield className="h-4 w-4" />
                              </Button>

                              <Button
                                variant={account.emergencyKillSwitch ? "default" : "outline"}
                                size="sm"
                                className={`p-1 rounded ${account.emergencyKillSwitch ? "bg-danger text-white" : "hover:bg-dark-lighter text-danger"}`}
                                onClick={() => openKillSwitchDialog(account)}
                              >
                                {account.emergencyKillSwitch ? (
                                  <PowerOff className="h-4 w-4" />
                                ) : (
                                  <Power className="h-4 w-4" />
                                )}
                              </Button>
                            </div>
                          </td>
                        </tr>
                      )
                    })
                  ) : (
                    <tr>
                      <td colSpan={8} className="px-6 py-12 text-center text-light-darker">
                        No accounts connected. Use the "Connect to Schwab" button above to link your trading account.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Copy Settings Dialog */}
      <Dialog open={isCopySettingsOpen} onOpenChange={setIsCopySettingsOpen}>
        <DialogContent className="sm:max-w-[500px] bg-dark border-dark-lighter text-light">
          <DialogHeader>
            <DialogTitle>Copy Trading Settings</DialogTitle>
            <DialogDescription className="text-light-darker">
              Configure how trades are copied to this account
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCopySettingsSubmit}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="copyMode">Copy Mode</Label>
                <Select value={copySettingsForm.copyMode} onValueChange={handleCopyModeChange}>
                  <SelectTrigger className="bg-dark-darker border-dark-lighter text-light">
                    <SelectValue placeholder="Select copy mode" />
                  </SelectTrigger>
                  <SelectContent className="bg-dark-darker border-dark-lighter text-light">
                    <SelectItem value="exact">Exact - Same share count</SelectItem>
                    <SelectItem value="percentage">Percentage - Based on account value</SelectItem>
                    <SelectItem value="fixed">Fixed - Set amount per trade</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-light-darker">
                  {copySettingsForm.copyMode === "exact" &&
                    "Copies trades with the exact same number of shares as the source trade."}
                  {copySettingsForm.copyMode === "percentage" &&
                    "Copies trades with a percentage of account value that matches the source trade."}
                  {copySettingsForm.copyMode === "fixed" &&
                    "Uses a fixed dollar amount for each trade, regardless of source trade size."}
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="copyAllocation">Copy Allocation: {copySettingsForm.copyAllocation}%</Label>
                </div>
                <Slider
                  id="copyAllocation"
                  min={1}
                  max={100}
                  step={1}
                  value={[copySettingsForm.copyAllocation]}
                  onValueChange={handleCopyAllocationChange}
                  className="pt-2"
                />
                <p className="text-sm text-light-darker">The percentage of available balance to use for copy trading</p>
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsCopySettingsOpen(false)}
                className="bg-dark-lighter text-light border-dark-lighter hover:bg-dark-darker"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={updateCopySettingsMutation.isPending}>
                {updateCopySettingsMutation.isPending ? "Updating..." : "Save Settings"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Risk Management Dialog */}
      <Dialog open={isRiskManagementOpen} onOpenChange={setIsRiskManagementOpen}>
        <DialogContent className="sm:max-w-[600px] bg-dark border-dark-lighter text-light">
          <DialogHeader>
            <DialogTitle>Risk Management Settings</DialogTitle>
            <DialogDescription className="text-light-darker">
              Configure risk parameters for this trading account
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRiskManagementSubmit}>
            <div className="grid gap-4 py-4">
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="position-limits" className="border-dark-lighter">
                  <AccordionTrigger className="text-light hover:text-primary">Position Limits</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 mt-2">
                      <div>
                        <Label htmlFor="maxTradeSize">Maximum Trade Size ($)</Label>
                        <Input
                          id="maxTradeSize"
                          name="maxTradeSize"
                          type="number"
                          value={riskSettingsForm.maxTradeSize}
                          onChange={handleRiskSettingsChange}
                          className="bg-dark-darker border-dark-lighter text-light"
                          placeholder="0 for no limit"
                          min="0"
                        />
                        <p className="text-xs text-light-darker mt-1">Maximum dollar amount per trade (0 = no limit)</p>
                      </div>

                      <div>
                        <Label htmlFor="maxDailyDrawdown">Maximum Daily Drawdown (%)</Label>
                        <Input
                          id="maxDailyDrawdown"
                          name="maxDailyDrawdown"
                          type="number"
                          value={riskSettingsForm.maxDailyDrawdown}
                          onChange={handleRiskSettingsChange}
                          className="bg-dark-darker border-dark-lighter text-light"
                          placeholder="0 for no limit"
                          min="0"
                          max="100"
                        />
                        <p className="text-xs text-light-darker mt-1">
                          Maximum percentage loss allowed in a single day (0 = no limit)
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="time-restrictions" className="border-dark-lighter">
                  <AccordionTrigger className="text-light hover:text-primary">Trading Hours</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-2 gap-4 mt-2">
                      <div>
                        <Label htmlFor="tradingStartTime">Trading Start Time</Label>
                        <Input
                          id="tradingStartTime"
                          name="tradingStartTime"
                          value={riskSettingsForm.tradingStartTime}
                          onChange={handleRiskSettingsChange}
                          className="bg-dark-darker border-dark-lighter text-light"
                          placeholder="09:30"
                        />
                        <p className="text-xs text-light-darker mt-1">Format: HH:MM (24h)</p>
                      </div>

                      <div>
                        <Label htmlFor="tradingEndTime">Trading End Time</Label>
                        <Input
                          id="tradingEndTime"
                          name="tradingEndTime"
                          value={riskSettingsForm.tradingEndTime}
                          onChange={handleRiskSettingsChange}
                          className="bg-dark-darker border-dark-lighter text-light"
                          placeholder="16:00"
                        />
                        <p className="text-xs text-light-darker mt-1">Format: HH:MM (24h)</p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="symbol-restrictions" className="border-dark-lighter">
                  <AccordionTrigger className="text-light hover:text-primary">Symbol Restrictions</AccordionTrigger>
                  <AccordionContent>
                    <div className="mt-2">
                      <Label htmlFor="blockedSymbols">Blocked Symbols</Label>
                      <Input
                        id="blockedSymbols"
                        name="blockedSymbols"
                        value={riskSettingsForm.blockedSymbols}
                        onChange={handleRiskSettingsChange}
                        className="bg-dark-darker border-dark-lighter text-light"
                        placeholder="TSLA,AAPL,META"
                      />
                      <p className="text-xs text-light-darker mt-1">
                        Comma-separated list of symbols to block from trading
                      </p>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsRiskManagementOpen(false)}
                className="bg-dark-lighter text-light border-dark-lighter hover:bg-dark-darker"
              >
                Cancel
              </Button>
              <Button type="submit" disabled={updateRiskManagementMutation.isPending}>
                {updateRiskManagementMutation.isPending ? "Updating..." : "Save Settings"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Kill Switch Dialog */}
      <Dialog open={isKillSwitchDialogOpen} onOpenChange={setIsKillSwitchDialogOpen}>
        <DialogContent className="sm:max-w-[400px] bg-dark border-dark-lighter text-light">
          <DialogHeader>
            <DialogTitle className={riskSettingsForm.emergencyKillSwitch ? "text-danger" : "text-warning"}>
              {riskSettingsForm.emergencyKillSwitch ? "Enable Emergency Kill Switch" : "Disable Emergency Kill Switch"}
            </DialogTitle>
            <DialogDescription className="text-light-darker">
              {riskSettingsForm.emergencyKillSwitch
                ? "This will immediately halt all trading activity for this account."
                : "This will re-enable trading for this account."}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="flex items-center justify-between py-4">
              <div className="space-y-0.5">
                <Label htmlFor="killSwitch">
                  {riskSettingsForm.emergencyKillSwitch ? "Enable Kill Switch" : "Disable Kill Switch"}
                </Label>
                <p className="text-sm text-light-darker">
                  {riskSettingsForm.emergencyKillSwitch
                    ? "All existing positions will remain open, but no new trades will be executed."
                    : "Trading will resume with the configured risk parameters."}
                </p>
              </div>
              <Switch
                id="killSwitch"
                name="emergencyKillSwitch"
                checked={riskSettingsForm.emergencyKillSwitch}
                onCheckedChange={(checked) => {
                  setRiskSettingsForm((prev) => ({ ...prev, emergencyKillSwitch: checked }))
                }}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsKillSwitchDialogOpen(false)}
              className="bg-dark-lighter text-light border-dark-lighter hover:bg-dark-darker"
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant={riskSettingsForm.emergencyKillSwitch ? "destructive" : "default"}
              disabled={toggleKillSwitchMutation.isPending}
              onClick={handleKillSwitchConfirm}
            >
              {toggleKillSwitchMutation.isPending
                ? "Updating..."
                : riskSettingsForm.emergencyKillSwitch
                  ? "Enable Kill Switch"
                  : "Disable Kill Switch"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Account Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[500px] bg-dark border-dark-lighter text-light">
          <DialogHeader>
            <DialogTitle>Delete Account</DialogTitle>
            <DialogDescription className="text-light-darker">
              Are you sure you want to delete this account?
              {selectedAccount && (
                <span className="font-semibold block mt-2">
                  {selectedAccount.accountName} ({selectedAccount.accountId})
                </span>
              )}
              <span className="block mt-2">
                This action cannot be undone. All account data, including trading history, will be permanently removed.
              </span>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-6">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
              className="bg-dark-lighter text-light border-dark-lighter hover:bg-dark-darker"
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={handleDeleteAccount}
              disabled={deleteAccountMutation.isPending}
              className="bg-danger hover:bg-danger/90 text-white"
            >
              {deleteAccountMutation.isPending ? "Deleting..." : "Delete Account"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
