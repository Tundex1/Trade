import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';

export default function Settings() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('profile');
  
  // API settings
  const [apiSettings, setApiSettings] = useState({
    schwabApiKey: import.meta.env.VITE_SCHWAB_API_KEY || '',
    schwabApiSecret: import.meta.env.VITE_SCHWAB_API_SECRET || '',
    schwabApiUrl: import.meta.env.VITE_SCHWAB_API_URL || '',
  });
  
  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    tradeExecuted: true,
    tradeError: true,
    accountSync: false,
    profitLossAlerts: true,
    marketUpdates: false,
  });
  
  // Profile settings
  const [profileSettings, setProfileSettings] = useState({
    username: user?.username || '',
    email: user?.email || '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  
  const handleApiSettingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setApiSettings(prev => ({
      ...prev,
      [name]: value,
    }));
  };
  
  const handleNotificationToggle = (setting: string) => {
    setNotificationSettings(prev => ({
      ...prev,
      [setting]: !prev[setting as keyof typeof prev],
    }));
  };
  
  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileSettings(prev => ({
      ...prev,
      [name]: value,
    }));
  };
  
  const handleSaveApiSettings = async () => {
    try {
      // Note: In a real app, we'd save these to environment variables or secure storage
      // This is just a UI simulation for the demo
      toast({
        title: 'API Settings Saved',
        description: 'Your API settings have been saved successfully',
      });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to save API settings',
      });
    }
  };
  
  const handleSaveNotificationSettings = async () => {
    try {
      // In a real app, we'd save these to the user's profile
      toast({
        title: 'Notification Settings Saved',
        description: 'Your notification preferences have been updated',
      });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to save notification settings',
      });
    }
  };
  
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate passwords match
    if (profileSettings.newPassword !== profileSettings.confirmPassword) {
      toast({
        variant: 'destructive',
        title: 'Password Mismatch',
        description: 'New password and confirmation do not match',
      });
      return;
    }
    
    try {
      // In a real app, we'd call an API endpoint to update the profile
      toast({
        title: 'Profile Updated',
        description: 'Your profile has been updated successfully',
      });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to update profile',
      });
    }
  };
  
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate passwords match
    if (profileSettings.newPassword !== profileSettings.confirmPassword) {
      toast({
        variant: 'destructive',
        title: 'Password Mismatch',
        description: 'New password and confirmation do not match',
      });
      return;
    }
    
    if (!profileSettings.currentPassword) {
      toast({
        variant: 'destructive',
        title: 'Current Password Required',
        description: 'Please enter your current password',
      });
      return;
    }
    
    try {
      // In a real app, we'd call an API endpoint to change the password
      toast({
        title: 'Password Changed',
        description: 'Your password has been changed successfully',
      });
      
      // Clear password fields
      setProfileSettings(prev => ({
        ...prev,
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      }));
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to change password',
      });
    }
  };
  
  return (
    <>
      <Helmet>
        <title>Settings - TradeSwim Admin Copy Trading Platform</title>
        <meta name="description" content="Configure your TradeSwim platform settings, API connections, and notification preferences." />
      </Helmet>
      
      <div className="mb-6">
        <h2 className="text-xl font-bold">Settings</h2>
        <p className="text-light-darker">Manage your account and platform settings</p>
      </div>
      
      <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-dark-lighter">
          <TabsTrigger value="profile" className="data-[state=active]:bg-primary data-[state=active]:text-white">Profile</TabsTrigger>
          <TabsTrigger value="api" className="data-[state=active]:bg-primary data-[state=active]:text-white">API Settings</TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:bg-primary data-[state=active]:text-white">Notifications</TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-primary data-[state=active]:text-white">Security</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile" className="space-y-4">
          <Card className="bg-dark border-dark-lighter">
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription className="text-light-darker">Manage your account information</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleUpdateProfile} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input 
                      id="username" 
                      name="username"
                      value={profileSettings.username}
                      onChange={handleProfileChange}
                      className="bg-dark-darker border-dark-lighter text-light"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      name="email"
                      type="email"
                      value={profileSettings.email}
                      onChange={handleProfileChange}
                      className="bg-dark-darker border-dark-lighter text-light"
                    />
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <Button type="submit">
                    Save Profile
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="api" className="space-y-4">
          <Card className="bg-dark border-dark-lighter">
            <CardHeader>
              <CardTitle>Schwab API Configuration</CardTitle>
              <CardDescription className="text-light-darker">Configure your Schwab Trading API credentials</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="schwabApiKey">API Key</Label>
                  <Input 
                    id="schwabApiKey" 
                    name="schwabApiKey"
                    value={apiSettings.schwabApiKey}
                    onChange={handleApiSettingChange}
                    className="bg-dark-darker border-dark-lighter text-light"
                    placeholder="Enter your Schwab API key"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="schwabApiSecret">API Secret</Label>
                  <Input 
                    id="schwabApiSecret" 
                    name="schwabApiSecret"
                    type="password"
                    value={apiSettings.schwabApiSecret}
                    onChange={handleApiSettingChange}
                    className="bg-dark-darker border-dark-lighter text-light"
                    placeholder="Enter your Schwab API secret"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="schwabApiUrl">API URL</Label>
                  <Input 
                    id="schwabApiUrl" 
                    name="schwabApiUrl"
                    value={apiSettings.schwabApiUrl}
                    onChange={handleApiSettingChange}
                    className="bg-dark-darker border-dark-lighter text-light"
                    placeholder="https://api.schwab.com/v1/"
                  />
                </div>
                
                <div className="flex justify-end">
                  <Button onClick={handleSaveApiSettings}>
                    Save API Settings
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications" className="space-y-4">
          <Card className="bg-dark border-dark-lighter">
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription className="text-light-darker">Choose which notifications you want to receive</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Trade Executed</Label>
                    <p className="text-sm text-light-darker">Receive notifications when trades are executed</p>
                  </div>
                  <Switch
                    checked={notificationSettings.tradeExecuted}
                    onCheckedChange={() => handleNotificationToggle('tradeExecuted')}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Trade Errors</Label>
                    <p className="text-sm text-light-darker">Receive notifications about trade execution errors</p>
                  </div>
                  <Switch
                    checked={notificationSettings.tradeError}
                    onCheckedChange={() => handleNotificationToggle('tradeError')}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Account Sync</Label>
                    <p className="text-sm text-light-darker">Receive notifications when accounts are synced</p>
                  </div>
                  <Switch
                    checked={notificationSettings.accountSync}
                    onCheckedChange={() => handleNotificationToggle('accountSync')}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Profit/Loss Alerts</Label>
                    <p className="text-sm text-light-darker">Receive alerts about significant profit/loss changes</p>
                  </div>
                  <Switch
                    checked={notificationSettings.profitLossAlerts}
                    onCheckedChange={() => handleNotificationToggle('profitLossAlerts')}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Market Updates</Label>
                    <p className="text-sm text-light-darker">Receive notifications about important market updates</p>
                  </div>
                  <Switch
                    checked={notificationSettings.marketUpdates}
                    onCheckedChange={() => handleNotificationToggle('marketUpdates')}
                  />
                </div>
                
                <div className="flex justify-end">
                  <Button onClick={handleSaveNotificationSettings}>
                    Save Notification Settings
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security" className="space-y-4">
          <Card className="bg-dark border-dark-lighter">
            <CardHeader>
              <CardTitle>Change Password</CardTitle>
              <CardDescription className="text-light-darker">Update your account password</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleChangePassword} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">Current Password</Label>
                  <Input 
                    id="currentPassword" 
                    name="currentPassword"
                    type="password"
                    value={profileSettings.currentPassword}
                    onChange={handleProfileChange}
                    className="bg-dark-darker border-dark-lighter text-light"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="newPassword">New Password</Label>
                  <Input 
                    id="newPassword" 
                    name="newPassword"
                    type="password"
                    value={profileSettings.newPassword}
                    onChange={handleProfileChange}
                    className="bg-dark-darker border-dark-lighter text-light"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm New Password</Label>
                  <Input 
                    id="confirmPassword" 
                    name="confirmPassword"
                    type="password"
                    value={profileSettings.confirmPassword}
                    onChange={handleProfileChange}
                    className="bg-dark-darker border-dark-lighter text-light"
                  />
                </div>
                
                <div className="flex justify-end">
                  <Button type="submit">
                    Change Password
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
          
          <Card className="bg-dark border-dark-lighter">
            <CardHeader>
              <CardTitle>Account Security</CardTitle>
              <CardDescription className="text-light-darker">Manage your account security settings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="pb-4 border-b border-dark-lighter">
                  <Button 
                    variant="destructive" 
                    onClick={logout}
                    className="w-full"
                  >
                    <span className="material-icons text-sm mr-2">logout</span>
                    Sign Out of All Devices
                  </Button>
                </div>
                
                <div className="pt-2">
                  <p className="text-sm text-light-darker mb-4">Last login: {user?.lastLogin ? new Date(user.lastLogin).toLocaleString() : 'Unknown'}</p>
                  
                  <div className="bg-dark-darker p-4 rounded-md border border-dark-lighter">
                    <h4 className="font-medium mb-2">Security Tips</h4>
                    <ul className="text-sm text-light-darker space-y-2">
                      <li className="flex items-start">
                        <span className="material-icons text-xs mr-2 mt-1">check_circle</span>
                        Use a strong, unique password that you don't use elsewhere
                      </li>
                      <li className="flex items-start">
                        <span className="material-icons text-xs mr-2 mt-1">check_circle</span>
                        Change your password regularly
                      </li>
                      <li className="flex items-start">
                        <span className="material-icons text-xs mr-2 mt-1">check_circle</span>
                        Keep your API keys secure and never share them
                      </li>
                      <li className="flex items-start">
                        <span className="material-icons text-xs mr-2 mt-1">check_circle</span>
                        Sign out when using shared or public computers
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}
