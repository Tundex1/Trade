import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Trade, InsertTrade } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { formatCurrency, formatPercentage, formatDuration } from '@/lib/utils';

export default function Trades() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('active');
  const [isNewTradeDialogOpen, setIsNewTradeDialogOpen] = useState(false);
  const [newTradeForm, setNewTradeForm] = useState({
    symbol: '',
    type: 'long',
    entryPrice: 0,
    quantity: 0,
    targetPrice: 0,
    stopLoss: 0,
  });
  const [selectedAccounts, setSelectedAccounts] = useState<number[]>([]);

  // Get trades
  const { data: trades, isLoading: isLoadingTrades, isError: isTradesError } = useQuery<Trade[]>({
    queryKey: ['/api/trades'],
  });

  // Get accounts for trade creation
  const { data: accounts, isLoading: isLoadingAccounts } = useQuery<any[]>({
    queryKey: ['/api/accounts'],
  });

  // Close trade mutation
  const closeTradeMutation = useMutation({
    mutationFn: async (tradeId: number) => {
      const res = await apiRequest('DELETE', `/api/trades/${tradeId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trades/active'] });
      toast({
        title: 'Trade closed',
        description: 'The trade has been closed successfully',
      });
    },
    onError: (error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to close trade',
      });
    }
  });

  // Create trade mutation
  const createTradeMutation = useMutation({
    mutationFn: async (data: { trade: InsertTrade, accountIds: number[] }) => {
      const res = await apiRequest('POST', '/api/trades', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trades/active'] });
      toast({
        title: 'Trade created',
        description: 'The trade has been created successfully',
      });
      setIsNewTradeDialogOpen(false);
      resetNewTradeForm();
    },
    onError: (error) => {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to create trade',
      });
    }
  });

  const handleCloseTrade = (tradeId: number) => {
    if (window.confirm('Are you sure you want to close this trade?')) {
      closeTradeMutation.mutate(tradeId);
    }
  };

  const handleNewTradeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (selectedAccounts.length === 0) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Please select at least one account',
      });
      return;
    }
    
    // Validate the trade first
    const isValid = await validateTradeOrder();
    if (!isValid) {
      toast({
        variant: 'destructive',
        title: 'Trade Validation Failed',
        description: validationMessage || 'The trade could not be validated',
      });
      return;
    }
    
    // Construct the trade order based on form values and selected order type
    const tradeData: any = {
      symbol: newTradeForm.symbol.toUpperCase(),
      type: newTradeForm.type as any,
      entryPrice: Number(newTradeForm.entryPrice),
      currentPrice: Number(newTradeForm.entryPrice),
      quantity: Number(newTradeForm.quantity),
      targetPrice: Number(newTradeForm.targetPrice) || null,
      stopLoss: Number(newTradeForm.stopLoss) || null,
      status: 'active',
      // Add additional fields for advanced order types
      orderType: orderType,
      timeInForce: timeInForce
    };
    
    // Include options data if applicable
    if (isOption) {
      tradeData.isOption = true;
      tradeData.optionType = optionType;
      tradeData.expirationDate = expirationDate;
      tradeData.strikePrice = strikePrice;
      
      if (selectedOptionLegs.length > 0) {
        tradeData.optionStrategy = optionStrategy;
      }
    }
    
    // Include trailing stop details if applicable
    if (orderType === 'trailing_stop') {
      tradeData.trailAmount = trailAmount;
      tradeData.trailType = trailType;
    }
    
    // Construct the full payload
    const payload: any = {
      trade: tradeData,
      accountIds: selectedAccounts
    };
    
    // Include options legs if applicable
    if (selectedOptionLegs.length > 0) {
      payload.optionLegs = selectedOptionLegs;
    }
    
    createTradeMutation.mutate(payload);
  };

  const [symbolSearchResults, setSymbolSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [orderType, setOrderType] = useState<string>('market');
  const [timeInForce, setTimeInForce] = useState<string>('day');
  const [trailAmount, setTrailAmount] = useState<number>(0);
  const [trailType, setTrailType] = useState<string>('amount');
  const [isOption, setIsOption] = useState<boolean>(false);
  const [optionStrategy, setOptionStrategy] = useState<string>('single');
  const [expirationDate, setExpirationDate] = useState<string>('');
  const [strikePrice, setStrikePrice] = useState<number>(0);
  const [optionType, setOptionType] = useState<string>('call');
  const [isValidatingOrder, setIsValidatingOrder] = useState(false);
  const [validationMessage, setValidationMessage] = useState<string | null>(null);
  const [optionChain, setOptionChain] = useState<any>(null);
  const [isLoadingOptionChain, setIsLoadingOptionChain] = useState(false);
  const [selectedOptionLegs, setSelectedOptionLegs] = useState<any[]>([]);
  
  // Reset the trade form completely
  const resetNewTradeForm = () => {
    setNewTradeForm({
      symbol: '',
      type: 'long',
      entryPrice: 0,
      quantity: 0,
      targetPrice: 0,
      stopLoss: 0,
    });
    setSelectedAccounts([]);
    setSymbolSearchResults([]);
    setOrderType('market');
    setTimeInForce('day');
    setTrailAmount(0);
    setTrailType('amount');
    setIsOption(false);
    setOptionStrategy('single');
    setExpirationDate('');
    setStrikePrice(0);
    setOptionType('call');
    setValidationMessage(null);
    setOptionChain(null);
    setSelectedOptionLegs([]);
  };

  // Add symbol search functionality
  const handleSymbolSearch = async (query: string) => {
    // Update the form state with the current input
    setNewTradeForm(prev => ({
      ...prev,
      symbol: query,
    }));
    
    // Only search if we have at least 2 characters
    if (query.length < 2) {
      setSymbolSearchResults([]);
      return;
    }
    
    setIsSearching(true);
    
    try {
      const response = await fetch(`/api/market/search?q=${encodeURIComponent(query)}`);
      if (!response.ok) {
        throw new Error('Symbol search failed');
      }
      
      const results = await response.json();
      setSymbolSearchResults(results);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to search symbols',
      });
    } finally {
      setIsSearching(false);
    }
  };
  
  // Add option chain fetching
  const fetchOptionChain = async (symbol: string) => {
    if (!symbol || symbol.length < 1) return;
    
    setIsLoadingOptionChain(true);
    
    try {
      const response = await fetch(`/api/market/options/${encodeURIComponent(symbol)}`);
      if (!response.ok) {
        throw new Error('Failed to fetch option chain');
      }
      
      const data = await response.json();
      setOptionChain(data);
      
      // If we have expirations, select the first one by default
      if (data.expirations && data.expirations.length > 0) {
        setExpirationDate(data.expirations[0]);
      }
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to fetch option chain',
      });
    } finally {
      setIsLoadingOptionChain(false);
    }
  };
  
  // Handle symbol selection from search results
  const handleSymbolSelect = async (symbol: string, type: string) => {
    setNewTradeForm(prev => ({
      ...prev,
      symbol,
    }));
    
    setSymbolSearchResults([]);
    
    // If it's an option-capable symbol, enable the options UI
    if (type === 'stock' || type === 'etf') {
      // Fetch the latest quote
      try {
        const response = await fetch(`/api/market/quotes?symbols=${encodeURIComponent(symbol)}`);
        if (!response.ok) {
          throw new Error('Failed to fetch quote');
        }
        
        const quotes = await response.json();
        if (quotes.length > 0) {
          setNewTradeForm(prev => ({
            ...prev,
            entryPrice: quotes[0].price,
          }));
        }
        
        // Also fetch option chain if it's a stock or ETF
        if (isOption) {
          fetchOptionChain(symbol);
        }
      } catch (error) {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: error instanceof Error ? error.message : 'Failed to fetch quote',
        });
      }
    }
  };
  
  // Validate the trade order before submission
  const validateTradeOrder = async () => {
    setIsValidatingOrder(true);
    setValidationMessage(null);
    
    try {
      // Construct the order payload based on current form state
      const orderPayload = {
        symbol: newTradeForm.symbol,
        quantity: Number(newTradeForm.quantity),
        orderType,
        action: newTradeForm.type === 'long' ? 'buy' : 'sell',
        price: orderType === 'limit' || orderType === 'stop_limit' ? Number(newTradeForm.entryPrice) : undefined,
        stopPrice: orderType === 'stop' || orderType === 'stop_limit' ? Number(newTradeForm.stopLoss) : undefined,
        timeInForce,
        trailAmount: orderType === 'trailing_stop' ? trailAmount : undefined,
        trailType: orderType === 'trailing_stop' ? trailType : undefined,
        accountId: 'validate-only', // Placeholder for validation
        isOption,
        expirationDate: isOption ? expirationDate : undefined,
        strikePrice: isOption ? strikePrice : undefined,
        optionType: isOption ? optionType : undefined,
        optionStrategy: isOption && selectedOptionLegs.length > 0 ? optionStrategy : undefined,
        legs: selectedOptionLegs.length > 0 ? selectedOptionLegs : undefined,
      };
      
      // Send validation request
      const response = await fetch('/api/trades/validate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderPayload),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Validation failed');
      }
      
      const result = await response.json();
      
      if (result.isValid) {
        setValidationMessage('Trade validation successful');
        return true;
      } else {
        setValidationMessage(`Validation failed: ${result.message}`);
        return false;
      }
    } catch (error) {
      setValidationMessage(error instanceof Error ? error.message : 'Validation failed');
      return false;
    } finally {
      setIsValidatingOrder(false);
    }
  };
  
  // Handle input change for the form fields
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    // Special handling for symbol field to trigger search
    if (name === 'symbol') {
      handleSymbolSearch(value);
    } else {
      setNewTradeForm(prev => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const toggleAccountSelection = (accountId: number) => {
    setSelectedAccounts(prev => 
      prev.includes(accountId)
        ? prev.filter(id => id !== accountId)
        : [...prev, accountId]
    );
  };

  // Filter trades based on active tab
  const filteredTrades = trades?.filter(trade => {
    if (activeTab === 'active') return trade.status === 'active';
    if (activeTab === 'closed') return trade.status === 'closed';
    return true; // 'all' tab
  });

  // Status styles
  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'active':
        return 'status-active';
      case 'warning':
        return 'status-warning';
      case 'error':
        return 'status-error';
      case 'closed':
        return 'status-inactive';
      default:
        return 'status-inactive';
    }
  };

  return (
    <>
      <Helmet>
        <title>Trades - TradeSwim Admin Copy Trading Platform</title>
        <meta name="description" content="Manage and monitor all your trading positions across connected accounts." />
      </Helmet>
      
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Trades Management</h2>
        
        <Dialog open={isNewTradeDialogOpen} onOpenChange={setIsNewTradeDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center">
              <Plus className="h-4 w-4 mr-1" />
              New Trade
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px] bg-dark border-dark-lighter text-light">
            <DialogHeader>
              <DialogTitle>Create New Trade</DialogTitle>
              <DialogDescription className="text-light-darker">
                Configure trade parameters and select accounts for copy trading
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleNewTradeSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-1 relative">
                    <Label htmlFor="symbol">Symbol</Label>
                    <Input
                      id="symbol"
                      name="symbol"
                      value={newTradeForm.symbol}
                      onChange={handleInputChange}
                      className="bg-dark-darker border-dark-lighter text-light"
                      placeholder="Search symbols (min 2 chars)"
                      required
                    />
                    
                    {/* Symbol search results dropdown */}
                    {isSearching && (
                      <div className="absolute inset-x-0 top-full mt-1 bg-dark-darker border border-dark-lighter rounded-md shadow-lg z-50 p-1">
                        <div className="flex justify-center p-2">
                          <div className="animate-spin h-4 w-4 border-2 border-primary rounded-full border-t-transparent"></div>
                          <span className="ml-2">Searching...</span>
                        </div>
                      </div>
                    )}
                    
                    {!isSearching && symbolSearchResults.length > 0 && (
                      <div className="absolute inset-x-0 top-full mt-1 bg-dark-darker border border-dark-lighter rounded-md shadow-lg z-50 max-h-40 overflow-y-auto">
                        <ul className="py-1">
                          {symbolSearchResults.map((result, index) => (
                            <li 
                              key={index} 
                              className="px-3 py-2 hover:bg-dark-lighter cursor-pointer flex justify-between items-center"
                              onClick={() => handleSymbolSelect(result.symbol, result.type)}
                            >
                              <div className="flex items-center">
                                <span className="font-bold">{result.symbol}</span>
                                <span className="ml-2 text-xs text-light-darker">{result.type}</span>
                              </div>
                              <span className="text-sm truncate max-w-[150px]">{result.name}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                  
                  <div className="col-span-1">
                    <Label htmlFor="type">Direction</Label>
                    <Select 
                      value={newTradeForm.type} 
                      onValueChange={(value) => setNewTradeForm(prev => ({ ...prev, type: value }))}
                    >
                      <SelectTrigger className="bg-dark-darker border-dark-lighter text-light">
                        <SelectValue placeholder="Select direction" />
                      </SelectTrigger>
                      <SelectContent className="bg-dark-darker border-dark-lighter text-light">
                        <SelectItem value="long">Long (Buy)</SelectItem>
                        <SelectItem value="short">Short (Sell)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                {/* Order Type Selection */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-1">
                    <Label htmlFor="orderType">Order Type</Label>
                    <Select 
                      value={orderType} 
                      onValueChange={setOrderType}
                    >
                      <SelectTrigger className="bg-dark-darker border-dark-lighter text-light">
                        <SelectValue placeholder="Select order type" />
                      </SelectTrigger>
                      <SelectContent className="bg-dark-darker border-dark-lighter text-light">
                        <SelectItem value="market">Market</SelectItem>
                        <SelectItem value="limit">Limit</SelectItem>
                        <SelectItem value="stop">Stop</SelectItem>
                        <SelectItem value="stop_limit">Stop Limit</SelectItem>
                        <SelectItem value="trailing_stop">Trailing Stop</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="col-span-1">
                    <Label htmlFor="timeInForce">Time In Force</Label>
                    <Select 
                      value={timeInForce} 
                      onValueChange={setTimeInForce}
                    >
                      <SelectTrigger className="bg-dark-darker border-dark-lighter text-light">
                        <SelectValue placeholder="Select time in force" />
                      </SelectTrigger>
                      <SelectContent className="bg-dark-darker border-dark-lighter text-light">
                        <SelectItem value="day">Day Only</SelectItem>
                        <SelectItem value="gtc">Good Till Canceled</SelectItem>
                        <SelectItem value="ext">Extended Hours</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                {/* Trailing Stop Parameters (only visible when order type is trailing_stop) */}
                {orderType === 'trailing_stop' && (
                  <div className="grid grid-cols-2 gap-4 mt-2 p-3 border border-dark-lighter rounded-md bg-dark-darker">
                    <div className="col-span-1">
                      <Label htmlFor="trailAmount">Trail Amount</Label>
                      <Input
                        id="trailAmount"
                        type="number"
                        step="0.01"
                        min="0.01"
                        value={trailAmount}
                        onChange={(e) => setTrailAmount(Number(e.target.value))}
                        className="bg-dark border-dark-lighter text-light"
                        required={orderType === 'trailing_stop'}
                      />
                    </div>
                    
                    <div className="col-span-1">
                      <Label htmlFor="trailType">Trail Type</Label>
                      <Select 
                        value={trailType} 
                        onValueChange={setTrailType}
                      >
                        <SelectTrigger className="bg-dark border-dark-lighter text-light">
                          <SelectValue placeholder="Select trail type" />
                        </SelectTrigger>
                        <SelectContent className="bg-dark border-dark-lighter text-light">
                          <SelectItem value="amount">Amount ($)</SelectItem>
                          <SelectItem value="percentage">Percentage (%)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="col-span-2 mt-1">
                      <p className="text-xs text-light-darker">
                        A trailing stop {trailType === 'amount' ? `of $${trailAmount}` : `of ${trailAmount}%`} will be placed. The stop price will automatically adjust as the market price moves in your favor.
                      </p>
                    </div>
                  </div>
                )}
                
                {/* Options Trading Toggle */}
                <div className="flex items-center space-x-2 my-2">
                  <Switch 
                    id="options-toggle" 
                    checked={isOption}
                    onCheckedChange={(checked) => {
                      setIsOption(checked);
                      if (checked && newTradeForm.symbol) {
                        fetchOptionChain(newTradeForm.symbol);
                      }
                    }}
                  />
                  <Label htmlFor="options-toggle">Options Trading</Label>
                </div>
                
                {/* Options Trading UI - only appears when options is toggled on */}
                {isOption && (
                  <div className="border border-dark-lighter rounded-md p-4 mt-2 bg-dark-darker">
                    <h4 className="text-sm font-medium mb-3">Options Configuration</h4>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-1">
                        <Label htmlFor="optionType">Option Type</Label>
                        <Select 
                          value={optionType} 
                          onValueChange={setOptionType}
                        >
                          <SelectTrigger className="bg-dark border-dark-lighter text-light">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent className="bg-dark border-dark-lighter text-light">
                            <SelectItem value="call">Call</SelectItem>
                            <SelectItem value="put">Put</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="col-span-1">
                        <Label htmlFor="optionStrategy">Strategy</Label>
                        <Select 
                          value={optionStrategy} 
                          onValueChange={setOptionStrategy}
                        >
                          <SelectTrigger className="bg-dark border-dark-lighter text-light">
                            <SelectValue placeholder="Select strategy" />
                          </SelectTrigger>
                          <SelectContent className="bg-dark border-dark-lighter text-light">
                            <SelectItem value="single">Single</SelectItem>
                            <SelectItem value="vertical">Vertical Spread</SelectItem>
                            <SelectItem value="calendar">Calendar Spread</SelectItem>
                            <SelectItem value="straddle">Straddle</SelectItem>
                            <SelectItem value="strangle">Strangle</SelectItem>
                            <SelectItem value="iron_condor">Iron Condor</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mt-3">
                      <div className="col-span-1">
                        <Label htmlFor="expirationDate">Expiration Date</Label>
                        {isLoadingOptionChain ? (
                          <div className="flex items-center mt-2">
                            <div className="animate-spin h-4 w-4 border-2 border-primary rounded-full border-t-transparent"></div>
                            <span className="ml-2">Loading...</span>
                          </div>
                        ) : optionChain && optionChain.expirations && optionChain.expirations.length > 0 ? (
                          <Select 
                            value={expirationDate} 
                            onValueChange={setExpirationDate}
                          >
                            <SelectTrigger className="bg-dark border-dark-lighter text-light">
                              <SelectValue placeholder="Select date" />
                            </SelectTrigger>
                            <SelectContent className="bg-dark border-dark-lighter text-light max-h-48">
                              {optionChain.expirations.map((date: string) => (
                                <SelectItem key={date} value={date}>
                                  {new Date(date).toLocaleDateString()}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : (
                          <Input
                            id="expirationDate"
                            value={expirationDate}
                            onChange={(e) => setExpirationDate(e.target.value)}
                            className="bg-dark border-dark-lighter text-light"
                            placeholder="YYYY-MM-DD"
                          />
                        )}
                      </div>
                      
                      <div className="col-span-1">
                        <Label htmlFor="strikePrice">Strike Price</Label>
                        <Input
                          id="strikePrice"
                          type="number"
                          step="0.01"
                          value={strikePrice}
                          onChange={(e) => setStrikePrice(Number(e.target.value))}
                          className="bg-dark border-dark-lighter text-light"
                          required={isOption}
                        />
                      </div>
                    </div>
                    
                    {/* Show message when option chain is loaded */}
                    {optionChain && optionChain.options && optionChain.options.length > 0 && (
                      <div className="mt-2 text-xs text-success">
                        Option chain loaded with {optionChain.options.length} contracts
                      </div>
                    )}
                    
                    {/* Multi-leg options UI (only shown for strategies other than single) */}
                    {isOption && optionStrategy !== 'single' && (
                      <div className="mt-3">
                        <div className="flex justify-between items-center mb-2">
                          <Label>Option Legs</Label>
                          <Button 
                            type="button" 
                            variant="outline" 
                            size="sm"
                            onClick={() => {
                              setSelectedOptionLegs([
                                ...selectedOptionLegs, 
                                {
                                  symbol: `${newTradeForm.symbol}${expirationDate.replace(/-/g, '')}${optionType.charAt(0).toUpperCase()}${strikePrice * 100}`,
                                  action: newTradeForm.type === 'long' ? 'buy' : 'sell',
                                  quantity: newTradeForm.quantity,
                                  optionType,
                                  strikePrice,
                                  expirationDate
                                }
                              ]);
                            }}
                            className="bg-dark-lighter text-light border-dark-lighter hover:bg-dark-darker"
                          >
                            Add Leg
                          </Button>
                        </div>
                        
                        {selectedOptionLegs.length > 0 ? (
                          <div className="bg-dark border border-dark-lighter rounded p-2 mt-1 max-h-32 overflow-y-auto">
                            {selectedOptionLegs.map((leg, index) => (
                              <div key={index} className="flex justify-between items-center py-1 border-b border-dark-lighter last:border-b-0">
                                <div className="text-sm">
                                  <span className={leg.action === 'buy' ? 'text-success' : 'text-danger'}>
                                    {leg.action.toUpperCase()}
                                  </span>
                                  {" "}
                                  <span className="font-medium">{leg.quantity}x</span>
                                  {" "}
                                  <span>{leg.symbol}</span>
                                </div>
                                <Button 
                                  type="button" 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => {
                                    setSelectedOptionLegs(legs => legs.filter((_, i) => i !== index));
                                  }}
                                  className="h-6 w-6 p-0 text-danger"
                                >
                                  &times;
                                </Button>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center text-light-darker text-sm p-2">
                            No option legs added yet
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-1">
                    <Label htmlFor="entryPrice">Entry Price</Label>
                    <Input
                      id="entryPrice"
                      name="entryPrice"
                      type="number"
                      step="0.01"
                      value={newTradeForm.entryPrice}
                      onChange={handleInputChange}
                      className="bg-dark-darker border-dark-lighter text-light"
                      required
                    />
                  </div>
                  <div className="col-span-1">
                    <Label htmlFor="quantity">Quantity</Label>
                    <Input
                      id="quantity"
                      name="quantity"
                      type="number"
                      step="0.01"
                      value={newTradeForm.quantity}
                      onChange={handleInputChange}
                      className="bg-dark-darker border-dark-lighter text-light"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-1">
                    <Label htmlFor="targetPrice">Target Price (Optional)</Label>
                    <Input
                      id="targetPrice"
                      name="targetPrice"
                      type="number"
                      step="0.01"
                      value={newTradeForm.targetPrice}
                      onChange={handleInputChange}
                      className="bg-dark-darker border-dark-lighter text-light"
                    />
                  </div>
                  <div className="col-span-1">
                    <Label htmlFor="stopLoss">Stop Loss (Optional)</Label>
                    <Input
                      id="stopLoss"
                      name="stopLoss"
                      type="number"
                      step="0.01"
                      value={newTradeForm.stopLoss}
                      onChange={handleInputChange}
                      className="bg-dark-darker border-dark-lighter text-light"
                    />
                  </div>
                </div>
                
                <div className="mt-2">
                  <Label className="mb-2 block">Select Accounts for Trade</Label>
                  <div className="bg-dark-darker border border-dark-lighter rounded-md p-4 max-h-40 overflow-y-auto">
                    {isLoadingAccounts ? (
                      <div className="flex justify-center">
                        <div className="animate-spin h-5 w-5 border-2 border-primary rounded-full border-t-transparent"></div>
                      </div>
                    ) : accounts && accounts.length > 0 ? (
                      accounts.filter(account => account.status === 'connected').map(account => (
                        <div key={account.id} className="flex items-center justify-between py-1">
                          <div className="flex items-center space-x-2">
                            <Switch
                              checked={selectedAccounts.includes(account.id)}
                              onCheckedChange={() => toggleAccountSelection(account.id)}
                            />
                            <span>{account.accountName}</span>
                          </div>
                          <span className="text-xs text-light-darker">Balance: {formatCurrency(account.balance)}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-light-darker text-center">No active accounts available</p>
                    )}
                  </div>
                </div>
                
                {/* Trade Validation Section */}
                <div className="mt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={validateTradeOrder}
                    disabled={isValidatingOrder || !newTradeForm.symbol || !newTradeForm.quantity}
                    className="w-full bg-dark-lighter hover:bg-dark border-dark-lighter text-light"
                  >
                    {isValidatingOrder ? (
                      <>
                        <div className="animate-spin h-4 w-4 border-2 border-primary rounded-full border-t-transparent mr-2"></div>
                        Validating Order...
                      </>
                    ) : (
                      'Validate Order Before Submission'
                    )}
                  </Button>
                  
                  {validationMessage && (
                    <div className={`mt-2 p-2 rounded-md text-sm ${validationMessage.includes('successful') ? 'bg-success/20 text-success' : 'bg-danger/20 text-danger'}`}>
                      {validationMessage}
                    </div>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsNewTradeDialogOpen(false)}
                  className="bg-dark-lighter text-light border-dark-lighter hover:bg-dark-darker"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createTradeMutation.isPending || selectedAccounts.length === 0}
                >
                  {createTradeMutation.isPending ? 'Creating...' : 'Create Trade'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      
      <Card className="bg-dark border-dark-lighter">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Trade Positions</CardTitle>
              <CardDescription className="text-light-darker">Manage all your trading positions</CardDescription>
            </div>
            <Tabs defaultValue="active" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="bg-dark-lighter">
                <TabsTrigger value="active" className="data-[state=active]:bg-primary data-[state=active]:text-white">Active</TabsTrigger>
                <TabsTrigger value="closed" className="data-[state=active]:bg-primary data-[state=active]:text-white">Closed</TabsTrigger>
                <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-white">All</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent>
          {isLoadingTrades ? (
            <div className="flex justify-center py-8">
              <div className="spinner"></div>
            </div>
          ) : isTradesError ? (
            <div className="text-danger flex items-center justify-center p-6">
              <span className="material-icons mr-2">error</span>
              Failed to load trades. Please try again later.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-dark-lighter">
                <thead className="bg-dark-lighter">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Symbol</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Type</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Entry Price</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Current Price</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Quantity</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">P&L</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Duration</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-light-darker uppercase tracking-wider">Status</th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-light-darker uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-dark divide-y divide-dark-lighter">
                  {filteredTrades && filteredTrades.length > 0 ? (
                    filteredTrades.map((trade) => (
                      <tr key={trade.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="font-mono font-medium">{trade.symbol}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            trade.type === 'long' 
                              ? 'bg-secondary bg-opacity-10 text-secondary'
                              : 'bg-danger bg-opacity-10 text-danger'
                          }`}>
                            {trade.type === 'long' ? 'Long' : 'Short'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap font-mono">{formatCurrency(trade.entryPrice)}</td>
                        <td className={`px-6 py-4 whitespace-nowrap font-mono ${
                          trade.currentPrice && trade.entryPrice 
                            ? (trade.type === 'long' 
                                ? (trade.currentPrice > trade.entryPrice ? 'price-up' : 'price-down')
                                : (trade.currentPrice < trade.entryPrice ? 'price-up' : 'price-down')
                              )
                            : ''
                        }`}>
                          {formatCurrency(trade.currentPrice)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap font-mono">{trade.quantity}</td>
                        <td className={`px-6 py-4 whitespace-nowrap font-mono ${
                          trade.profitLoss && trade.profitLoss > 0 ? 'text-secondary' : 'text-danger'
                        }`}>
                          {formatCurrency(trade.profitLoss)} ({formatPercentage(trade.profitLossPercentage)})
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          {trade.status === 'closed' && trade.closedAt 
                            ? `Closed: ${new Date(trade.closedAt).toLocaleString()}`
                            : formatDuration(new Date(trade.createdAt))}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <span className={`status-dot ${getStatusStyle(trade.status)}`}></span>
                            <span>{trade.status.charAt(0).toUpperCase() + trade.status.slice(1)}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex justify-end space-x-2">
                            {trade.status !== 'closed' && (
                              <>
                                <Button variant="ghost" size="sm" className="p-1 rounded hover:bg-dark-lighter text-light">
                                  <span className="material-icons text-sm">edit</span>
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="p-1 rounded hover:bg-dark-lighter text-danger"
                                  onClick={() => handleCloseTrade(trade.id)}
                                  disabled={closeTradeMutation.isPending}
                                >
                                  <span className="material-icons text-sm">close</span>
                                </Button>
                              </>
                            )}
                            {trade.status === 'closed' && (
                              <Button variant="ghost" size="sm" className="p-1 rounded hover:bg-dark-lighter text-light">
                                <span className="material-icons text-sm">visibility</span>
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={9} className="px-6 py-12 text-center text-light-darker">
                        {activeTab === 'active' 
                          ? 'No active trades found. Click "New Trade" to create one.'
                          : activeTab === 'closed' 
                            ? 'No closed trades found.'
                            : 'No trades found.'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
