import { Helmet } from 'react-helmet';
import StatsCards from '@/components/dashboard/StatsCards';
import TradingChart from '@/components/dashboard/TradingChart';
import ActiveTradesTable from '@/components/dashboard/ActiveTradesTable';
import ConnectedAccountsTable from '@/components/dashboard/ConnectedAccountsTable';

export default function Dashboard() {
  return (
    <>
      <Helmet>
        <title>Dashboard - TradeSwim Admin Copy Trading Platform</title>
        <meta name="description" content="Monitor your trading performance, active trades, and connected accounts in real-time." />
      </Helmet>
      
      <div className="mb-6">
        <h2 className="text-xl font-bold mb-4">Dashboard Overview</h2>
        
        {/* Stats Cards */}
        <StatsCards />
        
        {/* Chart Section */}
        <TradingChart />
        
        {/* Active Trades Section */}
        <ActiveTradesTable />
        
        {/* Connected Accounts Section */}
        <ConnectedAccountsTable />
      </div>
    </>
  );
}
