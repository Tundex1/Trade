import { Pool, neonConfig } from "@neondatabase/serverless"
import { drizzle } from "drizzle-orm/neon-serverless"
import { eq } from "drizzle-orm"
import { hash } from "bcrypt"
import ws from "ws"
import * as schema from "../shared/schema"
import dotenv from "dotenv"

// Load environment variables
dotenv.config()

// Configure Neon for WebSockets
neonConfig.webSocketConstructor = ws

// Validate DATABASE_URL
if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL must be set. Please check your environment variables.")
  process.exit(1)
}

// Create database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  connectionTimeoutMillis: 5000,
})

const db = drizzle(pool, { schema })

async function createUsersTableIfNotExists() {
  try {
    // Check if the users table exists
    const tableExists = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'users'
      );
    `)

    if (!tableExists.rows[0].exists) {
      console.log("Users table does not exist. Creating it now...")

      // Create the users table using the schema definition
      await pool.query(`
        CREATE TABLE users (
          id SERIAL PRIMARY KEY,
          username TEXT NOT NULL UNIQUE,
          password TEXT NOT NULL,
          email TEXT NOT NULL,
          is_admin BOOLEAN NOT NULL DEFAULT false,
          last_login TIMESTAMP
        );
      `)

      console.log("Users table created successfully.")
    } else {
      console.log("Users table already exists.")
    }
  } catch (error) {
    console.error("Error checking/creating users table:", error)
    throw error
  }
}

async function seedAdminUser() {
  try {
    console.log("Connecting to database...")

    // First ensure the users table exists
    await createUsersTableIfNotExists()

    // Check if user already exists
    const existingUser = await db.select().from(schema.users).where(eq(schema.users.username, "tkwfriend")).limit(1)

    if (existingUser.length > 0) {
      console.log("Admin user 'tkwfriend' already exists. Skipping insertion.")
      return
    }

    // Hash the password
    const hashedPassword = await hash("Simon7600", 10)

    // Insert new admin user
    await pool.query(
      `
      INSERT INTO users (username, password, email, is_admin)
      VALUES ($1, $2, $3, $4)
    `,
      ["tkwfriend", hashedPassword, "admin@tradecopilot.com", true],
    )

    console.log("Admin user created successfully")
  } catch (error) {
    console.error("Error seeding admin user:", error)
  } finally {
    // Close the database connection
    await pool.end()
    console.log("Database connection closed.")
  }
}

// Run the seed function
seedAdminUser()
  .then(() => {
    console.log("Seed process completed.")
  })
  .catch((error) => {
    console.error("Seed process failed:", error)
    process.exit(1)
  })
