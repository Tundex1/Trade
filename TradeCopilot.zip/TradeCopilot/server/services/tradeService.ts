import { storage } from '../storage';
import { schwabService, TradeOrder, TradeResponse } from './schwabService';
import { InsertTrade, Trade, InsertTradeAccount, TradeAccount, tradeTypeEnum } from '@shared/schema';
import { log } from '../vite';

export class TradeService {
  // Create a new trade and execute it
  async createTrade(tradeData: InsertTrade, accountIds: number[]): Promise<Trade> {
    try {
      // 1. Create the trade record
      const trade = await storage.createTrade(tradeData);
      
      // 2. Loop through the accounts and execute the trade on each
      await this.executeCopyTrade(trade, accountIds);
      
      return trade;
    } catch (error: any) {
      log(`Error creating trade: ${error.message}`, "trade-service-error");
      throw new Error(`Failed to create trade: ${error.message}`);
    }
  }
  
  // Execute a copy trade on multiple accounts with scaled execution logic
  async executeCopyTrade(trade: Trade, accountIds: number[]): Promise<TradeAccount[]> {
    const results: TradeAccount[] = [];
    const failedTrades: { accountId: number, error: string }[] = [];
    
    for (const accountId of accountIds) {
      try {
        // Get the account
        const account = await storage.getAccount(accountId);
        if (!account) {
          log(`Account ${accountId} not found`, "trade-service-error");
          failedTrades.push({ accountId, error: 'Account not found' });
          continue;
        }
        
        // Skip accounts that are paused or disconnected
        if (account.status !== 'connected') {
          log(`Account ${account.accountName} (ID: ${account.id}) is ${account.status}, skipping trade`, "trade-service-warning");
          failedTrades.push({ accountId, error: `Account is ${account.status}` });
          continue;
        }
        
        // Calculate quantity based on the copy mode
        let quantity = trade.quantity; // Default is exact copy
        
        if (account.copyMode === 'fixed') {
          // Fixed quantity - use the copyAllocation field directly as the quantity
          quantity = account.copyAllocation || trade.quantity;
        } else if (account.copyMode === 'percentage') {
          // Percentage allocation - scale based on account balance relative to trade size
          const tradeValue = trade.entryPrice * trade.quantity;
          const allocationPercentage = account.copyAllocation || 100; // Default to 100% if not set
          const accountAllocation = account.balance * (allocationPercentage / 100);
          
          // Calculate the proportional quantity that respects the percentage allocation
          // but never exceeds the maximum trade size set on the account
          const maxTradeSize = account.maxTradeSize || account.balance * 0.1; // Default to 10% of balance
          const maxPossibleValue = Math.min(accountAllocation, maxTradeSize);
          const proportionalQuantity = (maxPossibleValue / tradeValue) * trade.quantity;
          
          // Round down to avoid fractional shares (unless it's a very small allocation)
          quantity = Math.max(1, Math.floor(proportionalQuantity));
        }
        
        // Validate the trade against account risk controls
        const validationResult = await this.validateTradeAgainstRiskControls(trade, account, quantity);
        if (!validationResult.isValid) {
          log(`Trade validation failed for account ${account.accountName} (ID: ${account.id}): ${validationResult.reason}`, "trade-service-warning");
          failedTrades.push({ accountId, error: validationResult.reason || 'Failed validation' });
          
          // Create the trade-account relationship record with error status
          const tradeAccount: InsertTradeAccount = {
            tradeId: trade.id,
            accountId: account.id,
            status: 'error',
            executedAt: null,
            profitLoss: 0,
            profitLossPercentage: 0,
          };
          
          const newTradeAccount = await storage.createTradeAccount(tradeAccount);
          results.push(newTradeAccount);
          continue;
        }
        
        // Prepare the trade order for Schwab API
        const order: TradeOrder = {
          symbol: trade.symbol,
          quantity: quantity,
          orderType: trade.orderType ? trade.orderType : 'market',
          action: trade.type === 'long' ? 'buy' : 'sell',
          accountId: account.accountId,
          timeInForce: trade.timeInForce ? trade.timeInForce : 'day',
        };
        
        // Add additional fields based on order type
        if (trade.orderType === 'limit' || trade.orderType === 'stop_limit') {
          order.price = trade.entryPrice;
        }
        
        if (trade.orderType === 'stop' || trade.orderType === 'stop_limit') {
          order.stopPrice = trade.stopLoss || trade.entryPrice;
        }
        
        if (trade.orderType === 'trailing_stop') {
          order.trailAmount = trade.trailAmount || undefined;
          order.trailType = trade.trailType || undefined;
        }
        
        // Add options fields if applicable
        if (trade.isOption) {
          order.isOption = true;
          order.optionType = trade.optionType || undefined;
          order.expirationDate = trade.expirationDate || undefined;
          order.strikePrice = trade.strikePrice || undefined;
          
          if (trade.optionStrategy && trade.optionStrategy !== 'single') {
            order.optionStrategy = trade.optionStrategy;
            
            // Find option legs for this trade
            const optionLegs = await storage.getOptionLegsForTrade(trade.id);
            if (optionLegs.length > 0) {
              order.legs = optionLegs.map((leg: any) => ({
                symbol: leg.symbol,
                action: leg.action,
                quantity: leg.quantity,
                optionType: leg.optionType,
                strikePrice: leg.strikePrice,
                expirationDate: leg.expirationDate
              }));
            }
          }
        }
        
        // Execute the trade on Schwab
        const tradeResponse = await schwabService.executeTrade(order);
        
        // Create the trade-account relationship record
        const tradeAccount: InsertTradeAccount = {
          tradeId: trade.id,
          accountId: account.id,
          status: 'active',
          executedAt: new Date(),
          profitLoss: 0,
          profitLossPercentage: 0,
          quantity: quantity, // Store the actual quantity traded
          orderType: trade.orderType, // Store the order type used
          price: tradeResponse.filledPrice || trade.entryPrice, // Store the executed price
          orderId: tradeResponse.orderId, // Store the broker order ID
        };
        
        const newTradeAccount = await storage.createTradeAccount(tradeAccount);
        results.push(newTradeAccount);
        
        // Update the account's activeTrades count
        await storage.updateAccount(accountId, { 
          activeTrades: account.activeTrades + 1 
        });
        
        log(`Trade executed for account ${account.accountName} (ID: ${account.id}): ${quantity} shares of ${trade.symbol} at $${tradeResponse.filledPrice || trade.entryPrice}`, "trade-service");
      } catch (error: any) {
        log(`Failed to execute trade for account ${accountId}: ${error.message}`, "trade-service-error");
        failedTrades.push({ accountId, error: error.message });
        
        // Create the trade-account relationship record with error status
        try {
          const errorTradeAccount: InsertTradeAccount = {
            tradeId: trade.id,
            accountId,
            status: 'error',
            executedAt: null,
            profitLoss: 0,
            profitLossPercentage: 0,
          };
          
          const newTradeAccount = await storage.createTradeAccount(errorTradeAccount);
          results.push(newTradeAccount);
        } catch (createError) {
          log(`Failed to log error trade record: ${createError}`, "trade-service-error");
        }
      }
    }
    
    // Log summary of execution
    const successCount = results.filter(r => r.status === 'active').length;
    const errorCount = failedTrades.length;
    
    log(`Copy trade summary for ${trade.symbol}: ${successCount} successful, ${errorCount} failed`, "trade-service");
    
    // Store failed trades for potential retry
    if (failedTrades.length > 0) {
      this.storeFailedTradesForRetry(trade.id, failedTrades);
    }
    
    return results;
  }
  
  // Validate trade against account risk controls
  private async validateTradeAgainstRiskControls(
    trade: Trade, 
    account: any, 
    quantity: number
  ): Promise<{isValid: boolean, reason?: string}> {
    // Check if the symbol is in the blocklist
    if (account.blockedSymbols && account.blockedSymbols.includes(trade.symbol)) {
      return { isValid: false, reason: `Symbol ${trade.symbol} is blocked for this account` };
    }
    
    // Check if emergency kill switch is enabled
    if (account.emergencyKillSwitch) {
      return { isValid: false, reason: 'Emergency kill switch is enabled' };
    }
    
    // Check if we're within trading hours
    const now = new Date();
    const currentTime = now.getHours() * 100 + now.getMinutes();
    
    const startTimeParts = (account.tradingStartTime || '09:30').split(':');
    const endTimeParts = (account.tradingEndTime || '16:00').split(':');
    
    const startTime = parseInt(startTimeParts[0]) * 100 + parseInt(startTimeParts[1]);
    const endTime = parseInt(endTimeParts[0]) * 100 + parseInt(endTimeParts[1]);
    
    if (currentTime < startTime || currentTime > endTime) {
      return { isValid: false, reason: `Outside of trading hours (${account.tradingStartTime}-${account.tradingEndTime})` };
    }
    
    // Check max trade size
    const tradeValue = trade.entryPrice * quantity;
    if (account.maxTradeSize && tradeValue > account.maxTradeSize) {
      return { isValid: false, reason: `Trade value $${tradeValue.toFixed(2)} exceeds max trade size $${account.maxTradeSize.toFixed(2)}` };
    }
    
    // Check daily drawdown limit
    if (account.maxDailyDrawdown && account.dailyProfitLoss < 0) {
      const currentDrawdown = Math.abs(account.dailyProfitLoss);
      if (currentDrawdown >= account.maxDailyDrawdown) {
        return { isValid: false, reason: `Daily drawdown limit $${account.maxDailyDrawdown.toFixed(2)} reached: current loss $${currentDrawdown.toFixed(2)}` };
      }
    }
    
    // Additional validation against PDT rules for accounts under $25,000
    if (account.pdtStatus && account.balance < 25000) {
      // Get today's trade count for this account
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      
      const todayTrades = await storage.getAccountTradesSince(account.id, todayStart);
      if (todayTrades.length >= 3) {
        return { isValid: false, reason: 'PDT rule: Already executed 3 or more trades today' };
      }
    }
    
    // All checks passed
    return { isValid: true };
  }
  
  // Store failed trades for potential retry
  private storeFailedTradesForRetry(tradeId: number, failedTrades: { accountId: number, error: string }[]) {
    // This could save to a database table, file, or in-memory cache
    // For simplicity, we'll log it here, but in a production system
    // you'd want to persist this somewhere
    
    log(`Storing ${failedTrades.length} failed trades for potential retry: trade #${tradeId}`, "trade-service");
    
    // We could implement a retry queue here if needed
    // For now, we'll just log the failed trades
    failedTrades.forEach(failed => {
      log(`Failed trade for account ${failed.accountId}: ${failed.error}`, "trade-service-retry");
    });
  }
  
  // Retry failed trades
  async retryFailedTrade(tradeAccountId: number): Promise<TradeAccount | undefined> {
    try {
      // Get the trade account record
      const tradeAccount = await storage.getTradeAccount(tradeAccountId);
      if (!tradeAccount) {
        log(`Trade account ${tradeAccountId} not found`, "trade-service-error");
        return undefined;
      }
      
      // Only retry if status is error
      if (tradeAccount.status !== 'error') {
        log(`Cannot retry trade account ${tradeAccountId} with status ${tradeAccount.status}`, "trade-service-error");
        return undefined;
      }
      
      // Get the trade and account
      const trade = await storage.getTrade(tradeAccount.tradeId);
      const account = await storage.getAccount(tradeAccount.accountId);
      
      if (!trade || !account) {
        log(`Unable to find trade or account for trade account ${tradeAccountId}`, "trade-service-error");
        return undefined;
      }
      
      // Use the copy trade engine but with just this one account
      const results = await this.executeCopyTrade(trade, [account.id]);
      if (results.length === 0) {
        log(`Retry failed for trade account ${tradeAccountId}`, "trade-service-error");
        return undefined;
      }
      
      // Return the updated trade account
      return results[0];
    } catch (error: any) {
      log(`Error retrying failed trade: ${error.message}`, "trade-service-error");
      throw new Error(`Failed to retry trade: ${error.message}`);
    }
  }
  
  // Update trade with latest market data
  async updateTrade(tradeId: number): Promise<Trade | undefined> {
    try {
      const trade = await storage.getTrade(tradeId);
      if (!trade) {
        log(`Trade ${tradeId} not found`, "trade-service-error");
        return undefined;
      }
      
      // Get current market price
      const quote = await schwabService.getQuote(trade.symbol);
      
      // Calculate profit/loss
      const currentPrice = quote.price;
      let profitLoss: number;
      let profitLossPercentage: number;
      
      if (trade.type === 'long') {
        profitLoss = (currentPrice - trade.entryPrice) * trade.quantity;
        profitLossPercentage = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
      } else { // short
        profitLoss = (trade.entryPrice - currentPrice) * trade.quantity;
        profitLossPercentage = ((trade.entryPrice - currentPrice) / trade.entryPrice) * 100;
      }
      
      // Update the trade record
      const updatedTrade = await storage.updateTrade(tradeId, {
        currentPrice,
        profitLoss,
        profitLossPercentage
      });
      
      return updatedTrade;
    } catch (error: any) {
      log(`Error updating trade ${tradeId}: ${error.message}`, "trade-service-error");
      throw new Error(`Failed to update trade: ${error.message}`);
    }
  }
  
  // Close a trade
  async closeTrade(tradeId: number): Promise<Trade | undefined> {
    try {
      const trade = await storage.getTrade(tradeId);
      if (!trade) {
        log(`Trade ${tradeId} not found`, "trade-service-error");
        return undefined;
      }
      
      // Get all trade accounts associated with this trade
      const tradeAccountsResult = await db.query.tradeAccounts.findMany({
        where: eq(tradeAccounts.tradeId, tradeId)
      });
      
      // For each account, execute opposite order to close the position
      for (const tradeAccount of tradeAccountsResult) {
        const account = await storage.getAccount(tradeAccount.accountId);
        if (!account) continue;
        
        // Prepare the closing order
        const closingOrder: TradeOrder = {
          symbol: trade.symbol,
          quantity: trade.quantity,
          orderType: 'market',
          action: trade.type === 'long' ? 'sell' : 'buy', // Opposite of the original order
          accountId: account.accountId
        };
        
        // Execute the closing order
        await schwabService.executeTrade(closingOrder);
        
        // Update the account's activeTrades count
        await storage.updateAccount(account.id, { 
          activeTrades: Math.max(0, account.activeTrades - 1) 
        });
      }
      
      // Close the trade in our database
      const closedTrade = await storage.closeTrade(tradeId);
      
      log(`Trade ${tradeId} closed successfully`, "trade-service");
      return closedTrade;
    } catch (error: any) {
      log(`Error closing trade ${tradeId}: ${error.message}`, "trade-service-error");
      throw new Error(`Failed to close trade: ${error.message}`);
    }
  }
  
  // Update all active trades
  async updateAllActiveTrades(): Promise<void> {
    try {
      const activeTrades = await storage.getActiveTrades();
      
      for (const trade of activeTrades) {
        try {
          await this.updateTrade(trade.id);
        } catch (error: any) {
          log(`Error updating trade ${trade.id}: ${error.message}`, "trade-service-error");
          // Continue updating other trades even if one fails
        }
      }
      
      log(`Updated ${activeTrades.length} active trades`, "trade-service");
    } catch (error: any) {
      log(`Error updating active trades: ${error.message}`, "trade-service-error");
      throw new Error(`Failed to update active trades: ${error.message}`);
    }
  }
}

// For drizzle query in closeTrade method
import { eq } from 'drizzle-orm';
import { db } from '../db';
import { tradeAccounts } from '@shared/schema';

export const tradeService = new TradeService();
