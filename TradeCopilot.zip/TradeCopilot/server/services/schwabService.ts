import axios, { AxiosInstance } from 'axios';
import { log } from '../vite';

interface SchwabAuthConfig {
  apiKey: string;
  apiSecret: string;
  baseURL: string;
}

export interface TradeOrder {
  symbol: string;
  quantity: number;
  orderType: 'market' | 'limit' | 'stop' | 'stop_limit' | 'trailing_stop';
  action: 'buy' | 'sell';
  price?: number;
  stopPrice?: number;
  trailAmount?: number;
  trailType?: 'amount' | 'percentage';
  timeInForce?: 'day' | 'gtc' | 'ext';
  accountId: string;
  // Support for options trading
  isOption?: boolean;
  expirationDate?: string; // Format: YYYY-MM-DD
  strikePrice?: number;
  optionType?: 'call' | 'put';
  optionStrategy?: 'single' | 'vertical' | 'calendar' | 'straddle' | 'strangle' | 'iron_condor';
  // For multi-leg options
  legs?: Array<{
    symbol: string;
    action: 'buy' | 'sell';
    quantity: number;
    optionType: 'call' | 'put';
    strikePrice: number;
    expirationDate: string;
  }>;
}

export interface TradeResponse {
  orderId: string;
  status: string;
  filledPrice?: number;
  filledQuantity?: number;
  timestamp?: Date;
  message?: string;
}

export interface AccountDetails {
  accountId: string;
  accountName: string;
  accountType: string;
  balance: number;
  marginAvailable?: number;
  pdtStatus?: boolean; 
  status: 'active' | 'inactive' | 'restricted';
}

export interface MarketQuote {
  symbol: string;
  price: number;
  change: number;
  changePercentage: number;
  bid?: number;
  ask?: number;
  volume?: number;
}

class SchwabService {
  private client: AxiosInstance;
  private isAuthenticated: boolean = false;
  private initialized: boolean = false;
  
  constructor() {
    // Initialize the client but don't authenticate yet
    this.client = axios.create({
      baseURL: process.env.SCHWAB_API_URL || 'https://api.schwab.com',  // Use default if not provided
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
  }
  
  // Initialize the service with credentials check
  private async initialize(): Promise<void> {
    if (this.initialized) return;
    
    // Check for required environment variables
    if (!process.env.SCHWAB_API_KEY || !process.env.SCHWAB_API_SECRET || !process.env.SCHWAB_API_URL) {
      log("Missing Schwab API credentials. Set SCHWAB_API_KEY, SCHWAB_API_SECRET, and SCHWAB_API_URL", "error");
      throw new Error("Missing Schwab API credentials");
    }
    
    // Update URL if it was provided later
    this.client.defaults.baseURL = process.env.SCHWAB_API_URL;
    this.initialized = true;
  }
  
  private async authenticate(): Promise<void> {
    try {
      const response = await this.client.post('/auth', {
        apiKey: process.env.SCHWAB_API_KEY,
        apiSecret: process.env.SCHWAB_API_SECRET
      });
      
      if (response.data && response.data.token) {
        this.client.defaults.headers.common['Authorization'] = `Bearer ${response.data.token}`;
        this.isAuthenticated = true;
        log("Successfully authenticated with Schwab API", "schwab");
      } else {
        throw new Error("Authentication failed: No token received");
      }
    } catch (error: any) {
      this.isAuthenticated = false;
      log(`Schwab API authentication error: ${error.message}`, "schwab-error");
      throw new Error(`Schwab API authentication failed: ${error.message}`);
    }
  }
  
  // Ensure authentication before making requests
  private async ensureAuth(): Promise<void> {
    // Make sure we're initialized first
    if (!this.initialized) {
      try {
        await this.initialize();
      } catch (error) {
        // If we can't initialize, log but don't throw to allow app to start
        log(`SchwabService initialization failed: ${error instanceof Error ? error.message : String(error)}`, "schwab-error");
        return;
      }
    }
    
    // Only try to authenticate if we successfully initialized
    if (this.initialized && !this.isAuthenticated) {
      try {
        await this.authenticate();
      } catch (error) {
        // If we can't authenticate, log but don't throw to allow app to start
        log(`SchwabService authentication failed: ${error instanceof Error ? error.message : String(error)}`, "schwab-error");
      }
    }
  }
  
  // Get account details
  async getAccountDetails(accountId: string): Promise<AccountDetails> {
    await this.ensureAuth();
    
    try {
      if (!this.isAuthenticated) {
        log(`Not authenticated, using mock account details for ${accountId}`, "schwab-warning");
        const { mockAccountDetails } = await import('./mockSchwabData');
        return { ...mockAccountDetails, accountId };
      }
      
      const response = await this.client.get(`/accounts/${accountId}`);
      return response.data;
    } catch (error: any) {
      log(`Failed to get account details: ${error.message}`, "schwab-error");
      
      // Return mock data instead of throwing
      try {
        const { mockAccountDetails } = await import('./mockSchwabData');
        log(`Using mock account details for ${accountId}`, "schwab-info");
        return { ...mockAccountDetails, accountId };
      } catch (mockError) {
        log(`Error loading mock data: ${mockError}`, "schwab-error");
        throw new Error(`Failed to get account details: ${error.message}`);
      }
    }
  }
  
  // Get all accounts (for admin users)
  async getAccounts(): Promise<AccountDetails[]> {
    await this.ensureAuth();
    
    try {
      if (!this.isAuthenticated) {
        log("Not authenticated, using mock accounts data", "schwab-warning");
        const { mockAccountDetails } = await import('./mockSchwabData');
        // Create an array with a few variations of the mock account
        return [
          mockAccountDetails,
          { ...mockAccountDetails, accountId: '987654321', accountName: 'Demo IRA Account', accountType: 'IRA' },
          { ...mockAccountDetails, accountId: '456789123', accountName: 'Demo Investment Account', accountType: 'Individual', balance: 250000.00 }
        ];
      }
      
      const response = await this.client.get('/accounts');
      return response.data;
    } catch (error: any) {
      log(`Failed to get accounts: ${error.message}`, "schwab-error");
      
      // Return mock data instead of throwing
      try {
        const { mockAccountDetails } = await import('./mockSchwabData');
        log("Using mock accounts data", "schwab-info");
        // Create an array with a few variations of the mock account
        return [
          mockAccountDetails,
          { ...mockAccountDetails, accountId: '987654321', accountName: 'Demo IRA Account', accountType: 'IRA' },
          { ...mockAccountDetails, accountId: '456789123', accountName: 'Demo Investment Account', accountType: 'Individual', balance: 250000.00 }
        ];
      } catch (mockError) {
        log(`Error loading mock data: ${mockError}`, "schwab-error");
        throw new Error(`Failed to get accounts: ${error.message}`);
      }
    }
  }
  
  // Execute a trade
  async executeTrade(order: TradeOrder): Promise<TradeResponse> {
    await this.ensureAuth();
    
    try {
      if (!this.isAuthenticated) {
        log(`Not authenticated, using mock trade execution for ${order.symbol}`, "schwab-warning");
        const { mockTradeResponse } = await import('./mockSchwabData');
        return {
          ...mockTradeResponse,
          orderId: `ORD${Date.now()}`,
          timestamp: new Date(),
          filledPrice: order.price || (await this.getQuote(order.symbol)).price
        };
      }
      
      let endpoint = '/orders';
      
      // Determine if this is an options order and use the correct endpoint
      if (order.isOption) {
        if (order.legs && order.legs.length > 0) {
          endpoint = '/orders/options/multi';
        } else {
          endpoint = '/orders/options';
        }
      }
      
      // Create appropriate payload based on order type
      let payload: any = {
        symbol: order.symbol,
        quantity: order.quantity,
        orderType: order.orderType,
        action: order.action,
        accountId: order.accountId,
        timeInForce: order.timeInForce || 'day'
      };
      
      // Add conditional properties based on order type
      if (order.orderType === 'limit' || order.orderType === 'stop_limit') {
        payload.price = order.price;
      }
      
      if (order.orderType === 'stop' || order.orderType === 'stop_limit') {
        payload.stopPrice = order.stopPrice;
      }
      
      if (order.orderType === 'trailing_stop') {
        payload.trailAmount = order.trailAmount;
        payload.trailType = order.trailType || 'amount';
      }
      
      // Add options-specific data if applicable
      if (order.isOption) {
        if (order.legs && order.legs.length > 0) {
          // Multi-leg options order
          payload.strategy = order.optionStrategy;
          payload.legs = order.legs;
        } else {
          // Single options order
          payload.expirationDate = order.expirationDate;
          payload.strikePrice = order.strikePrice;
          payload.optionType = order.optionType;
        }
      }
      
      const response = await this.client.post(endpoint, payload);
      return response.data;
    } catch (error: any) {
      log(`Trade execution failed: ${error.message}`, "schwab-error");
      
      // Return mock data instead of throwing
      try {
        const { mockTradeResponse } = await import('./mockSchwabData');
        log(`Using mock trade execution for ${order.symbol}`, "schwab-info");
        return {
          ...mockTradeResponse,
          orderId: `ORD${Date.now()}`,
          timestamp: new Date(),
          filledPrice: order.price || (await this.getQuote(order.symbol)).price
        };
      } catch (mockError) {
        log(`Error loading mock data: ${mockError}`, "schwab-error");
        throw new Error(`Trade execution failed: ${error.message}`);
      }
    }
  }
  
  // Search for tradable symbols (stocks, ETFs, options)
  async searchSymbols(query: string): Promise<any[]> {
    await this.ensureAuth();
    
    try {
      if (!this.isAuthenticated) {
        log(`Not authenticated, using mock symbol search for ${query}`, "schwab-warning");
        // Generate simple mock results
        return [
          { symbol: query.toUpperCase(), name: `${query.toUpperCase()} Corp`, type: 'stock' },
          { symbol: `${query.toUpperCase()}.X`, name: `${query.toUpperCase()} ETF`, type: 'etf' }
        ];
      }
      
      const response = await this.client.get('/search/symbols', {
        params: { query }
      });
      return response.data;
    } catch (error: any) {
      log(`Symbol search failed: ${error.message}`, "schwab-error");
      
      // Return mock symbols instead of empty array
      return [
        { symbol: query.toUpperCase(), name: `${query.toUpperCase()} Corp`, type: 'stock' },
        { symbol: `${query.toUpperCase()}.X`, name: `${query.toUpperCase()} ETF`, type: 'etf' }
      ];
    }
  }
  
  // Get option chain for a symbol
  async getOptionChain(symbol: string, expirationDate?: string): Promise<any> {
    await this.ensureAuth();
    
    try {
      if (!this.isAuthenticated) {
        log(`Not authenticated, using mock option chain for ${symbol}`, "schwab-warning");
        
        // Generate mock option chain data
        const quote = await this.getQuote(symbol);
        const currentPrice = quote.price;
        const expirations = expirationDate ? [expirationDate] : 
          ['2023-05-19', '2023-05-26', '2023-06-16', '2023-07-21'];
          
        // Generate strikes around the current price
        const strikeStep = Math.round(currentPrice * 0.05) / 10;
        const strikes = Array.from({length: 10}, (_, i) => 
          Math.round((currentPrice - (strikeStep * 5) + (strikeStep * i)) * 100) / 100);
          
        return {
          symbol,
          expirations,
          current_price: currentPrice,
          options: expirations.flatMap(expDate => 
            strikes.flatMap(strike => [
              // Call option
              {
                symbol: `${symbol}${expDate.replace(/-/g, '')}C${strike * 1000}`,
                option_type: 'call',
                strike_price: strike,
                expiration_date: expDate,
                bid: Math.max(0, Math.round((currentPrice - strike + Math.random() * 2) * 100) / 100),
                ask: Math.max(0.01, Math.round((currentPrice - strike + 2 + Math.random() * 2) * 100) / 100),
                volume: Math.floor(Math.random() * 1000),
                open_interest: Math.floor(Math.random() * 5000),
                delta: Math.min(1, Math.max(0, (currentPrice / strike) * Math.random())),
                implied_volatility: Math.random() * 0.5,
              },
              // Put option
              {
                symbol: `${symbol}${expDate.replace(/-/g, '')}P${strike * 1000}`,
                option_type: 'put',
                strike_price: strike,
                expiration_date: expDate,
                bid: Math.max(0, Math.round((strike - currentPrice + Math.random() * 2) * 100) / 100),
                ask: Math.max(0.01, Math.round((strike - currentPrice + 2 + Math.random() * 2) * 100) / 100),
                volume: Math.floor(Math.random() * 1000),
                open_interest: Math.floor(Math.random() * 5000),
                delta: Math.min(1, Math.max(0, (strike / currentPrice) * Math.random() * -1)),
                implied_volatility: Math.random() * 0.5,
              }
            ])
          )
        };
      }
      
      const params: any = { symbol };
      if (expirationDate) {
        params.expiration = expirationDate;
      }
      
      const response = await this.client.get('/chain/options', { params });
      return response.data;
    } catch (error: any) {
      log(`Option chain request failed: ${error.message}`, "schwab-error");
      
      // Return empty structure
      return {
        symbol,
        expirations: [],
        options: []
      };
    }
  }
  
  // Validate a trade before execution
  async validateTrade(trade: TradeOrder): Promise<{ isValid: boolean, message?: string }> {
    await this.ensureAuth();
    
    try {
      if (!this.isAuthenticated) {
        log(`Not authenticated, using mock trade validation for ${trade.symbol}`, "schwab-warning");
        // Simple mock validation that always passes
        return { 
          isValid: true, 
          message: "Trade validated successfully" 
        };
      }
      
      const response = await this.client.post('/orders/validate', trade);
      return response.data;
    } catch (error: any) {
      log(`Trade validation failed: ${error.message}`, "schwab-error");
      
      // Return a success response in development
      return { 
        isValid: true, 
        message: "Trade validated successfully (mock)" 
      };
    }
  }
  
  // Get market quotes
  async getQuote(symbol: string): Promise<MarketQuote> {
    await this.ensureAuth();
    
    try {
      if (!this.isAuthenticated) {
        log(`Not authenticated, using mock quote data for ${symbol}`, "schwab-warning");
        const { generateMockQuote } = await import('./mockSchwabData');
        return generateMockQuote(symbol);
      }
      
      const response = await this.client.get(`/quotes/${symbol}`);
      return response.data;
    } catch (error: any) {
      log(`Failed to get quote for ${symbol}: ${error.message}`, "schwab-error");
      
      // Use mock data instead of throwing error
      try {
        const { generateMockQuote } = await import('./mockSchwabData');
        log(`Using mock quote data for ${symbol}`, "schwab-info");
        return generateMockQuote(symbol);
      } catch (mockError) {
        log(`Error loading mock data: ${mockError}`, "schwab-error");
        throw new Error(`Failed to get quote for ${symbol}: ${error.message}`);
      }
    }
  }
  
  // Get quotes for multiple symbols
  async getQuotes(symbols: string[]): Promise<MarketQuote[]> {
    await this.ensureAuth();
    
    try {
      // Only proceed if we're authenticated, otherwise return mock data
      if (!this.isAuthenticated) {
        log("Not authenticated, using mock quotes data", "schwab-warning");
        const { generateMockQuotes } = await import('./mockSchwabData');
        return generateMockQuotes(symbols);
      }
      
      const response = await this.client.get('/quotes', {
        params: { symbols: symbols.join(',') }
      });
      return response.data;
    } catch (error: any) {
      log(`Failed to get quotes: ${error.message}`, "schwab-error");
      
      // Use mock data instead of returning empty array
      try {
        const { generateMockQuotes } = await import('./mockSchwabData');
        log("Using mock quotes data", "schwab-info");
        return generateMockQuotes(symbols);
      } catch (mockError) {
        log(`Error loading mock data: ${mockError}`, "schwab-error");
        return [];
      }
    }
  }
  
  // Get market indices
  async getMarketIndices(): Promise<MarketQuote[]> {
    await this.ensureAuth();
    
    try {
      const indices = ['SPX', 'COMP', 'DJI', 'VIX'];
      return await this.getQuotes(indices);
    } catch (error: any) {
      log(`Failed to get market indices: ${error.message}`, "schwab-error");
      
      // Import mock data for development/testing
      try {
        const { mockMarketIndices } = await import('./mockSchwabData');
        log("Using mock market indices data", "schwab-info");
        return mockMarketIndices;
      } catch (mockError) {
        log(`Error loading mock data: ${mockError}`, "schwab-error");
        return [];
      }
    }
  }
}

export const schwabService = new SchwabService();
