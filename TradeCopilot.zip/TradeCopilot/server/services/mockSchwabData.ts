import { MarketQuote, AccountDetails, TradeResponse } from './schwabService';

// Mock market indices data
export const mockMarketIndices: MarketQuote[] = [
  {
    symbol: 'SPX',
    price: 5123.45,
    change: 23.45,
    changePercentage: 0.46,
    bid: 5123.25,
    ask: 5123.65,
    volume: 2456789
  },
  {
    symbol: 'COMP',
    price: 16234.67,
    change: -45.32,
    changePercentage: -0.28,
    bid: 16234.50,
    ask: 16234.85,
    volume: 1873456
  },
  {
    symbol: 'DJI',
    price: 38765.43,
    change: 134.56,
    changePercentage: 0.35,
    bid: 38765.00,
    ask: 38766.00,
    volume: 3214567
  },
  {
    symbol: 'VIX',
    price: 18.65,
    change: -0.32,
    changePercentage: -1.69,
    bid: 18.64,
    ask: 18.66,
    volume: 765432
  }
];

// Mock account details
export const mockAccountDetails: AccountDetails = {
  accountId: '123456789',
  accountName: 'Demo Trading Account',
  accountType: 'Margin',
  balance: 100000.00,
  marginAvailable: 50000.00,
  pdtStatus: false,
  status: 'active'
};

// Mock trade response
export const mockTradeResponse: TradeResponse = {
  orderId: 'ORD123456789',
  status: 'executed',
  filledPrice: 352.45,
  filledQuantity: 10,
  timestamp: new Date(),
  message: 'Order executed successfully'
};

// Function to generate a mock quote for a given symbol
export function generateMockQuote(symbol: string): MarketQuote {
  // Generate a random price between 10 and 1000
  const price = Math.random() * 990 + 10;
  // Generate a random change between -5 and 5
  const change = (Math.random() * 10) - 5;
  // Calculate change percentage
  const changePercentage = (change / price) * 100;
  
  return {
    symbol: symbol.toUpperCase(),
    price: parseFloat(price.toFixed(2)),
    change: parseFloat(change.toFixed(2)),
    changePercentage: parseFloat(changePercentage.toFixed(2)),
    bid: parseFloat((price - 0.05).toFixed(2)),
    ask: parseFloat((price + 0.05).toFixed(2)),
    volume: Math.floor(Math.random() * 10000000)
  };
}

// Generate mock quotes for multiple symbols
export function generateMockQuotes(symbols: string[]): MarketQuote[] {
  return symbols.map(symbol => generateMockQuote(symbol));
}