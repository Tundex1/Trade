import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";
import { log } from './vite';

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Add connection options for better stability
export const pool = new Pool({ 
  connectionString: process.env.DATABASE_URL,
  connectionTimeoutMillis: 5000,
  max: 20,
  idleTimeoutMillis: 30000,
  keepAlive: true
});

export const db = drizzle(pool, { schema });

// Log DB connection but don't throw errors that would crash the server
pool.connect()
  .then(() => log("Database connected successfully", "db"))
  .catch(err => {
    log(`Database connection error: ${err.message}`, "db-error");
    // Log error but don't throw to prevent server crash
  });
