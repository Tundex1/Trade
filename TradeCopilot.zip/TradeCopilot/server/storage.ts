import { 
  users, type User, type InsertUser, 
  accounts, type Account, type InsertAccount,
  trades, type Trade, type InsertTrade,
  tradeAccounts, type TradeAccount, type InsertTradeAccount,
  marketData, type MarketData, type InsertMarketData
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";
import { hash, compare } from "bcrypt";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  verifyUserCredentials(username: string, password: string): Promise<User | null>;
  
  // Account operations
  getAccount(id: number): Promise<Account | undefined>;
  getAccounts(): Promise<Account[]>;
  createAccount(account: InsertAccount): Promise<Account>;
  updateAccount(id: number, account: Partial<InsertAccount>): Promise<Account | undefined>;
  deleteAccount(id: number): Promise<boolean>;
  
  // Trade operations
  getTrade(id: number): Promise<Trade | undefined>;
  getTrades(): Promise<Trade[]>;
  getActiveTrades(): Promise<Trade[]>;
  getTradeHistory(filters?: { startDate?: Date; endDate?: Date; symbol?: string; status?: string; account?: number; }): Promise<Trade[]>;
  getTradeHistoryWithAccounts(filters?: { startDate?: Date; endDate?: Date; symbol?: string; status?: string; account?: number; }): Promise<any[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: number, trade: Partial<InsertTrade>): Promise<Trade | undefined>;
  closeTrade(id: number): Promise<Trade | undefined>;
  
  // TradeAccount operations
  getTradeAccount(id: number): Promise<TradeAccount | undefined>;
  getTradeAccountsByTrade(tradeId: number): Promise<TradeAccount[]>;
  getAccountTradesSince(accountId: number, date: Date): Promise<TradeAccount[]>;
  createTradeAccount(tradeAccount: InsertTradeAccount): Promise<TradeAccount>;
  updateTradeAccount(id: number, tradeAccount: Partial<InsertTradeAccount>): Promise<TradeAccount | undefined>;
  
  // Option Legs operations
  getOptionLegsForTrade(tradeId: number): Promise<OptionLeg[]>;
  createOptionLeg(optionLeg: InsertOptionLeg): Promise<OptionLeg>;
  
  // Market data
  getMarketData(): Promise<MarketData[]>;
  updateMarketData(data: InsertMarketData): Promise<MarketData>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Hash the password before storing
    const hashedPassword = await hash(insertUser.password, 10);
    
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        password: hashedPassword
      })
      .returning();
      
    return user;
  }
  
  async verifyUserCredentials(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    try {
      // For debugging, log username and password length
      console.log(`Verifying credentials for ${username} (password length: ${password.length})`);
      
      const isPasswordValid = await compare(password, user.password);
      
      if (!isPasswordValid) {
        console.log(`Password validation failed for ${username}`);
        return null;
      }
      
      // Update last login
      await db
        .update(users)
        .set({ lastLogin: new Date() })
        .where(eq(users.id, user.id));
        
      console.log(`Authentication successful for ${username}`);
      return user;
    } catch (error) {
      console.error(`Password comparison error:`, error);
      return null;
    }
  }

  // Account operations
  async getAccount(id: number): Promise<Account | undefined> {
    const [account] = await db.select().from(accounts).where(eq(accounts.id, id));
    return account;
  }

  async getAccounts(): Promise<Account[]> {
    return db.select().from(accounts).orderBy(accounts.createdAt);
  }

  async createAccount(account: InsertAccount): Promise<Account> {
    const [newAccount] = await db
      .insert(accounts)
      .values(account)
      .returning();
      
    return newAccount;
  }

  async updateAccount(id: number, accountData: Partial<InsertAccount>): Promise<Account | undefined> {
    const [updatedAccount] = await db
      .update(accounts)
      .set({
        ...accountData,
        updatedAt: new Date()
      })
      .where(eq(accounts.id, id))
      .returning();
      
    return updatedAccount;
  }

  async deleteAccount(id: number): Promise<boolean> {
    const result = await db
      .delete(accounts)
      .where(eq(accounts.id, id));
      
    return true;
  }
  
  // Trade operations
  async getTrade(id: number): Promise<Trade | undefined> {
    const [trade] = await db.select().from(trades).where(eq(trades.id, id));
    return trade;
  }

  async getTrades(): Promise<Trade[]> {
    return db.select().from(trades).orderBy(desc(trades.createdAt));
  }
  
  async getTradeHistory(filters?: {
    startDate?: Date;
    endDate?: Date;
    symbol?: string;
    status?: string;
    account?: number;
  }): Promise<Trade[]> {
    // Start with base query
    let query = db.select({
      id: trades.id,
      symbol: trades.symbol,
      type: trades.type,
      entryPrice: trades.entryPrice,
      currentPrice: trades.currentPrice,
      quantity: trades.quantity,
      profitLoss: trades.profitLoss,
      profitLossPercentage: trades.profitLossPercentage,
      status: trades.status,
      createdAt: trades.createdAt,
      closedAt: trades.closedAt,
      isOption: trades.isOption,
      optionType: trades.optionType,
      strikePrice: trades.strikePrice,
      expirationDate: trades.expirationDate,
    })
    .from(trades);
    
    // Apply filters if provided
    if (filters) {
      const conditions = [];
      
      if (filters.startDate) {
        conditions.push(sql`${trades.createdAt} >= ${filters.startDate}`);
      }
      
      if (filters.endDate) {
        conditions.push(sql`${trades.createdAt} <= ${filters.endDate}`);
      }
      
      if (filters.symbol) {
        conditions.push(sql`${trades.symbol} ILIKE ${`%${filters.symbol}%`}`);
      }
      
      if (filters.status) {
        conditions.push(sql`${trades.status} = ${filters.status}`);
      }
      
      // Apply all conditions if any
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
    }
    
    const tradeResults = await query.orderBy(desc(trades.createdAt));
    
    // If we need to filter by account, we need to join with tradeAccounts
    if (filters?.account) {
      // Get all trade accounts for specified account
      const tradeAccountResults = await db
        .select()
        .from(tradeAccounts)
        .where(eq(tradeAccounts.accountId, filters.account));
      
      // Filter trade results by account
      const tradeIds = tradeAccountResults.map(ta => ta.tradeId);
      return tradeResults.filter(trade => tradeIds.includes(trade.id));
    }
    
    return tradeResults;
  }

  async getActiveTrades(): Promise<Trade[]> {
    return db
      .select()
      .from(trades)
      .where(eq(trades.status, 'active'))
      .orderBy(desc(trades.createdAt));
  }

  async createTrade(trade: InsertTrade): Promise<Trade> {
    const [newTrade] = await db
      .insert(trades)
      .values(trade)
      .returning();
      
    return newTrade;
  }

  async updateTrade(id: number, tradeData: Partial<InsertTrade>): Promise<Trade | undefined> {
    const [updatedTrade] = await db
      .update(trades)
      .set({
        ...tradeData,
        updatedAt: new Date()
      })
      .where(eq(trades.id, id))
      .returning();
      
    return updatedTrade;
  }

  async closeTrade(id: number): Promise<Trade | undefined> {
    const [closedTrade] = await db
      .update(trades)
      .set({
        status: 'closed',
        closedAt: new Date(),
        updatedAt: new Date()
      })
      .where(eq(trades.id, id))
      .returning();
      
    return closedTrade;
  }
  
  // TradeAccount operations
  async getTradeAccount(id: number): Promise<TradeAccount | undefined> {
    const [tradeAccount] = await db.select().from(tradeAccounts).where(eq(tradeAccounts.id, id));
    return tradeAccount;
  }
  
  async getTradeAccountsByTrade(tradeId: number): Promise<TradeAccount[]> {
    return db
      .select()
      .from(tradeAccounts)
      .where(eq(tradeAccounts.tradeId, tradeId))
      .orderBy(tradeAccounts.createdAt);
  }
  
  async getTradeHistoryWithAccounts(filters?: {
    startDate?: Date;
    endDate?: Date;
    symbol?: string;
    status?: string;
    account?: number;
  }): Promise<any[]> {
    // Get the base trade data first
    const tradeResults = await this.getTradeHistory(filters);
    
    // Create an array to store the enhanced trade data
    const enhancedTradeData = [];
    
    // Enhance each trade with its account details
    for (const trade of tradeResults) {
      // Get the trade accounts for this trade
      const tradeAccountsData = await this.getTradeAccountsByTrade(trade.id);
      
      // Get the account data for each trade account
      const accounts = [];
      for (const ta of tradeAccountsData) {
        const account = await this.getAccount(ta.accountId);
        if (account) {
          accounts.push({
            id: account.id,
            accountName: account.accountName,
            accountId: account.accountId,
            status: ta.status,
            executedAt: ta.executedAt,
            profitLoss: ta.profitLoss,
            quantity: ta.quantity,
            price: ta.price,
            errorMessage: ta.errorMessage
          });
        }
      }
      
      // Add the enhanced data
      enhancedTradeData.push({
        ...trade,
        accounts
      });
    }
    
    return enhancedTradeData;
  }
  
  async getAccountTradesSince(accountId: number, date: Date): Promise<TradeAccount[]> {
    return db
      .select()
      .from(tradeAccounts)
      .where(
        and(
          eq(tradeAccounts.accountId, accountId),
          sql`${tradeAccounts.createdAt} >= ${date}`
        )
      )
      .orderBy(desc(tradeAccounts.createdAt));
  }

  async createTradeAccount(tradeAccount: InsertTradeAccount): Promise<TradeAccount> {
    const [newTradeAccount] = await db
      .insert(tradeAccounts)
      .values(tradeAccount)
      .returning();
      
    return newTradeAccount;
  }
  
  async updateTradeAccount(id: number, tradeAccountData: Partial<InsertTradeAccount>): Promise<TradeAccount | undefined> {
    const [updatedTradeAccount] = await db
      .update(tradeAccounts)
      .set({
        ...tradeAccountData,
        updatedAt: new Date()
      })
      .where(eq(tradeAccounts.id, id))
      .returning();
      
    return updatedTradeAccount;
  }
  
  // Option Legs operations
  async getOptionLegsForTrade(tradeId: number): Promise<OptionLeg[]> {
    return db
      .select()
      .from(optionLegs)
      .where(eq(optionLegs.tradeId, tradeId))
      .orderBy(optionLegs.createdAt);
  }
  
  async createOptionLeg(optionLeg: InsertOptionLeg): Promise<OptionLeg> {
    const [newOptionLeg] = await db
      .insert(optionLegs)
      .values(optionLeg)
      .returning();
      
    return newOptionLeg;
  }
  
  // Market data
  async getMarketData(): Promise<MarketData[]> {
    return db.select().from(marketData).orderBy(marketData.symbol);
  }

  async updateMarketData(data: InsertMarketData): Promise<MarketData> {
    // Check if the symbol exists
    const [existingData] = await db
      .select()
      .from(marketData)
      .where(eq(marketData.symbol, data.symbol));
    
    if (existingData) {
      // Update existing record
      const [updatedData] = await db
        .update(marketData)
        .set({
          price: data.price,
          change: data.change,
          changePercentage: data.changePercentage,
          updatedAt: new Date()
        })
        .where(eq(marketData.symbol, data.symbol))
        .returning();
        
      return updatedData;
    } else {
      // Insert new record
      const [newData] = await db
        .insert(marketData)
        .values(data)
        .returning();
        
      return newData;
    }
  }
}

export const storage = new DatabaseStorage();
