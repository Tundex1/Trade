import { Router, type Request, type Response } from "express"
import { oauthService } from "../services/oauthService"
import { storage } from "../storage"
import { authenticate } from "../middleware/auth"
import type { AuthRequest } from "../middleware/auth"
import { randomBytes } from "crypto"

const router = Router()

// Generate a random state for CSRF protection
const generateState = (): string => {
  return randomBytes(32).toString("hex")
}

// Route: GET /auth/schwab/connect
// Returns Schwab login URL with appropriate parameters as JSON
router.get("/connect", authenticate, async (req: AuthRequest, res: Response) => {
  try {
    // Require accountId parameter
    const accountId = req.query.accountId as string

    // If accountId is 0, this is a new account connection
    const isNewAccount = accountId === "0"

    // Generate and store state parameter to prevent CSRF
    const state = generateState()

    // Store the state and accountId in session to verify on callback
    req.session.oauthState = state
    req.session.accountId = accountId
    req.session.isNewAccount = isNewAccount

    // Return the authorization URL as JSON instead of redirecting
    const authUrl = oauthService.getAuthorizationUrl(state)
    res.status(200).json({ authUrl })
  } catch (error) {
    console.error("[oauth-error] Connect error:", error)
    res.status(500).json({ error: "Failed to initiate OAuth flow" })
  }
})

// Route: GET /auth/schwab/callback
// Handles callback from Schwab OAuth with code
router.get("/callback", async (req: Request, res: Response) => {
  try {
    const { code, state } = req.query

    // Validate state to prevent CSRF attacks
    if (!state || state !== req.session.oauthState) {
      return res.status(400).json({ error: "Invalid state parameter" })
    }

    // Get accountId from session
    const accountId = Number.parseInt(req.session.accountId as string, 10)
    const isNewAccount = req.session.isNewAccount === true

    // Exchange code for tokens
    const tokenResponse = await oauthService.exchangeCodeForToken(code as string)

    // Get account details from Schwab API
    const accountDetails = await oauthService.getAccountDetails(tokenResponse.access_token)

    if (isNewAccount) {
      // Create a new account with the details from Schwab
      const newAccount = await storage.createAccount({
        accountName: accountDetails.accountName || `Schwab Account ${accountDetails.accountId}`,
        accountId: accountDetails.accountId,
        accountType: accountDetails.accountType || "Schwab",
        balance: accountDetails.balance || 0,
        status: "connected",
        activeTrades: 0,
        monthlyProfitLoss: 0,
        monthlyProfitLossPercentage: 0,
      })

      // Save tokens for the new account
      await oauthService.saveTokens(newAccount.id, tokenResponse)
    } else {
      // Save tokens for existing account
      await oauthService.saveTokens(accountId, tokenResponse)

      // Update account status and balance
      await storage.updateAccount(accountId, {
        status: "connected",
        balance: accountDetails.balance || 0,
      })
    }

    // Clear session data
    delete req.session.oauthState
    delete req.session.accountId
    delete req.session.isNewAccount

    // Redirect back to application
    res.redirect("/accounts")
  } catch (error) {
    console.error("[oauth-error] Callback error:", error)
    res.status(500).json({ error: "Failed to complete OAuth flow" })
  }
})

// Check if an account has a valid OAuth token
router.get("/status/:accountId", authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const accountId = Number.parseInt(req.params.accountId, 10)
    const token = await oauthService.getTokenByAccountId(accountId)

    if (!token) {
      return res.json({ connected: false })
    }

    const now = new Date()
    const isValid = now < token.expiresAt
    const expiresIn = Math.floor((token.expiresAt.getTime() - now.getTime()) / 1000) // seconds until expiration

    res.json({
      connected: isValid,
      expiresAt: token.expiresAt,
      expiresIn,
      tokenAge: Math.floor((now.getTime() - token.createdAt.getTime()) / 1000), // seconds since creation
      lastRefreshed: token.updatedAt,
    })
  } catch (error) {
    console.error("[oauth-error] Status check error:", error)
    res.status(500).json({ error: "Failed to check OAuth status" })
  }
})

// Disconnect an account (revoke OAuth token)
router.post("/disconnect/:accountId", authenticate, async (req: AuthRequest, res: Response) => {
  try {
    const accountId = Number.parseInt(req.params.accountId, 10)

    // Get the token
    const token = await oauthService.getTokenByAccountId(accountId)

    if (!token) {
      return res.status(404).json({ error: "No token found for this account" })
    }

    // Revoke the token with Schwab
    await oauthService.revokeToken(token)

    // Update account status
    await storage.updateAccount(accountId, {
      status: "disconnected",
    })

    res.json({ success: true, message: "Account disconnected successfully" })
  } catch (error) {
    console.error("[oauth-error] Disconnect error:", error)
    res.status(500).json({ error: "Failed to disconnect account" })
  }
})

export default router
